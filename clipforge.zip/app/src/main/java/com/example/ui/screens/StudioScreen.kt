package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ClosedCaptionDisabled
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.media.OnDeviceSignalAnalyzer
import com.example.data.model.CaptionPosition
import com.example.data.model.FilterPreset
import com.example.data.model.MusicTrack
import com.example.data.model.SocialPlatform
import com.example.data.model.SubtitleStyle
import com.example.data.model.UiState
import com.example.data.model.VideoEffect
import com.example.data.model.ViralClipDoc
import com.example.ui.components.ClipThumbnailTemplateCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.LocalVideoPlayer
import com.example.ui.components.SubtitleCaptionOverlay
import com.example.ui.components.YouTubeClipSegmentPlayer
import com.example.ui.components.formatSec
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse
import com.example.ui.viewmodel.ExportStatus
import kotlinx.coroutines.delay

enum class StudioToolTab(val label: String, val icon: ImageVector) {
    TRIM("Edit & Trim", Icons.Default.ContentCut),
    FILTERS("Filters", Icons.Default.Palette),
    EFFECTS("Effects", Icons.Default.AutoFixHigh),
    SUBTITLES("Captions", Icons.Default.ClosedCaption),
    AUDIO("Audio", Icons.Default.AudioFile),
    TEMPLATES("Templates", Icons.Default.Style),
    EXPORT("HD Export", Icons.Default.FileDownload)
}

@Composable
fun StudioScreen(
    clipsState: UiState<List<ViralClipDoc>>,
    selectedClipId: String?,
    exportStatus: ExportStatus,
    isGeneratingSeo: Boolean,
    isGeneratingCaptions: Boolean,
    isGeneratingSmartEdit: Boolean = false,
    onSelectClip: (String) -> Unit,
    onUploadVideoToStudio: (Uri) -> Unit,
    onSaveClip: (ViralClipDoc) -> Unit,
    onSplitClip: (ViralClipDoc, Long) -> Unit = { _, _ -> },
    onDuplicateClip: (ViralClipDoc) -> Unit = {},
    onCaptureCoverFrame: (ViralClipDoc, Long, (ViralClipDoc) -> Unit) -> Unit = { _, _, _ -> },
    onSyncScript: (ViralClipDoc, String, (ViralClipDoc) -> Unit) -> Unit = { _, _, _ -> },
    onAiSmartEdit: (ViralClipDoc, (ViralClipDoc) -> Unit) -> Unit = { _, _ -> },
    onGenerateSeo: (ViralClipDoc, SocialPlatform, (ViralClipDoc) -> Unit) -> Unit,
    onRegenerateCaptions: (ViralClipDoc) -> Unit,
    onExportClip: (ViralClipDoc) -> Unit
) {
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onUploadVideoToStudio(uri)
            }
        }
    )

    val clips = (clipsState as? UiState.Success)?.data.orEmpty()
    val activeClip = remember(clips, selectedClipId) {
        clips.firstOrNull { it.id == selectedClipId } ?: clips.firstOrNull()
    }

    if (activeClip == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            EmptyStateCard(
                title = "CapCut & TikTok Pro Studio",
                subtitle = "Upload any HD video from your device or auto-clip a YouTube URL to edit 30–90s highlights with filters, effects, subtitles & 4K export."
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    videoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("studio_empty_upload_button")
            ) {
                Icon(Icons.Default.UploadFile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Upload Video From Device (HD)", fontWeight = FontWeight.Bold)
            }
        }
        return
    }

    var draft by remember(activeClip.id, activeClip.updatedAt) { mutableStateOf(activeClip) }
    var activeTool by remember { mutableStateOf(StudioToolTab.TRIM) }
    var isPlaying by remember { mutableStateOf(false) }
    var playheadSec by remember(activeClip.id) { mutableLongStateOf(draft.startSec) }
    var seekRequestMs by remember(activeClip.id) { mutableStateOf<Long?>(null) }
    var seekRequestSec by remember(activeClip.id) { mutableStateOf<Long?>(null) }
    var clipDropdownExpanded by remember { mutableStateOf(false) }

    val isLocalVideo = draft.sourceUrl.startsWith("content://") || draft.sourceUrl.startsWith("file://")
    val isYouTubeVideo = !isLocalVideo && draft.youtubeVideoId.isNotBlank()

    // Fallback timer only when previewing a static card without an active video engine
    LaunchedEffect(isPlaying, draft.startSec, draft.endSec, draft.playbackSpeed, isLocalVideo, isYouTubeVideo) {
        if (isPlaying && !isLocalVideo && !isYouTubeVideo) {
            while (isPlaying) {
                val stepMs = (1000.0 / draft.playbackSpeed.coerceIn(0.25, 3.0)).toLong()
                delay(stepMs)
                playheadSec = if (playheadSec >= draft.endSec) draft.startSec else playheadSec + 1L
            }
        }
    }

    val currentCueText = remember(draft.captions, playheadSec, draft.subtitlesEnabled) {
        if (!draft.subtitlesEnabled) null
        else draft.captions.firstOrNull { playheadSec in it.startSec..it.endSec }?.text
            ?: draft.captions.firstOrNull()?.text
    }

    val waveform = remember(draft.id, draft.waveformBars, draft.title) {
        draft.waveformBars.ifEmpty {
            OnDeviceSignalAnalyzer.generateSynthesizedWaveform(draft.title + draft.id)
        }
    }
    val stageRatio = when (draft.aspectRatio) {
        "16:9" -> 16f / 9f
        "1:1" -> 1f
        "4:5" -> 4f / 5f
        else -> 9f / 16f
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Action Row: Clip Picker + Direct Upload HD + Save
        item(key = "studio_header") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = ObsidianSurface,
                            border = BorderStroke(1.dp, ObsidianOutline),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { clipDropdownExpanded = true }
                        ) {
                            Text(
                                text = draft.title,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = clipDropdownExpanded,
                            onDismissRequest = { clipDropdownExpanded = false }
                        ) {
                            clips.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    onClick = {
                                        clipDropdownExpanded = false
                                        onSelectClip(item.id)
                                    }
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.65f)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("studio_upload_video_button")
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = "Upload HD Video", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Upload", color = CyberCyan, style = MaterialTheme.typography.labelLarge)
                    }

                    Button(
                        onClick = { onSaveClip(draft) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("studio_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save")
                    }
                }

                // Quick Toolbar: Ratio + CC Toggle + Smart Edit + Duplicate + Cover Grab
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("9:16", "4:5", "1:1", "16:9").forEach { ratio ->
                        val selected = draft.aspectRatio == ratio
                        Surface(
                            color = if (selected) CyberCyan.copy(alpha = 0.2f) else ObsidianSurface,
                            border = BorderStroke(1.dp, if (selected) CyberCyan else ObsidianOutline),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.clickable { draft = draft.copy(aspectRatio = ratio) }
                        ) {
                            Text(
                                text = ratio,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) CyberCyan else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Surface(
                        color = if (draft.subtitlesEnabled) EmeraldSuccess.copy(alpha = 0.16f) else ObsidianSurface,
                        border = BorderStroke(1.dp, if (draft.subtitlesEnabled) EmeraldSuccess else ObsidianOutline),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable {
                                val updated = draft.copy(subtitlesEnabled = !draft.subtitlesEnabled)
                                draft = updated
                                onSaveClip(updated)
                            }
                            .testTag("studio_quick_cc_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (draft.subtitlesEnabled) Icons.Default.ClosedCaption else Icons.Default.ClosedCaptionDisabled,
                                contentDescription = "Toggle Captions",
                                tint = if (draft.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (draft.subtitlesEnabled) "CC ON" else "CC OFF",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (draft.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        color = VioletPulse.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, VioletPulse),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable(enabled = !isGeneratingSmartEdit) {
                                onAiSmartEdit(draft) { updated -> draft = updated }
                            }
                            .testTag("studio_ai_smart_edit_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isGeneratingSmartEdit) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = CyberCyan)
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(15.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isGeneratingSmartEdit) "Tuning..." else "Smart Edit",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                    }

                    Surface(
                        color = ObsidianSurface,
                        border = BorderStroke(1.dp, ObsidianOutline),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clickable { onDuplicateClip(draft) }
                            .testTag("studio_duplicate_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate Clip", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Duplicate", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    if (isLocalVideo) {
                        Surface(
                            color = ObsidianSurface,
                            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clickable {
                                    onCaptureCoverFrame(draft, playheadSec) { updated -> draft = updated }
                                }
                                .testTag("studio_grab_frame_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Capture Frame Cover", tint = CyberCyan, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Grab Cover", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
                            }
                        }
                    }
                }
            }
        }

        // HD Preview Stage
        item(key = "studio_stage") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isLocalVideo) {
                    Box(
                        modifier = Modifier
                            .height(290.dp)
                            .aspectRatio(stageRatio)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        LocalVideoPlayer(
                            videoUri = draft.sourceUrl,
                            isPlaying = isPlaying,
                            playbackSpeed = draft.playbackSpeed.toFloat(),
                            volume = draft.voiceVolume.toFloat(),
                            clipStartSec = draft.startSec,
                            clipEndSec = draft.endSec,
                            zoomScale = draft.zoomScale.toFloat(),
                            rotationDeg = draft.rotationDeg,
                            flipHorizontal = draft.flipHorizontal,
                            filterPreset = FilterPreset.fromRaw(draft.filterPreset),
                            videoEffect = VideoEffect.fromRaw(draft.videoEffect),
                            warmth = draft.warmth.toFloat(),
                            brightness = draft.brightness.toFloat(),
                            vignette = draft.vignette.toFloat(),
                            seekPositionMs = seekRequestMs,
                            onPositionUpdateSec = { sec -> playheadSec = sec },
                            modifier = Modifier.fillMaxSize()
                        )
                        if (draft.overlayText.isNotBlank()) {
                            Surface(
                                color = CoralPrimary.copy(alpha = 0.9f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 12.dp, start = 12.dp, end = 12.dp)
                            ) {
                                Text(
                                    text = draft.overlayText.uppercase(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (draft.subtitlesEnabled && !currentCueText.isNullOrBlank()) {
                            val pos = CaptionPosition.fromRaw(draft.captionPosition)
                            val align = when (pos) {
                                CaptionPosition.TOP -> Alignment.TopCenter
                                CaptionPosition.CENTER -> Alignment.Center
                                CaptionPosition.BOTTOM -> Alignment.BottomCenter
                            }
                            SubtitleCaptionOverlay(
                                text = currentCueText,
                                style = SubtitleStyle.fromRaw(draft.subtitleStyle),
                                scale = draft.captionScale.toFloat(),
                                modifier = Modifier
                                    .align(align)
                                    .padding(
                                        top = if (pos == CaptionPosition.TOP) 48.dp else 12.dp,
                                        bottom = 44.dp,
                                        start = 10.dp,
                                        end = 10.dp
                                    )
                            )
                        }
                    }
                } else if (isYouTubeVideo) {
                    Box(
                        modifier = Modifier
                            .height(290.dp)
                            .aspectRatio(stageRatio)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        YouTubeClipSegmentPlayer(
                            youtubeVideoId = draft.youtubeVideoId,
                            sourceUrl = draft.sourceUrl,
                            startSec = draft.startSec,
                            endSec = draft.endSec,
                            isPlaying = isPlaying,
                            playbackSpeed = draft.playbackSpeed.toFloat(),
                            filterPreset = FilterPreset.fromRaw(draft.filterPreset),
                            warmth = draft.warmth.toFloat(),
                            vignette = draft.vignette.toFloat(),
                            seekRequestSec = seekRequestSec,
                            onPositionUpdateSec = { sec -> playheadSec = sec },
                            modifier = Modifier.fillMaxSize(),
                            fallbackContent = {
                                ClipThumbnailTemplateCard(
                                    clip = draft,
                                    activeCaptionText = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        )
                        if (draft.overlayText.isNotBlank()) {
                            Surface(
                                color = CoralPrimary.copy(alpha = 0.9f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 12.dp, start = 12.dp, end = 12.dp)
                            ) {
                                Text(
                                    text = draft.overlayText.uppercase(),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        if (draft.subtitlesEnabled && !currentCueText.isNullOrBlank()) {
                            val pos = CaptionPosition.fromRaw(draft.captionPosition)
                            val align = when (pos) {
                                CaptionPosition.TOP -> Alignment.TopCenter
                                CaptionPosition.CENTER -> Alignment.Center
                                CaptionPosition.BOTTOM -> Alignment.BottomCenter
                            }
                            SubtitleCaptionOverlay(
                                text = currentCueText,
                                style = SubtitleStyle.fromRaw(draft.subtitleStyle),
                                scale = draft.captionScale.toFloat(),
                                modifier = Modifier
                                    .align(align)
                                    .padding(
                                        top = if (pos == CaptionPosition.TOP) 48.dp else 12.dp,
                                        bottom = 44.dp,
                                        start = 10.dp,
                                        end = 10.dp
                                    )
                            )
                        }
                    }
                } else {
                    ClipThumbnailTemplateCard(
                        clip = draft,
                        activeCaptionText = currentCueText,
                        modifier = Modifier
                            .height(290.dp)
                            .aspectRatio(stageRatio)
                    )
                }

                // HD Quality + Clip Duration Badge
                val clipLengthSec = (draft.endSec - draft.startSec).coerceAtLeast(1L)
                Surface(
                    color = ObsidianBg.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "${draft.exportResolution} • ${draft.exportFps}fps • ${clipLengthSec}s",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Play/Pause Floating Button
                Surface(
                    shape = CircleShape,
                    color = ObsidianBg.copy(alpha = 0.76f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .size(48.dp)
                ) {
                    IconButton(onClick = { isPlaying = !isPlaying }) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause preview" else "Play preview",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Multi-Track CapCut/TikTok Timeline Scrubber + Live Audio Waveform Visualizer
        item(key = "studio_timeline") {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Playhead ${formatSec(playheadSec)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan
                        )
                        Text(
                            text = "Clip ${formatSec(draft.startSec)} – ${formatSec(draft.endSec)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Audio Energy Waveform Strip
                    val progressFraction = if (draft.endSec > draft.startSec) {
                        ((playheadSec - draft.startSec).toFloat() / (draft.endSec - draft.startSec)).coerceIn(0f, 1f)
                    } else 0f

                    WaveformVisualizerStrip(
                        bars = waveform,
                        progressFraction = progressFraction,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                    )

                    Slider(
                        value = playheadSec.toFloat().coerceIn(draft.startSec.toFloat(), draft.endSec.toFloat().coerceAtLeast(draft.startSec + 1f)),
                        onValueChange = { sec ->
                            val newSec = sec.toLong()
                            playheadSec = newSec
                            if (isLocalVideo) seekRequestMs = newSec * 1000L
                            if (isYouTubeVideo) seekRequestSec = newSec
                        },
                        valueRange = draft.startSec.toFloat()..draft.endSec.toFloat().coerceAtLeast(draft.startSec + 1f),
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = CoralPrimary)
                    )

                    TimelineTrackStrip(
                        label = "VIDEO",
                        detail = "${draft.aspectRatio} • ${draft.playbackSpeed}x • ${FilterPreset.fromRaw(draft.filterPreset).label} • FX: ${VideoEffect.fromRaw(draft.videoEffect).label}",
                        accent = CoralPrimary
                    )
                    TimelineTrackStrip(
                        label = "CC",
                        detail = if (draft.subtitlesEnabled) "${draft.captions.size} cues • ${SubtitleStyle.fromRaw(draft.subtitleStyle).label}" else "Subtitles removed (tap CC ON to restore)",
                        accent = if (draft.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TimelineTrackStrip(
                        label = "AUDIO",
                        detail = "${MusicTrack.fromRaw(draft.musicTrack).label} • Voice ${(draft.voiceVolume * 100).toInt()}%",
                        accent = VioletPulse
                    )
                }
            }
        }

        // Advanced CapCut Tool Selector Dock
        item(key = "studio_tool_dock") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StudioToolTab.entries.forEach { tab ->
                    val selected = activeTool == tab
                    Surface(
                        color = if (selected) CoralPrimary else ObsidianSurface,
                        border = BorderStroke(1.dp, if (selected) CoralPrimary else ObsidianOutline),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .clickable { activeTool = tab }
                            .testTag("studio_tab_${tab.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = null,
                                tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Active Tool Panel
        item(key = "studio_active_panel") {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(16.dp)) {
                    when (activeTool) {
                        StudioToolTab.TRIM -> StudioTrimSpeedPanel(
                            draft = draft,
                            playheadSec = playheadSec,
                            onSplitAtPlayhead = {
                                onSplitClip(draft, playheadSec)
                                draft = draft.copy(endSec = playheadSec.coerceAtLeast(draft.startSec + 2L))
                            },
                            onUpdate = { draft = it }
                        )
                        StudioToolTab.FILTERS -> StudioFiltersPanel(draft = draft, onUpdate = { draft = it })
                        StudioToolTab.EFFECTS -> StudioEffectsPanel(draft = draft, onUpdate = { draft = it })
                        StudioToolTab.SUBTITLES -> StudioSubtitlesPanel(
                            draft = draft,
                            isGeneratingCaptions = isGeneratingCaptions,
                            onUpdate = { draft = it },
                            onRegenerateCaptions = { onRegenerateCaptions(draft) },
                            onSyncScript = { script ->
                                onSyncScript(draft, script) { updated -> draft = updated }
                            }
                        )
                        StudioToolTab.AUDIO -> StudioAudioPanel(draft = draft, onUpdate = { draft = it })
                        StudioToolTab.TEMPLATES -> StudioTemplatesSeoPanel(
                            draft = draft,
                            isGeneratingSeo = isGeneratingSeo,
                            isLocalVideo = isLocalVideo,
                            onUpdate = { draft = it },
                            onCaptureCover = {
                                onCaptureCoverFrame(draft, playheadSec) { updated -> draft = updated }
                            },
                            onGenerateSeo = {
                                onGenerateSeo(
                                    draft,
                                    SocialPlatform.fromRaw(draft.optimizedPlatform)
                                ) { updated -> draft = updated }
                            }
                        )
                        StudioToolTab.EXPORT -> StudioExportPanel(
                            draft = draft,
                            exportStatus = exportStatus,
                            onUpdate = { draft = it },
                            onExportClip = { onExportClip(draft) }
                        )
                    }
                }
            }
        }

        item(key = "studio_bottom_spacer") {
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun WaveformVisualizerStrip(
    bars: List<Float>,
    progressFraction: Float,
    modifier: Modifier = Modifier
) {
    Surface(
        color = ObsidianBg,
        border = BorderStroke(1.dp, ObsidianOutline),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            if (bars.isEmpty()) return@Canvas
            val count = bars.size
            val slotW = size.width / count
            val barW = (slotW * 0.62f).coerceAtLeast(2f)
            val centerY = size.height / 2f
            bars.forEachIndexed { idx, amp ->
                val norm = amp.coerceIn(0.12f, 1.0f)
                val barH = (size.height * norm).coerceAtLeast(4f)
                val x = idx * slotW + (slotW - barW) / 2f
                val fraction = idx.toFloat() / count
                val color = if (fraction <= progressFraction) CoralPrimary else CyberCyan.copy(alpha = 0.5f)
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, centerY - barH / 2f),
                    size = Size(barW, barH),
                    cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                )
            }
        }
    }
}

@Composable
private fun TimelineTrackStrip(label: String, detail: String, accent: Color) {
    Surface(
        color = ObsidianSurfaceVariant,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = accent.copy(alpha = 0.2f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = accent,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
