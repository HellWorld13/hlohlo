package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.UserProfile
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse
import com.example.ui.viewmodel.SuperAiStatus
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SuperAiAutopilotPanel(
    userProfile: UserProfile,
    superAiStatus: SuperAiStatus,
    libraryClippedCount: Int,
    onToggleSuperAi: (
        enabled: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) -> Unit,
    onRunSuperAiNow: (
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) -> Unit,
    onSavePreferences: (
        active: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) -> Unit,
    onDismissStatus: () -> Unit
) {
    var nicheText by remember(userProfile.superAiNiche) {
        mutableStateOf(userProfile.superAiNiche.ifBlank { "Trending & Viral" })
    }
    var channelText by remember(userProfile.superAiChannel) {
        mutableStateOf(userProfile.superAiChannel)
    }
    var autoPostNow by remember(userProfile.superAiAutoPostNow) {
        mutableStateOf(userProfile.superAiAutoPostNow)
    }
    val postingTimes = remember(userProfile.superAiPostingTimes) {
        mutableStateListOf<String>().apply {
            addAll(
                userProfile.superAiPostingTimes.ifEmpty {
                    listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM")
                }
            )
        }
    }
    var optionsExpanded by remember { mutableStateOf(true) }
    var showTimePickerDialog by remember { mutableStateOf(false) }

    val isRunning = superAiStatus is SuperAiStatus.Running
    val presetNiches = listOf(
        "Trending & Viral",
        "Tech & AI",
        "Podcasts",
        "Finance & Business",
        "Fitness",
        "Gaming",
        "Comedy"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(
            width = 1.5.dp,
            brush = Brush.horizontalGradient(
                colors = if (userProfile.superAiActive || isRunning) {
                    listOf(CoralPrimary, VioletPulse, CyberCyan)
                } else {
                    listOf(VioletPulse.copy(alpha = 0.65f), CyberCyan.copy(alpha = 0.65f))
                }
            )
        ),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row + One-Tap Autonomous Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                Brush.linearGradient(listOf(CoralPrimary, VioletPulse)),
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = "Super AI",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Auto Clipping Super AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = if (userProfile.superAiActive) EmeraldSuccess.copy(alpha = 0.18f) else CyberCyan.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (userProfile.superAiActive) "ON" else "AUTO",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (userProfile.superAiActive) EmeraldSuccess else CyberCyan,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Keyless Discovery -> 10+ clips (30-90s) -> Pro Edit -> Library & Auto-Post",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Switch(
                    checked = userProfile.superAiActive,
                    enabled = !isRunning,
                    onCheckedChange = { turnedOn ->
                        onToggleSuperAi(
                            turnedOn,
                            nicheText,
                            channelText,
                            autoPostNow,
                            postingTimes.toList()
                        )
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = CoralPrimary
                    ),
                    modifier = Modifier.testTag("super_ai_toggle_switch")
                )
            }

            // Library Clip Target Status Pill + Expand/Collapse Options
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (libraryClippedCount >= 10) EmeraldSuccess.copy(alpha = 0.14f) else AmberViral.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "Library Clipped Videos: $libraryClippedCount / 10+ min",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (libraryClippedCount >= 10) EmeraldSuccess else AmberViral,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                TextButton(
                    onClick = { optionsExpanded = !optionsExpanded },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (optionsExpanded) "Hide Filters" else "Channel & Times",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan
                    )
                    Icon(
                        imageVector = if (optionsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Optional Video Type, Specific YT Channel & Custom Posting Times
            AnimatedVisibility(visible = optionsExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Video Type / Niche (Optional)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            presetNiches.forEach { preset ->
                                val selected = nicheText.equals(preset, ignoreCase = true)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        nicheText = preset
                                        onSavePreferences(
                                            userProfile.superAiActive,
                                            preset,
                                            channelText,
                                            autoPostNow,
                                            postingTimes.toList()
                                        )
                                    },
                                    label = { Text(preset) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = VioletPulse.copy(alpha = 0.25f),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        OutlinedTextField(
                            value = nicheText,
                            onValueChange = { nicheText = it },
                            label = { Text("Custom Video Topic / Niche") },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = CyberCyan)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = ObsidianOutline,
                                focusedContainerColor = ObsidianBg,
                                unfocusedContainerColor = ObsidianBg
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("super_ai_niche_input")
                        )
                    }

                    OutlinedTextField(
                        value = channelText,
                        onValueChange = { channelText = it },
                        label = { Text("Specific YouTube Channel (Optional)") },
                        placeholder = { Text("e.g. @MKBHD, @hubermanlab, MrBeast") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CoralPrimary,
                            unfocusedBorderColor = ObsidianOutline,
                            focusedContainerColor = ObsidianBg,
                            unfocusedContainerColor = ObsidianBg
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("super_ai_channel_input")
                    )

                    // Post Automatically vs Schedule on Custom Times
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Publishing Mode",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = !autoPostNow,
                                onClick = {
                                    autoPostNow = false
                                    onSavePreferences(
                                        userProfile.superAiActive,
                                        nicheText,
                                        channelText,
                                        false,
                                        postingTimes.toList()
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                label = { Text("Schedule Times") },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = autoPostNow,
                                onClick = {
                                    autoPostNow = true
                                    onSavePreferences(
                                        userProfile.superAiActive,
                                        nicheText,
                                        channelText,
                                        true,
                                        postingTimes.toList()
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                label = { Text("Post Automatically") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        if (!autoPostNow) {
                            Surface(
                                color = ObsidianBg,
                                border = BorderStroke(1.dp, ObsidianOutline),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Auto-Schedule Times (${postingTimes.size})",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = CyberCyan
                                        )
                                        OutlinedButton(
                                            onClick = { showTimePickerDialog = true },
                                            shape = RoundedCornerShape(50),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("super_ai_add_time_button")
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Add time", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Add Time", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }

                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        postingTimes.forEach { time ->
                                            Surface(
                                                color = ObsidianSurfaceVariant,
                                                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
                                                shape = RoundedCornerShape(50)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                                                ) {
                                                    Text(
                                                        text = time,
                                                        style = MaterialTheme.typography.labelMedium,
                                                        color = Color.White
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    IconButton(
                                                        onClick = {
                                                            postingTimes.remove(time)
                                                            onSavePreferences(
                                                                userProfile.superAiActive,
                                                                nicheText,
                                                                channelText,
                                                                autoPostNow,
                                                                postingTimes.toList()
                                                            )
                                                        },
                                                        modifier = Modifier.size(22.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Close,
                                                            contentDescription = "Remove $time",
                                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.size(14.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // One-Click Launch Super AI Autopilot Button
            Button(
                onClick = {
                    onRunSuperAiNow(
                        nicheText,
                        channelText,
                        autoPostNow,
                        postingTimes.toList()
                    )
                },
                enabled = !isRunning,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VioletPulse,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("super_ai_run_button")
            ) {
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Super AI Running...")
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (userProfile.superAiActive) {
                            "Run Super AI Batch Now (10+ Clips • 30-90s)"
                        } else {
                            "Activate & Run Super AI Autopilot (10+ Clips)"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Live Super AI Execution Feedback
            AnimatedVisibility(visible = superAiStatus !is SuperAiStatus.Idle) {
                when (superAiStatus) {
                    is SuperAiStatus.Running -> {
                        Surface(
                            color = CyberCyan.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = CyberCyan,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = superAiStatus.stepMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberCyan
                                )
                            }
                        }
                    }
                    is SuperAiStatus.Success -> {
                        Surface(
                            color = EmeraldSuccess.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.45f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onDismissStatus() }
                        ) {
                            Text(
                                text = "Super AI created ${superAiStatus.clipsCreated} pro-edited clips (30-90s) in Library and ${if (superAiStatus.postedImmediately) "auto-posted" else "scheduled"} ${superAiStatus.postsQueued} posts! (${superAiStatus.summary})",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldSuccess,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                    is SuperAiStatus.Error -> {
                        Surface(
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onDismissStatus() }
                        ) {
                            Text(
                                text = superAiStatus.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                    SuperAiStatus.Idle -> {}
                }
            }
        }
    }

    if (showTimePickerDialog) {
        val pickerState = rememberTimePickerState(initialHour = 19, initialMinute = 30, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showTimePickerDialog = false },
            title = { Text("Add Auto-Schedule Time") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    TimePicker(state = pickerState)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val formatted = formatHourMinuteAmPm(pickerState.hour, pickerState.minute)
                        if (!postingTimes.contains(formatted)) {
                            postingTimes.add(formatted)
                            onSavePreferences(
                                userProfile.superAiActive,
                                nicheText,
                                channelText,
                                autoPostNow,
                                postingTimes.toList()
                            )
                        }
                        showTimePickerDialog = false
                    }
                ) {
                    Text("Add Time")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePickerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun formatHourMinuteAmPm(hour24: Int, minute: Int): String {
    val amPm = if (hour24 >= 12) "PM" else "AM"
    val hour12 = when {
        hour24 == 0 -> 12
        hour24 > 12 -> hour24 - 12
        else -> hour24
    }
    return String.format(Locale.US, "%02d:%02d %s", hour12, minute, amPm)
}
