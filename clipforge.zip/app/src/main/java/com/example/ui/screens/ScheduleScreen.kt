package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PostStatus
import com.example.data.model.ScheduledPostDoc
import com.example.data.model.SocialAccountDoc
import com.example.data.model.SocialPlatform
import com.example.data.model.UiState
import com.example.data.model.ViralClipDoc
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.PlatformChipBadge
import com.example.ui.components.formatCompactCount
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse

private data class PeakSlot(
    val label: String,
    val peakScore: Long,
    val offsetHours: Long,
    val reason: String
)

@Composable
fun ScheduleScreen(
    clipsState: UiState<List<ViralClipDoc>>,
    accountsState: UiState<List<SocialAccountDoc>>,
    postsState: UiState<List<ScheduledPostDoc>>,
    isGeneratingSeo: Boolean,
    preselectedClipId: String?,
    onConnectAccount: (SocialPlatform, String, Boolean, Boolean, Long) -> Unit,
    onGenerateSeo: (ViralClipDoc, SocialPlatform, (ViralClipDoc) -> Unit) -> Unit,
    onSchedulePost: (
        clip: ViralClipDoc,
        platforms: List<SocialPlatform>,
        seoTitle: String,
        seoDescription: String,
        seoTags: List<String>,
        scheduledEpochMs: Long,
        scheduledLabel: String,
        peakScore: Long,
        publishImmediately: Boolean
    ) -> Unit,
    onMarkPublished: (ScheduledPostDoc) -> Unit,
    onDeletePost: (String) -> Unit
) {
    val context = LocalContext.current
    val clips = (clipsState as? UiState.Success)?.data.orEmpty()
    val accounts = (accountsState as? UiState.Success)?.data.orEmpty()
    val posts = (postsState as? UiState.Success)?.data.orEmpty()

    var editingAccountPlatform by remember { mutableStateOf<SocialPlatform?>(null) }

    val selectedClip = remember(clips, preselectedClipId) {
        clips.firstOrNull { it.id == preselectedClipId } ?: clips.firstOrNull()
    }
    var activeClipId by remember(selectedClip?.id) { mutableStateOf(selectedClip?.id.orEmpty()) }
    val currentClip = remember(clips, activeClipId, selectedClip) {
        clips.firstOrNull { it.id == activeClipId } ?: selectedClip
    }
    val accountsByPlatform = remember(accounts) {
        accounts.associateBy { it.platform }
    }

    val selectedPlatforms = remember {
        mutableStateListOf(SocialPlatform.TIKTOK, SocialPlatform.YOUTUBE_SHORTS)
    }
    var seoTitle by remember(currentClip?.id) {
        mutableStateOf(currentClip?.seoTitle?.ifBlank { currentClip.title }.orEmpty())
    }
    var seoDescription by remember(currentClip?.id) {
        mutableStateOf(currentClip?.seoDescription.orEmpty())
    }
    var seoTagsText by remember(currentClip?.id) {
        mutableStateOf(currentClip?.seoTags?.joinToString(" ").orEmpty())
    }
    var clipDropdownOpen by remember { mutableStateOf(false) }

    val peakSlots = remember {
        listOf(
            PeakSlot("Today • 6:30 PM", 96L, 4L, "Peak evening scroll surge"),
            PeakSlot("Tomorrow • 11:30 AM", 91L, 18L, "Lunch break discovery spike"),
            PeakSlot("Thu • 8:00 PM", 94L, 36L, "Highest multi-platform retention"),
            PeakSlot("Sat • 10:15 AM", 89L, 72L, "Weekend creator binge window")
        )
    }
    var selectedSlotIndex by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Connected Social Accounts Hub
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Connected Social Channels", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Auto-optimize uploads per platform spec",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    val connectedCount = accounts.count { it.connected }
                    Surface(
                        color = CyberCyan.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "$connectedCount/${SocialPlatform.entries.size} Linked",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SocialPlatform.entries.forEach { platform ->
                        val doc = accountsByPlatform[platform.name]
                        val isConnected = doc?.connected == true
                        Card(
                            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                            border = BorderStroke(
                                1.dp,
                                if (isConnected) EmeraldSuccess.copy(alpha = 0.6f) else ObsidianOutline
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .width(172.dp)
                                .clickable { editingAccountPlatform = platform }
                                .testTag("social_account_card_${platform.name.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    PlatformChipBadge(platform = platform)
                                    Icon(
                                        imageVector = if (isConnected) Icons.Default.CheckCircle else Icons.Default.AddLink,
                                        contentDescription = null,
                                        tint = if (isConnected) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Text(
                                    text = if (isConnected) doc?.handle.orEmpty() else "Not Connected",
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (isConnected) {
                                        "${formatCompactCount(doc?.followersCount ?: 0L)} followers • Auto-Opt"
                                    } else {
                                        "Tap to connect ${platform.shortLabel}"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isConnected) CyberCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Multi-Platform Composer + Peak Audience Timing
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Multi-Platform Post & Peak Scheduler", style = MaterialTheme.typography.titleLarge)

                    if (currentClip == null) {
                        EmptyStateCard(
                            title = "Create a Clip First",
                            subtitle = "Generate a clip in Clipper or upload one in Library to schedule it across your social channels."
                        )
                    } else {
                        // Clip Picker
                        Box {
                            Surface(
                                color = ObsidianSurfaceVariant,
                                border = BorderStroke(1.dp, ObsidianOutline),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { clipDropdownOpen = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Selected Clip", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                                        Text(currentClip.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text("Change", style = MaterialTheme.typography.labelLarge, color = CoralPrimary)
                                }
                            }
                            DropdownMenu(
                                expanded = clipDropdownOpen,
                                onDismissRequest = { clipDropdownOpen = false }
                            ) {
                                clips.forEach { clip ->
                                    DropdownMenuItem(
                                        text = { Text(clip.title) },
                                        onClick = {
                                            activeClipId = clip.id
                                            clipDropdownOpen = false
                                        }
                                    )
                                }
                            }
                        }

                        // Platform Multi-Select + Per-Platform Auto-Optimization Specs
                        Text("Target Platforms (Auto-Optimized)", style = MaterialTheme.typography.titleSmall)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SocialPlatform.entries.forEach { platform ->
                                val selected = selectedPlatforms.contains(platform)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        if (selected && selectedPlatforms.size > 1) {
                                            selectedPlatforms.remove(platform)
                                        } else if (!selected) {
                                            selectedPlatforms.add(platform)
                                        }
                                    },
                                    label = { Text(platform.shortLabel) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                                        selectedLabelColor = CoralPrimary
                                    )
                                )
                            }
                        }

                        Surface(
                            color = ObsidianSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                selectedPlatforms.forEach { p ->
                                    Text(
                                        text = "• ${p.label}: ${p.optimizationSpec}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberCyan
                                    )
                                }
                            }
                        }

                        // AI SEO Generator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AI SEO Title & Description", style = MaterialTheme.typography.titleSmall)
                            OutlinedButton(
                                onClick = {
                                    onGenerateSeo(
                                        currentClip,
                                        selectedPlatforms.firstOrNull() ?: SocialPlatform.TIKTOK
                                    ) { updated ->
                                        seoTitle = updated.seoTitle
                                        seoDescription = updated.seoDescription
                                        seoTagsText = updated.seoTags.joinToString(" ")
                                    }
                                },
                                enabled = !isGeneratingSeo,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                if (isGeneratingSeo) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text("Generate SEO", color = CyberCyan)
                            }
                        }

                        OutlinedTextField(
                            value = seoTitle,
                            onValueChange = { seoTitle = it },
                            label = { Text("SEO Title") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = seoDescription,
                            onValueChange = { seoDescription = it },
                            label = { Text("SEO Description") },
                            minLines = 2,
                            maxLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = seoTagsText,
                            onValueChange = { seoTagsText = it },
                            label = { Text("Hashtags (space separated)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Built-in Peak Audience Activity Times
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = AmberViral, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Peak Audience Activity Windows", style = MaterialTheme.typography.titleSmall)
                        }
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            peakSlots.forEachIndexed { idx, slot ->
                                val selected = idx == selectedSlotIndex
                                Surface(
                                    color = if (selected) CyberCyan.copy(alpha = 0.16f) else ObsidianSurfaceVariant,
                                    border = BorderStroke(1.dp, if (selected) CyberCyan else ObsidianOutline),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.clickable { selectedSlotIndex = idx }
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = slot.label,
                                            style = MaterialTheme.typography.labelLarge,
                                            color = if (selected) CyberCyan else Color.White
                                        )
                                        Text(
                                            text = "${slot.peakScore}% Audience Active",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AmberViral
                                        )
                                        Text(
                                            text = slot.reason,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        // Action Buttons: Schedule at Peak Time OR Publish Now
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val chosenSlot = peakSlots[selectedSlotIndex]
                            val parsedTags = seoTagsText.split(" ", ",").map { it.trim() }.filter { it.isNotEmpty() }

                            Button(
                                onClick = {
                                    onSchedulePost(
                                        currentClip,
                                        selectedPlatforms.toList(),
                                        seoTitle,
                                        seoDescription,
                                        parsedTags,
                                        System.currentTimeMillis() + chosenSlot.offsetHours * 3_600_000L,
                                        chosenSlot.label,
                                        chosenSlot.peakScore,
                                        false
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("schedule_peak_button")
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Schedule Peak")
                            }

                            Button(
                                onClick = {
                                    onSchedulePost(
                                        currentClip,
                                        selectedPlatforms.toList(),
                                        seoTitle,
                                        seoDescription,
                                        parsedTags,
                                        System.currentTimeMillis(),
                                        "Published Now",
                                        95L,
                                        true
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("publish_now_button")
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Post Now")
                            }
                        }
                    }
                }
            }
        }

        // 3. Scheduled & Published Queue
        item {
            Text("Publishing Queue (${posts.size})", style = MaterialTheme.typography.titleLarge)
        }

        if (posts.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Queue is Empty",
                    subtitle = "Schedule a clip using the peak audience timing selector above to automate your multi-platform drops."
                )
            }
        } else {
            items(posts, key = { it.id }) { post ->
                val status = PostStatus.fromRaw(post.status)
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(1.dp, ObsidianOutline),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (status == PostStatus.PUBLISHED) EmeraldSuccess.copy(alpha = 0.18f) else CyberCyan.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "${status.label.uppercase()} • ${post.scheduledLabel}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (status == PostStatus.PUBLISHED) EmeraldSuccess else CyberCyan,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Row {
                                IconButton(
                                    onClick = {
                                        val shareText = "${post.seoTitle}\n\n${post.seoDescription}\n\n${post.seoTags.joinToString(" ")}"
                                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                            putExtra(Intent.EXTRA_TEXT, shareText)
                                            type = "text/plain"
                                        }
                                        runCatching {
                                            context.startActivity(Intent.createChooser(sendIntent, "Share Optimized Clip Copy"))
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Share post copy", tint = CyberCyan)
                                }
                                IconButton(onClick = { onDeletePost(post.id) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete scheduled post", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Text(post.seoTitle, style = MaterialTheme.typography.titleMedium)
                        if (post.seoDescription.isNotBlank()) {
                            Text(
                                text = post.seoDescription,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            post.platforms.forEach { raw ->
                                PlatformChipBadge(platform = SocialPlatform.fromRaw(raw))
                            }
                        }

                        if (post.optimizationSummary.isNotBlank()) {
                            Text(
                                text = "Auto-Optimized: ${post.optimizationSummary}",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberViral
                            )
                        }

                        if (status != PostStatus.PUBLISHED) {
                            OutlinedButton(
                                onClick = { onMarkPublished(post) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Publish & Mark Live Now")
                            }
                        }
                    }
                }
            }
        }
    }

    // Connect Social Account Dialog
    editingAccountPlatform?.let { platform ->
        val existing = accountsByPlatform[platform.name]
        var handle by remember(platform) { mutableStateOf(existing?.handle?.ifBlank { "@clipforge.creator" } ?: "@clipforge.creator") }
        var followersText by remember(platform) { mutableStateOf((existing?.followersCount ?: 12500L).toString()) }
        var autoOpt by remember(platform) { mutableStateOf(existing?.autoOptimize ?: true) }
        var isConnected by remember(platform) { mutableStateOf(existing?.connected ?: true) }

        AlertDialog(
            onDismissRequest = { editingAccountPlatform = null },
            title = { Text("Configure ${platform.label}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(platform.optimizationSpec, style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    OutlinedTextField(
                        value = handle,
                        onValueChange = { handle = it },
                        label = { Text("Channel / Account Handle") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = followersText,
                        onValueChange = { followersText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Followers / Subscribers") },
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Auto-Optimize Exports", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = autoOpt, onCheckedChange = { autoOpt = it })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Channel Connected", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = isConnected, onCheckedChange = { isConnected = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onConnectAccount(
                            platform,
                            handle.ifBlank { "@creator" },
                            isConnected,
                            autoOpt,
                            followersText.toLongOrNull() ?: 0L
                        )
                        editingAccountPlatform = null
                    }
                ) {
                    Text("Save Channel")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingAccountPlatform = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
