package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Creator Pro Palette
val ObsidianBg = Color(0xFF0D0E14)
val ObsidianSurface = Color(0xFF141722)
val ObsidianSurfaceVariant = Color(0xFF1D2130)
val ObsidianSurfaceHigh = Color(0xFF252A3D)
val ObsidianOutline = Color(0xFF2F364E)

val CoralPrimary = Color(0xFFFF3B6B)
val CoralContainer = Color(0xFF471224)
val OnCoral = Color(0xFFFFFFFF)

val CyberCyan = Color(0xFF00E5C8)
val CyberCyanContainer = Color(0xFF093A36)
val OnCyberCyan = Color(0xFF04201C)

val VioletPulse = Color(0xFF8B5CF6)
val VioletContainer = Color(0xFF2C1E59)

val AmberViral = Color(0xFFFFB800)
val EmeraldSuccess = Color(0xFF10B981)
val ErrorCrimson = Color(0xFFFF5A6E)

val TextPrimary = Color(0xFFF4F6FA)
val TextSecondary = Color(0xFF9AA3B8)
val TextMuted = Color(0xFF6B748B)
