package com.example.ui.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppSettings
import com.example.data.local.AppSettingsStore
import com.example.data.media.OnDeviceSignalAnalyzer
import com.example.data.media.VideoExportEngine
import com.example.data.model.AnalyticsRecordDoc
import com.example.data.model.CaptionCue
import com.example.data.model.MediaItemDoc
import com.example.data.model.MediaSourceType
import com.example.data.model.MediaStatus
import com.example.data.model.PostStatus
import com.example.data.model.ScheduledPostDoc
import com.example.data.model.SocialAccountDoc
import com.example.data.model.SocialPlatform
import com.example.data.model.SpeedCurvePreset
import com.example.data.model.StudioTemplate
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.ViralClipDoc
import com.example.data.remote.ClipForgeAiService
import com.example.data.remote.GrowthInsightResult
import com.example.data.remote.YouTubeMetadataService
import com.example.data.repository.ClipForgeRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

sealed interface AiClipperStatus {
    data object Idle : AiClipperStatus
    data class Processing(val stepMessage: String) : AiClipperStatus
    data class Success(val generatedCount: Int, val sourceTitle: String) : AiClipperStatus
    data class Error(val message: String) : AiClipperStatus
}

sealed interface ExportStatus {
    data object Idle : ExportStatus
    data class Exporting(val progress: Int) : ExportStatus
    data class Completed(val message: String, val outputPath: String) : ExportStatus
    data class Error(val message: String) : ExportStatus
}

sealed interface SuperAiStatus {
    data object Idle : SuperAiStatus
    data class Running(val stepMessage: String) : SuperAiStatus
    data class Success(
        val clipsCreated: Int,
        val postsQueued: Int,
        val postedImmediately: Boolean,
        val summary: String
    ) : SuperAiStatus
    data class Error(val message: String) : SuperAiStatus
}

class ClipForgeViewModel(
    private val repository: ClipForgeRepository,
    private val youTubeMetadataService: YouTubeMetadataService,
    private val aiService: ClipForgeAiService,
    private val videoExportEngine: VideoExportEngine,
    private val currentUserId: String,
    private val displayName: String,
    private val settingsStore: AppSettingsStore? = null,
    private val signalAnalyzer: OnDeviceSignalAnalyzer? = null
) : ViewModel() {

    val appSettingsState: StateFlow<AppSettings> = (settingsStore?.settingsFlow ?: flowOf(AppSettings()))
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppSettings())

    val userProfileState: StateFlow<UiState<UserProfile>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile, UiState<UserProfile>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "profile")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val clipsState: StateFlow<UiState<List<ViralClipDoc>>> = repository.observeClips(currentUserId)
        .map<List<ViralClipDoc>, UiState<List<ViralClipDoc>>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "clips")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val mediaState: StateFlow<UiState<List<MediaItemDoc>>> = repository.observeMedia(currentUserId)
        .map<List<MediaItemDoc>, UiState<List<MediaItemDoc>>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "media")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val socialAccountsState: StateFlow<UiState<List<SocialAccountDoc>>> = repository.observeSocialAccounts(currentUserId)
        .map<List<SocialAccountDoc>, UiState<List<SocialAccountDoc>>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "social accounts")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val scheduledPostsState: StateFlow<UiState<List<ScheduledPostDoc>>> = repository.observeScheduledPosts(currentUserId)
        .map<List<ScheduledPostDoc>, UiState<List<ScheduledPostDoc>>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "scheduled posts")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val analyticsState: StateFlow<UiState<List<AnalyticsRecordDoc>>> = repository.observeAnalytics(currentUserId)
        .map<List<AnalyticsRecordDoc>, UiState<List<AnalyticsRecordDoc>>> { UiState.Success(it) }
        .catch { error -> emit(unwrapStreamError(error, "analytics")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _aiClipperStatus = MutableStateFlow<AiClipperStatus>(AiClipperStatus.Idle)
    val aiClipperStatus: StateFlow<AiClipperStatus> = _aiClipperStatus.asStateFlow()

    private val _superAiStatus = MutableStateFlow<SuperAiStatus>(SuperAiStatus.Idle)
    val superAiStatus: StateFlow<SuperAiStatus> = _superAiStatus.asStateFlow()

    private val _selectedStudioClipId = MutableStateFlow<String?>(null)
    val selectedStudioClipId: StateFlow<String?> = _selectedStudioClipId.asStateFlow()

    private val _exportStatus = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
    val exportStatus: StateFlow<ExportStatus> = _exportStatus.asStateFlow()

    private val _aiInsightsState = MutableStateFlow<UiState<GrowthInsightResult>?>(null)
    val aiInsightsState: StateFlow<UiState<GrowthInsightResult>?> = _aiInsightsState.asStateFlow()

    private val _seoGenerating = MutableStateFlow(false)
    val seoGenerating: StateFlow<Boolean> = _seoGenerating.asStateFlow()

    private val _captionsGenerating = MutableStateFlow(false)
    val captionsGenerating: StateFlow<Boolean> = _captionsGenerating.asStateFlow()

    private val _smartEditGenerating = MutableStateFlow(false)
    val smartEditGenerating: StateFlow<Boolean> = _smartEditGenerating.asStateFlow()

    private val _cacheSizeMb = MutableStateFlow(0.0)
    val cacheSizeMb: StateFlow<Double> = _cacheSizeMb.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private var sweepInFlight = false

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(displayName)
            refreshCacheSize()
        }
        viewModelScope.launch {
            combine(userProfileState, mediaState, clipsState) { pState, mState, cState ->
                Triple(
                    (pState as? UiState.Success)?.data?.autoDelete24hEnabled == true,
                    (mState as? UiState.Success)?.data.orEmpty(),
                    (cState as? UiState.Success)?.data.orEmpty()
                )
            }.collect { (enabled, mediaList, clipList) ->
                if (enabled) {
                    sweepExpiredItems(mediaList, clipList)
                }
            }
        }
        viewModelScope.launch {
            while (isActive) {
                delay(60_000L)
                val profile = (userProfileState.value as? UiState.Success)?.data
                if (profile?.autoDelete24hEnabled == true) {
                    val mediaList = (mediaState.value as? UiState.Success)?.data.orEmpty()
                    val clipList = (clipsState.value as? UiState.Success)?.data.orEmpty()
                    sweepExpiredItems(mediaList, clipList)
                }
            }
        }
    }

    fun refreshCacheSize() {
        viewModelScope.launch(Dispatchers.IO) {
            val sizeMb = signalAnalyzer?.getMediaCacheSizeMb() ?: 0.0
            _cacheSizeMb.value = sizeMb
        }
    }

    fun clearMediaCaches() {
        viewModelScope.launch(Dispatchers.IO) {
            val freed = signalAnalyzer?.clearMediaCaches() ?: 0L
            _cacheSizeMb.value = signalAnalyzer?.getMediaCacheSizeMb() ?: 0.0
            val freedMb = String.format(Locale.US, "%.1f", freed / (1024.0 * 1024.0))
            _snackbarMessage.value = "Cleared $freedMb MB of temporary exports & frame covers."
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun dismissSuperAiStatus() {
        _superAiStatus.value = SuperAiStatus.Idle
    }

    fun saveAppSettings(updated: AppSettings) {
        viewModelScope.launch {
            settingsStore?.updateSettings(updated)
            _snackbarMessage.value = "Settings saved • ${updated.effectiveEngineLabel()}"
        }
    }

    fun clearLocalWorkspace() {
        repository.clearLocalWorkspace()
        _selectedStudioClipId.value = null
        _exportStatus.value = ExportStatus.Idle
        _snackbarMessage.value = "Local clips and library cleared."
    }

    fun toggleAutoDelete24h(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateAutoDelete24h(enabled).onSuccess {
                _snackbarMessage.value = if (enabled) {
                    "24h Auto-Delete ON — Library items expire 24h after creation."
                } else {
                    "24h Auto-Delete OFF — Library videos are kept permanently."
                }
                if (enabled) {
                    val mediaList = (mediaState.value as? UiState.Success)?.data.orEmpty()
                    val clipList = (clipsState.value as? UiState.Success)?.data.orEmpty()
                    sweepExpiredItems(mediaList, clipList)
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed updating 24h auto-delete setting."
            }
        }
    }

    private suspend fun sweepExpiredItems(
        mediaList: List<MediaItemDoc>,
        clipList: List<ViralClipDoc>
    ) {
        if (sweepInFlight || (mediaList.isEmpty() && clipList.isEmpty())) return
        val (expiredMediaIds, expiredClipIds) = withContext(Dispatchers.Default) {
            val now = System.currentTimeMillis()
            val mIds = mediaList
                .filter { it.id.isNotBlank() && (now - it.effectiveCreatedEpochMs()) >= AUTO_DELETE_WINDOW_MS }
                .map { it.id }
            val cIds = clipList
                .filter { it.id.isNotBlank() && (now - it.effectiveCreatedEpochMs()) >= AUTO_DELETE_WINDOW_MS }
                .map { it.id }
            mIds to cIds
        }

        if (expiredMediaIds.isEmpty() && expiredClipIds.isEmpty()) return

        sweepInFlight = true
        try {
            repository.deleteExpiredMediaAndClips(expiredMediaIds, expiredClipIds).onSuccess { deleted ->
                if (deleted > 0) {
                    _snackbarMessage.value = "24h Auto-Delete removed $deleted expired item(s) from Library."
                }
            }
        } finally {
            sweepInFlight = false
        }
    }

    fun saveSuperAiSettings(
        active: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) {
        viewModelScope.launch {
            repository.updateSuperAiConfig(active, niche, channel, autoPostNow, postingTimes)
                .onFailure { err ->
                    _snackbarMessage.value = err.localizedMessage ?: "Failed saving Super AI preferences."
                }
        }
    }

    fun toggleSuperAiAndRunIfEnabled(
        enabled: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) {
        viewModelScope.launch {
            repository.updateSuperAiConfig(enabled, niche, channel, autoPostNow, postingTimes)
            if (enabled) {
                runSuperAiAutopilot(niche, channel, autoPostNow, postingTimes)
            } else {
                _superAiStatus.value = SuperAiStatus.Idle
                _snackbarMessage.value = "Auto Clipping Super AI turned OFF."
            }
        }
    }

    fun runSuperAiAutopilot(
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) {
        if (_superAiStatus.value is SuperAiStatus.Running) return
        viewModelScope.launch {
            repository.updateSuperAiConfig(true, niche, channel, autoPostNow, postingTimes)
            _superAiStatus.value = SuperAiStatus.Running("Starting API-Free Super AI discovery...")

            val existingLibraryClipCount = (mediaState.value as? UiState.Success)?.data
                ?.count { it.sourceType == MediaSourceType.CLIP.name } ?: 0
            val targetClips = maxOf(10, 10 - existingLibraryClipCount)

            val aiRes = aiService.runSuperAiAutopilot(
                niche = niche,
                specificChannel = channel,
                targetCount = targetClips,
                onProgress = { step ->
                    _superAiStatus.value = SuperAiStatus.Running(step)
                }
            )

            val superResult = aiRes.getOrElse { err ->
                _superAiStatus.value = SuperAiStatus.Error(
                    err.localizedMessage ?: "Super AI autopilot failed."
                )
                return@launch
            }

            _superAiStatus.value = SuperAiStatus.Running(
                "Storing ${superResult.clips.size} pro-edited clips in Library & ${if (autoPostNow) "auto-posting" else "scheduling"}..."
            )

            val mediaDocs = superResult.clips.map { clip ->
                val dur = (clip.endSec - clip.startSec).coerceIn(30L, 90L)
                MediaItemDoc(
                    title = clip.title,
                    sourceType = MediaSourceType.CLIP.name,
                    sourceUrl = clip.sourceUrl,
                    youtubeVideoId = clip.youtubeVideoId,
                    thumbnailUrl = clip.thumbnailUrl,
                    durationSeconds = dur,
                    aspectRatio = "9:16",
                    status = MediaStatus.EXPORTED.name,
                    createdEpochMs = clip.createdEpochMs,
                    superAiGenerated = true
                )
            }

            val connectedPlatforms = (socialAccountsState.value as? UiState.Success)?.data
                ?.filter { it.connected }
                ?.map { SocialPlatform.fromRaw(it.platform) }
                .orEmpty()

            val effectiveTimes = postingTimes.ifEmpty {
                listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM")
            }

            val saveRes = repository.saveSuperAiBatch(
                clips = superResult.clips,
                mediaItems = mediaDocs,
                scheduledPostsBuilder = { clipPairs ->
                    clipPairs.mapIndexed { idx, (clipId, clip) ->
                        val clipPlatform = SocialPlatform.fromRaw(clip.optimizedPlatform)
                        val targetPlatforms = if (connectedPlatforms.isNotEmpty()) {
                            connectedPlatforms.map { it.name }
                        } else {
                            listOf(clipPlatform.name, SocialPlatform.YOUTUBE_SHORTS.name).distinct()
                        }
                        val slot = if (autoPostNow) {
                            System.currentTimeMillis() to "Super AI • Posted Auto"
                        } else {
                            val timeLabel = effectiveTimes[idx % effectiveTimes.size]
                            val dayOffset = idx / effectiveTimes.size
                            val epoch = parseTimeLabelToFutureEpochMs(timeLabel, dayOffset)
                            val dayPrefix = when (dayOffset) {
                                0 -> "Today"
                                1 -> "Tomorrow"
                                else -> "Day +$dayOffset"
                            }
                            epoch to "Super AI • $dayPrefix $timeLabel"
                        }

                        ScheduledPostDoc(
                            clipId = clipId,
                            clipTitle = clip.title,
                            thumbnailUrl = clip.thumbnailUrl,
                            platforms = targetPlatforms,
                            seoTitle = clip.seoTitle.ifBlank { clip.title },
                            seoDescription = clip.seoDescription,
                            seoTags = clip.seoTags,
                            scheduledAtEpochMs = slot.first,
                            scheduledLabel = slot.second,
                            peakScore = clip.viralScore,
                            status = if (autoPostNow) PostStatus.PUBLISHED.name else PostStatus.SCHEDULED.name,
                            optimizationSummary = "Super AI 9:16 • ${clip.filterPreset} • ${clip.subtitleStyle}"
                        )
                    }
                },
                analyticsBuilder = { clipPairs ->
                    if (!autoPostNow) {
                        emptyList()
                    } else {
                        clipPairs.take(5).map { (clipId, clip) ->
                            AnalyticsRecordDoc(
                                clipId = clipId,
                                clipTitle = clip.title,
                                platform = clip.optimizedPlatform,
                                dayLabel = "Today",
                                views = 240L + clip.viralScore * 4L,
                                likes = 32L + clip.viralScore / 2L,
                                comments = 6L,
                                shares = 9L,
                                avgWatchSeconds = (clip.endSec - clip.startSec).coerceIn(30L, 90L),
                                retentionPercent = 81L
                            )
                        }
                    }
                }
            )

            saveRes.onSuccess { ids ->
                if (ids.isNotEmpty()) {
                    _selectedStudioClipId.value = ids.first()
                }
                _superAiStatus.value = SuperAiStatus.Success(
                    clipsCreated = superResult.clips.size,
                    postsQueued = superResult.clips.size,
                    postedImmediately = autoPostNow,
                    summary = superResult.discoveredSourcesSummary
                )
                _snackbarMessage.value = if (autoPostNow) {
                    "Super AI created ${superResult.clips.size} clips (30-90s), stored in Library & auto-posted!"
                } else {
                    "Super AI created ${superResult.clips.size} clips, stored in Library & scheduled across ${effectiveTimes.size} time slot(s)!"
                }
            }.onFailure { err ->
                _superAiStatus.value = SuperAiStatus.Error(
                    err.localizedMessage ?: "Failed saving Super AI clips."
                )
            }
        }
    }

    private fun parseTimeLabelToFutureEpochMs(timeLabel: String, dayOffset: Int): Long {
        val cal = Calendar.getInstance()
        val cleaned = timeLabel.trim().uppercase(Locale.US)
        val regex = Regex("""(\d{1,2}):(\d{2})\s*(AM|PM)?""")
        val match = regex.find(cleaned)
        if (match != null) {
            var hour = match.groupValues[1].toIntOrNull() ?: 12
            val minute = match.groupValues[2].toIntOrNull() ?: 0
            val amPm = match.groupValues[3]
            if (amPm == "PM" && hour < 12) hour += 12
            if (amPm == "AM" && hour == 12) hour = 0
            cal.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            cal.set(Calendar.MINUTE, minute.coerceIn(0, 59))
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            if (dayOffset == 0 && cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            } else if (dayOffset > 0) {
                cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            }
            return cal.timeInMillis
        }
        return System.currentTimeMillis() + ((dayOffset + 1) * 3_600_000L)
    }

    fun selectClipForStudio(clipId: String) {
        _selectedStudioClipId.value = clipId
        _exportStatus.value = ExportStatus.Idle
    }

    fun resetClipperStatus() {
        _aiClipperStatus.value = AiClipperStatus.Idle
    }

    fun resetExportStatus() {
        _exportStatus.value = ExportStatus.Idle
    }

    fun clipYouTubeVideo(
        rawUrl: String,
        targetPlatform: SocialPlatform,
        includeSubtitles: Boolean,
        clipCount: Int = 3,
        minClipSec: Long = 30L,
        maxClipSec: Long = 90L
    ) {
        viewModelScope.launch {
            _aiClipperStatus.value = AiClipperStatus.Processing("Fetching YouTube duration, chapters & transcript...")
            val metaResult = youTubeMetadataService.fetchMetadata(rawUrl)
            val meta = metaResult.getOrElse { err ->
                _aiClipperStatus.value = AiClipperStatus.Error(
                    err.localizedMessage ?: "Invalid or unavailable YouTube URL."
                )
                return@launch
            }

            val mediaDoc = MediaItemDoc(
                title = meta.title,
                sourceType = MediaSourceType.YOUTUBE.name,
                sourceUrl = meta.canonicalUrl,
                youtubeVideoId = meta.videoId,
                thumbnailUrl = meta.thumbnailUrl,
                durationSeconds = meta.durationSeconds,
                aspectRatio = "16:9",
                status = MediaStatus.PROCESSING.name
            )
            val mediaId = repository.createMediaItem(mediaDoc).getOrElse { err ->
                _aiClipperStatus.value = AiClipperStatus.Error(
                    err.localizedMessage ?: "Failed saving source video."
                )
                return@launch
            }

            val engineLabel = if (aiService.isGroqConfigured()) "Groq AI" else "Smart AI"
            _aiClipperStatus.value = AiClipperStatus.Processing(
                "$engineLabel auto-clipping $clipCount highlights (${minClipSec}–${maxClipSec}s)..."
            )
            val aiResult = aiService.analyzeVideoAndGenerateClips(
                videoTitle = meta.title,
                authorName = meta.authorName,
                sourceUrl = meta.canonicalUrl,
                youtubeVideoId = meta.videoId,
                thumbnailUrl = meta.thumbnailUrl,
                mediaId = mediaId,
                targetPlatform = targetPlatform,
                includeSubtitles = includeSubtitles,
                durationHintSec = meta.durationSeconds,
                clipCount = clipCount,
                minClipSec = minClipSec,
                maxClipSec = maxClipSec,
                description = meta.description,
                chapters = meta.chapters,
                transcriptCues = meta.transcriptCues,
                heatMarkers = meta.heatMarkers
            )

            val generatedClips = aiResult.getOrElse { err ->
                repository.updateMediaStatus(mediaId, MediaStatus.READY.name)
                _aiClipperStatus.value = AiClipperStatus.Error(
                    err.localizedMessage ?: "Highlight detection failed."
                )
                return@launch
            }

            val saveResult = repository.saveClips(generatedClips)
            saveResult.onSuccess { ids ->
                repository.updateMediaStatus(mediaId, MediaStatus.READY.name)
                if (ids.isNotEmpty()) {
                    _selectedStudioClipId.value = ids.first()
                }
                _aiClipperStatus.value = AiClipperStatus.Success(generatedClips.size, meta.title)
                _snackbarMessage.value = "Generated ${generatedClips.size} viral clips (${minClipSec}–${maxClipSec}s) from \"${meta.title.take(26)}\""
            }.onFailure { err ->
                _aiClipperStatus.value = AiClipperStatus.Error(
                    err.localizedMessage ?: "Failed saving generated clips."
                )
            }
        }
    }

    fun uploadLocalVideo(uri: Uri) {
        viewModelScope.launch {
            val meta = videoExportEngine.inspectLocalVideo(uri)
            val thumb = signalAnalyzer?.captureFrameThumbnail(uri, meta.durationSeconds / 3L, "lib").orEmpty()
            val mediaDoc = MediaItemDoc(
                title = meta.title,
                sourceType = MediaSourceType.UPLOADED.name,
                sourceUrl = uri.toString(),
                youtubeVideoId = "",
                thumbnailUrl = thumb,
                durationSeconds = meta.durationSeconds,
                aspectRatio = meta.aspectRatio,
                status = MediaStatus.READY.name
            )
            repository.createMediaItem(mediaDoc).onSuccess {
                refreshCacheSize()
                _snackbarMessage.value = "Uploaded \"${meta.title}\" (${meta.width}x${meta.height}) to Media Library."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed saving uploaded video."
            }
        }
    }

    fun uploadVideoToStudio(uri: Uri) {
        viewModelScope.launch {
            val meta = videoExportEngine.inspectLocalVideo(uri)
            val settings = appSettingsState.value
            val coverThumb = signalAnalyzer?.captureFrameThumbnail(uri, (meta.durationSeconds / 4L).coerceAtLeast(0L), "studio").orEmpty()

            val mediaDoc = MediaItemDoc(
                title = meta.title,
                sourceType = MediaSourceType.UPLOADED.name,
                sourceUrl = uri.toString(),
                youtubeVideoId = "",
                thumbnailUrl = coverThumb,
                durationSeconds = meta.durationSeconds,
                aspectRatio = meta.aspectRatio,
                status = MediaStatus.READY.name
            )
            val mediaId = repository.createMediaItem(mediaDoc).getOrElse { "" }
            val endSec = meta.durationSeconds.coerceAtLeast(5L)
            val starterWaveform = OnDeviceSignalAnalyzer.generateSynthesizedWaveform(meta.title)

            val initialClip = ViralClipDoc(
                mediaId = mediaId,
                sourceUrl = uri.toString(),
                thumbnailUrl = coverThumb,
                title = meta.title,
                hook = "HD Studio Project (${meta.width}x${meta.height})",
                viralScore = 90L,
                startSec = 0L,
                endSec = endSec,
                subtitlesEnabled = settings.autoCaptionsOnUpload,
                captions = listOf(
                    CaptionCue(0L, minOf(4L, endSec), meta.title)
                ),
                aspectRatio = meta.aspectRatio,
                exportResolution = settings.defaultExportResolution,
                exportFps = settings.defaultExportFps,
                exportBitrate = settings.defaultExportBitrate,
                exportFormat = settings.defaultExportFormat,
                waveformBars = starterWaveform
            )
            repository.saveClips(listOf(initialClip)).onSuccess { ids ->
                val clipId = ids.firstOrNull()
                if (clipId != null) {
                    _selectedStudioClipId.value = clipId
                    _exportStatus.value = ExportStatus.Idle
                    refreshCacheSize()
                    _snackbarMessage.value = "Loaded \"${meta.title}\" (${meta.width}x${meta.height}) in HD Studio."

                    var updatedClip = initialClip.copy(id = clipId)
                    var modified = false

                    if (settings.autoCaptionsOnUpload) {
                        val cues = aiService.regenerateCaptions(meta.title, updatedClip.hook, 0L, endSec).getOrNull()
                        if (!cues.isNullOrEmpty()) {
                            updatedClip = updatedClip.copy(captions = cues)
                            modified = true
                        }
                    }

                    if (settings.autoWaveformAnalysis && signalAnalyzer != null) {
                        val analysis = signalAnalyzer.analyzeVideoHighlights(uri, meta.title, endSec)
                        val peakScore = analysis.peakWindows.firstOrNull()?.peakScore ?: 92L
                        val bestThumb = analysis.peakWindows.firstOrNull()?.thumbnailPath?.ifBlank { coverThumb } ?: coverThumb
                        updatedClip = updatedClip.copy(
                            waveformBars = analysis.waveformBars,
                            thumbnailUrl = bestThumb,
                            viralScore = peakScore
                        )
                        modified = true
                    }

                    if (modified) {
                        repository.updateClip(updatedClip)
                        refreshCacheSize()
                    }
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed loading uploaded video in Studio."
            }
        }
    }

    fun captureCoverFrameAtPlayhead(
        clip: ViralClipDoc,
        playheadSec: Long,
        onCaptured: (ViralClipDoc) -> Unit
    ) {
        if (!clip.sourceUrl.startsWith("content://") && !clip.sourceUrl.startsWith("file://")) {
            _snackbarMessage.value = "Frame capture works on uploaded device videos."
            return
        }
        viewModelScope.launch {
            val path = signalAnalyzer?.captureFrameThumbnail(
                uri = Uri.parse(clip.sourceUrl),
                timeSec = playheadSec,
                label = "cover_${clip.id.take(8)}"
            )
            if (!path.isNullOrBlank()) {
                val updated = clip.copy(thumbnailUrl = path)
                repository.updateClip(updated)
                onCaptured(updated)
                refreshCacheSize()
                _snackbarMessage.value = "Captured HD cover frame at ${playheadSec}s!"
            } else {
                _snackbarMessage.value = "Could not extract frame at ${playheadSec}s."
            }
        }
    }

    fun duplicateClip(clip: ViralClipDoc) {
        viewModelScope.launch {
            val copyClip = clip.copy(
                id = "",
                title = "${clip.title.take(40)} (Copy)",
                createdEpochMs = System.currentTimeMillis()
            )
            repository.saveClips(listOf(copyClip)).onSuccess { ids ->
                ids.firstOrNull()?.let { _selectedStudioClipId.value = it }
                _snackbarMessage.value = "Duplicated clip in Studio."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed duplicating clip."
            }
        }
    }

    fun syncScriptToClipCaptions(
        clip: ViralClipDoc,
        scriptText: String,
        onSynced: (ViralClipDoc) -> Unit
    ) {
        viewModelScope.launch {
            val cues = aiService.syncScriptToCaptions(scriptText, clip.startSec, clip.endSec)
            val updated = clip.copy(captions = cues, subtitlesEnabled = true)
            repository.updateClip(updated)
            onSynced(updated)
            _snackbarMessage.value = "Synced ${cues.size} caption lines across clip timeline."
        }
    }

    fun splitClipAtPlayhead(clip: ViralClipDoc, playheadSec: Long) {
        val splitPoint = playheadSec.coerceIn(clip.startSec + 1L, clip.endSec - 1L)
        if (splitPoint <= clip.startSec || splitPoint >= clip.endSec) {
            _snackbarMessage.value = "Move playhead inside clip bounds to split."
            return
        }
        viewModelScope.launch {
            val part1 = clip.copy(endSec = splitPoint)
            val part2 = clip.copy(
                id = "",
                title = "${clip.title} (Part 2)",
                startSec = splitPoint,
                endSec = clip.endSec
            )
            repository.updateClip(part1)
            repository.saveClips(listOf(part2)).onSuccess {
                _snackbarMessage.value = "Split clip at ${splitPoint}s into 2 parts."
            }
        }
    }

    fun applyStudioTemplate(
        clip: ViralClipDoc,
        template: StudioTemplate,
        onDone: (ViralClipDoc) -> Unit
    ) {
        viewModelScope.launch {
            val updated = clip.copy(
                filterPreset = template.filter.name,
                filterIntensity = 0.95,
                videoEffect = template.effect.name,
                transitionType = template.transition.name,
                subtitleStyle = template.subtitleStyle.name,
                musicTrack = template.musicTrack.name,
                thumbnailTemplate = template.thumbnailTemplate.name,
                playbackSpeed = template.speed,
                speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
                zoomScale = template.zoom,
                contrast = template.contrast,
                saturation = template.saturation,
                warmth = template.warmth,
                vignette = template.vignette,
                overlayText = clip.overlayText.ifBlank { template.overlayBadge },
                studioTemplateId = template.name,
                subtitlesEnabled = true
            )
            repository.updateClip(updated)
            onDone(updated)
            _snackbarMessage.value = "Applied FREE \"${template.label}\" template!"
        }
    }

    fun cleanClipFillersAndPacing(
        clip: ViralClipDoc,
        onDone: (ViralClipDoc) -> Unit
    ) {
        viewModelScope.launch {
            val updated = aiService.cleanClipFillersAndPacing(clip)
            repository.updateClip(updated)
            onDone(updated)
            _snackbarMessage.value = "Cleaned speech fillers & tightened dead-air pacing (${updated.playbackSpeed}x)!"
        }
    }

    fun runAiSmartDirector(clip: ViralClipDoc, onDone: (ViralClipDoc) -> Unit) {
        viewModelScope.launch {
            _smartEditGenerating.value = true
            val platform = SocialPlatform.fromRaw(clip.optimizedPlatform)
            val res = aiService.suggestSmartStudioEdits(clip, platform)
            _smartEditGenerating.value = false
            res.onSuccess { updated ->
                repository.updateClip(updated)
                onDone(updated)
                _snackbarMessage.value = if (aiService.isGroqConfigured()) {
                    "Groq Smart Director tuned filters, effects & SEO!"
                } else {
                    "Smart Director tuned filters, effects & SEO!"
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Smart Edit failed."
            }
        }
    }

    fun clipMediaItemWithAi(
        media: MediaItemDoc,
        targetPlatform: SocialPlatform,
        includeSubtitles: Boolean
    ) {
        viewModelScope.launch {
            _aiClipperStatus.value = AiClipperStatus.Processing("Analyzing \"${media.title.take(24)}\" for 30–90s highlights...")
            val aiResult = aiService.analyzeVideoAndGenerateClips(
                videoTitle = media.title,
                authorName = displayName,
                sourceUrl = media.sourceUrl,
                youtubeVideoId = media.youtubeVideoId,
                thumbnailUrl = media.thumbnailUrl,
                mediaId = media.id,
                targetPlatform = targetPlatform,
                includeSubtitles = includeSubtitles,
                durationHintSec = media.durationSeconds.coerceAtLeast(30L),
                clipCount = 3,
                minClipSec = 30L,
                maxClipSec = 90L
            )
            val clips = aiResult.getOrElse { err ->
                _aiClipperStatus.value = AiClipperStatus.Error(
                    err.localizedMessage ?: "Highlight extraction failed."
                )
                return@launch
            }
            repository.saveClips(clips).onSuccess { ids ->
                if (ids.isNotEmpty()) _selectedStudioClipId.value = ids.first()
                _aiClipperStatus.value = AiClipperStatus.Success(clips.size, media.title)
                refreshCacheSize()
                _snackbarMessage.value = "Created ${clips.size} clips from ${media.title}"
            }.onFailure { err ->
                _aiClipperStatus.value = AiClipperStatus.Error(err.localizedMessage ?: "Failed saving clips.")
            }
        }
    }

    fun toggleClipSubtitles(clip: ViralClipDoc) {
        viewModelScope.launch {
            val updated = clip.copy(subtitlesEnabled = !clip.subtitlesEnabled)
            repository.updateClip(updated).onSuccess {
                _snackbarMessage.value = if (updated.subtitlesEnabled) "Subtitles enabled" else "Subtitles removed"
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed updating subtitles."
            }
        }
    }

    fun saveClipEdits(clip: ViralClipDoc, silent: Boolean = false) {
        viewModelScope.launch {
            repository.updateClip(clip).onSuccess {
                if (!silent) _snackbarMessage.value = "Saved studio edits for \"${clip.title.take(24)}\""
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed saving clip edits."
            }
        }
    }

    fun deleteClip(clipId: String) {
        viewModelScope.launch {
            repository.deleteClip(clipId).onSuccess {
                if (_selectedStudioClipId.value == clipId) {
                    _selectedStudioClipId.value = null
                }
                _snackbarMessage.value = "Clip deleted."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed deleting clip."
            }
        }
    }

    fun deleteMedia(mediaId: String) {
        viewModelScope.launch {
            repository.deleteMediaItem(mediaId).onSuccess {
                _snackbarMessage.value = "Media deleted from library."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed deleting media."
            }
        }
    }

    fun generateSeoForClip(
        clip: ViralClipDoc,
        platform: SocialPlatform,
        onGenerated: (ViralClipDoc) -> Unit
    ) {
        viewModelScope.launch {
            _seoGenerating.value = true
            val captionSummary = clip.captions.joinToString(" ") { it.text }.ifBlank { clip.hook }
            val result = aiService.generateSeoMetadata(clip.title, clip.hook, captionSummary, platform)
            _seoGenerating.value = false
            result.onSuccess { seo ->
                val updated = clip.copy(
                    seoTitle = seo.seoTitle,
                    seoDescription = seo.seoDescription,
                    seoTags = seo.seoTags,
                    optimizedPlatform = platform.name
                )
                repository.updateClip(updated)
                onGenerated(updated)
                _snackbarMessage.value = "SEO title & tags boosted for ${platform.shortLabel}."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "SEO generation failed."
            }
        }
    }

    fun regenerateCaptionsForClip(clip: ViralClipDoc) {
        viewModelScope.launch {
            _captionsGenerating.value = true
            val result = aiService.regenerateCaptions(clip.title, clip.hook, clip.startSec, clip.endSec)
            _captionsGenerating.value = false
            result.onSuccess { cues ->
                if (cues.isNotEmpty()) {
                    val updated = clip.copy(captions = cues, subtitlesEnabled = true)
                    repository.updateClip(updated)
                    _snackbarMessage.value = "Generated ${cues.size} synced caption cues."
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed regenerating captions."
            }
        }
    }

    fun exportClip(clip: ViralClipDoc) {
        viewModelScope.launch {
            repository.updateClip(clip)
            val isLocal = clip.sourceUrl.startsWith("content://") || clip.sourceUrl.startsWith("file://")
            if (isLocal) {
                _exportStatus.value = ExportStatus.Exporting(5)
                val saveGallery = appSettingsState.value.autoSaveToGallery
                val res = videoExportEngine.exportLocalClipWithMedia3(
                    clip = clip,
                    saveToGallery = saveGallery
                ) { progress ->
                    _exportStatus.value = ExportStatus.Exporting(progress)
                }
                res.onSuccess { path ->
                    val updated = clip.copy(exportedPath = path)
                    repository.updateClip(updated)
                    val savedSource = if (path.startsWith("content://")) path else "file://$path"
                    repository.createMediaItem(
                        MediaItemDoc(
                            title = "${clip.title} (${clip.exportResolution})",
                            sourceType = MediaSourceType.CLIP.name,
                            sourceUrl = savedSource,
                            youtubeVideoId = "",
                            thumbnailUrl = clip.thumbnailUrl,
                            durationSeconds = (clip.endSec - clip.startSec).coerceAtLeast(1L),
                            aspectRatio = clip.aspectRatio,
                            status = MediaStatus.EXPORTED.name
                        )
                    )
                    refreshCacheSize()
                    val galleryNote = if (path.startsWith("content://")) " • Saved to Movies/ClipForge" else ""
                    _exportStatus.value = ExportStatus.Completed(
                        message = "Exported ${clip.exportResolution} ${clip.exportFps}fps HD MP4$galleryNote",
                        outputPath = path
                    )
                }.onFailure { err ->
                    _exportStatus.value = ExportStatus.Error(
                        err.localizedMessage ?: "Media3 HD export failed."
                    )
                }
            } else {
                val platform = SocialPlatform.fromRaw(clip.optimizedPlatform)
                val exportSummary = "ondevice-preset://${clip.id}/${platform.name.lowercase()}_${clip.exportResolution}_${clip.exportFps}fps.mp4"
                repository.updateClip(clip.copy(exportedPath = exportSummary))
                repository.createMediaItem(
                    MediaItemDoc(
                        title = "${clip.title} (${platform.shortLabel})",
                        sourceType = MediaSourceType.CLIP.name,
                        sourceUrl = clip.sourceUrl,
                        youtubeVideoId = clip.youtubeVideoId,
                        thumbnailUrl = clip.thumbnailUrl,
                        durationSeconds = (clip.endSec - clip.startSec).coerceAtLeast(1L),
                        aspectRatio = clip.aspectRatio,
                        status = MediaStatus.EXPORTED.name
                    )
                )
                _exportStatus.value = ExportStatus.Completed(
                    message = "Prepared ${clip.exportResolution} • ${clip.exportFps}fps • ${platform.optimizationSpec}",
                    outputPath = exportSummary
                )
            }
        }
    }

    fun connectOrUpdateSocialAccount(
        platform: SocialPlatform,
        handle: String,
        connected: Boolean,
        autoOptimize: Boolean,
        followersCount: Long
    ) {
        viewModelScope.launch {
            val formattedHandle = if (handle.startsWith("@")) handle else "@$handle"
            val doc = SocialAccountDoc(
                platform = platform.name,
                handle = formattedHandle,
                connected = connected,
                autoOptimize = autoOptimize,
                followersCount = followersCount,
                peakTimeWindow = platform.defaultPeakWindow
            )
            repository.upsertSocialAccount(doc).onSuccess {
                _snackbarMessage.value = if (connected) {
                    "Connected ${platform.label} ($formattedHandle)"
                } else {
                    "Disconnected ${platform.label}"
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed updating social account."
            }
        }
    }

    fun scheduleClipPost(
        clip: ViralClipDoc,
        platforms: List<SocialPlatform>,
        seoTitle: String,
        seoDescription: String,
        seoTags: List<String>,
        scheduledEpochMs: Long,
        scheduledLabel: String,
        peakScore: Long,
        publishImmediately: Boolean
    ) {
        viewModelScope.launch {
            val platformNames = platforms.ifEmpty { listOf(SocialPlatform.TIKTOK) }.map { it.name }
            val optimization = platforms.joinToString(" • ") { "${it.shortLabel}: ${it.targetRatio}" }
            val status = if (publishImmediately) PostStatus.PUBLISHED else PostStatus.SCHEDULED

            val post = ScheduledPostDoc(
                clipId = clip.id.ifBlank { "clip_manual" },
                clipTitle = clip.title,
                thumbnailUrl = clip.thumbnailUrl,
                platforms = platformNames,
                seoTitle = seoTitle.ifBlank { clip.title },
                seoDescription = seoDescription,
                seoTags = seoTags,
                scheduledAtEpochMs = scheduledEpochMs,
                scheduledLabel = scheduledLabel,
                peakScore = peakScore,
                status = status.name,
                optimizationSummary = optimization
            )
            repository.createScheduledPost(post).onSuccess {
                if (publishImmediately) {
                    platforms.forEach { p ->
                        repository.logAnalyticsRecord(
                            AnalyticsRecordDoc(
                                clipId = clip.id,
                                clipTitle = clip.title,
                                platform = p.name,
                                dayLabel = "Today",
                                views = 120L,
                                likes = 18L,
                                comments = 3L,
                                shares = 5L,
                                avgWatchSeconds = (clip.endSec - clip.startSec).coerceAtLeast(15L),
                                retentionPercent = 76L
                            )
                        )
                    }
                    _snackbarMessage.value = "Published to ${platforms.joinToString { it.shortLabel }} & tracked in Analytics."
                } else {
                    _snackbarMessage.value = "Scheduled for $scheduledLabel (${peakScore}% peak score)."
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed scheduling post."
            }
        }
    }

    fun markPostPublished(post: ScheduledPostDoc) {
        viewModelScope.launch {
            repository.updateScheduledPost(
                postId = post.id,
                scheduledAtEpochMs = System.currentTimeMillis(),
                scheduledLabel = "Published Now",
                peakScore = post.peakScore,
                status = PostStatus.PUBLISHED
            ).onSuccess {
                _snackbarMessage.value = "Marked \"${post.clipTitle.take(24)}\" as Published."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed updating post."
            }
        }
    }

    fun deleteScheduledPost(postId: String) {
        viewModelScope.launch {
            repository.deleteScheduledPost(postId).onSuccess {
                _snackbarMessage.value = "Scheduled post removed."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed removing scheduled post."
            }
        }
    }

    fun logAnalyticsMetric(
        clipTitle: String,
        clipId: String,
        platform: SocialPlatform,
        dayLabel: String,
        views: Long,
        likes: Long,
        comments: Long,
        shares: Long,
        retentionPercent: Long
    ) {
        viewModelScope.launch {
            val record = AnalyticsRecordDoc(
                clipId = clipId,
                clipTitle = clipTitle,
                platform = platform.name,
                dayLabel = dayLabel,
                views = views,
                likes = likes,
                comments = comments,
                shares = shares,
                avgWatchSeconds = 32L,
                retentionPercent = retentionPercent.coerceIn(0L, 100L)
            )
            repository.logAnalyticsRecord(record).onSuccess {
                _snackbarMessage.value = "Logged ${platform.shortLabel} engagement snapshot."
            }.onFailure { err ->
                _snackbarMessage.value = err.localizedMessage ?: "Failed logging analytics."
            }
        }
    }

    fun generateGrowthInsights(records: List<AnalyticsRecordDoc>, clips: List<ViralClipDoc>) {
        viewModelScope.launch {
            _aiInsightsState.value = UiState.Loading
            val res = aiService.generateAnalyticsGrowthInsights(records, clips)
            res.onSuccess { insight ->
                _aiInsightsState.value = UiState.Success(insight)
            }.onFailure { err ->
                _aiInsightsState.value = UiState.Error(err.localizedMessage ?: "Failed generating growth insights.")
            }
        }
    }

    private fun unwrapStreamError(error: Throwable, label: String): UiState.Error {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        val message = when (firestoreError?.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED -> "Permission denied loading $label."
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Network unavailable loading $label."
            else -> error.localizedMessage ?: "Unable to load $label."
        }
        Log.e(TAG, "Stream error loading $label: $message", error)
        return UiState.Error(message)
    }

    private companion object {
        const val TAG = "ClipForgeViewModel"
        const val AUTO_DELETE_WINDOW_MS = 24L * 60L * 60L * 1000L
    }
}
