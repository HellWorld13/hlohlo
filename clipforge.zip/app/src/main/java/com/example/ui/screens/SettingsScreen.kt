package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.AppSettings
import com.example.data.model.ExportBitrate
import com.example.data.model.ExportFormat
import com.example.data.model.ExportResolution
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.VioletPulse
import java.util.Locale

@Composable
fun SettingsScreen(
    currentSettings: AppSettings,
    autoDelete24hEnabled: Boolean,
    cacheSizeMb: Double,
    onBack: () -> Unit,
    onSaveSettings: (AppSettings) -> Unit,
    onToggleAutoDelete24h: (Boolean) -> Unit,
    onClearMediaCache: () -> Unit,
    onClearWorkspace: () -> Unit
) {
    BackHandler(onBack = onBack)

    var draft by remember(currentSettings) { mutableStateOf(currentSettings) }
    var confirmClearDialog by remember { mutableStateOf(false) }

    LaunchedEffect(currentSettings) {
        draft = currentSettings
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item(key = "settings_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Column {
                        Text("Studio Settings", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            text = draft.effectiveEngineLabel(),
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan
                        )
                    }
                }
                Button(
                    onClick = { onSaveSettings(draft) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                    modifier = Modifier.testTag("settings_save_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section 1: Groq Smart AI + Built-In Studio Engine Status
        item(key = "settings_ai_engine_status") {
            val groqReady = draft.isGroqSecretSet()
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, if (groqReady) CyberCyan.copy(alpha = 0.65f) else EmeraldSuccess.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = if (groqReady) CyberCyan else EmeraldSuccess)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (groqReady) "Groq Llama-3.3 70B + On-Device Engine Active"
                                else "On-Device Engine Active (Groq Secret Ready)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = if (groqReady) {
                                    "Smart highlight detection, transcript clipping, SEO, and Studio Director powered by Groq + local Media3 tools."
                                } else {
                                    "Add GROQ_API_KEY in AI Studio Secrets to boost highlight intelligence with Llama-3.3 70B (automatic on-device fallback always works)."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    listOf(
                        "YouTube Transcript, Chapter & Duration Extractor (30–90s Viral Cuts)",
                        "Groq Llama-3.3 70B Highlight & Hook Director (with Local Fallback)",
                        "Audio Peak & Waveform Scanner (MediaExtractor + MediaCodec RMS)",
                        "Real HD Renderer & 4K Export (Media3 Transformer H.264/HEVC)",
                        "Offline Voiceover Preview (TTS) & Frame Cover Extractor"
                    ).forEach { tool ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(tool, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        // Section 2: Studio HD Defaults & Smart Director Tone
        item(key = "settings_studio_hd") {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = VioletPulse)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("HD Export & Autonomous Defaults", style = MaterialTheme.typography.titleMedium)
                    }

                    Text("Default HD Export Resolution", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportResolution.entries.forEach { res ->
                            FilterChip(
                                selected = draft.defaultExportResolution == res.label,
                                onClick = { draft = draft.copy(defaultExportResolution = res.label) },
                                label = { Text(res.label) }
                            )
                        }
                    }

                    Text("Default Frame Rate, Bitrate & Codec", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(24L, 30L, 60L).forEach { fps ->
                            FilterChip(
                                selected = draft.defaultExportFps == fps,
                                onClick = { draft = draft.copy(defaultExportFps = fps) },
                                label = { Text("${fps}fps") }
                            )
                        }
                        ExportBitrate.entries.forEach { br ->
                            FilterChip(
                                selected = draft.defaultExportBitrate == br.name,
                                onClick = { draft = draft.copy(defaultExportBitrate = br.name) },
                                label = { Text(br.label) }
                            )
                        }
                        ExportFormat.entries.forEach { fmt ->
                            FilterChip(
                                selected = draft.defaultExportFormat == fmt.name,
                                onClick = { draft = draft.copy(defaultExportFormat = fmt.name) },
                                label = { Text(fmt.label) }
                            )
                        }
                    }

                    Text("Smart Edit Director Style", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Viral High-Energy", "Cinematic Story", "Podcast Breakdown", "Fast TikTok Cuts").forEach { tone ->
                            FilterChip(
                                selected = draft.smartDirectorTone == tone,
                                onClick = { draft = draft.copy(smartDirectorTone = tone) },
                                label = { Text(tone) }
                            )
                        }
                    }

                    SettingsSwitchRow(
                        title = "Auto-Save HD Exports to Phone Gallery",
                        subtitle = "Saves rendered MP4s into Movies/ClipForge automatically",
                        checked = draft.autoSaveToGallery,
                        onCheckedChange = {
                            draft = draft.copy(autoSaveToGallery = it)
                            onSaveSettings(draft)
                        }
                    )

                    SettingsSwitchRow(
                        title = "Auto Waveform & Audio Peak Scan on Upload",
                        subtitle = "Extracts energy waveform, highlight timestamps, and HD cover frame",
                        checked = draft.autoWaveformAnalysis,
                        onCheckedChange = {
                            draft = draft.copy(autoWaveformAnalysis = it)
                            onSaveSettings(draft)
                        }
                    )

                    SettingsSwitchRow(
                        title = "Auto Smart Captions on Upload",
                        subtitle = "Generates timed hook & starter captions automatically for uploaded videos",
                        checked = draft.autoCaptionsOnUpload,
                        onCheckedChange = {
                            draft = draft.copy(autoCaptionsOnUpload = it)
                            onSaveSettings(draft)
                        }
                    )

                    SettingsSwitchRow(
                        title = "24h Library Auto-Delete",
                        subtitle = "Automatically purge clips & media 24 hours after creation",
                        checked = autoDelete24hEnabled,
                        onCheckedChange = onToggleAutoDelete24h
                    )
                }
            }
        }

        // Section 3: Local Storage & Cache Management
        item(key = "settings_storage") {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("On-Device Storage & Cache", style = MaterialTheme.typography.titleMedium)
                        Surface(
                            color = CyberCyan.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = String.format(Locale.US, "%.1f MB used", cacheSizeMb),
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Text(
                        text = "All clips, edits, waveforms, and HD renders live privately on this phone. No sign-in or API keys ever needed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = onClearMediaCache,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear Temporary Exports & Frame Cache", color = CyberCyan)
                    }
                    OutlinedButton(
                        onClick = { confirmClearDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear All Local Clips & Library", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (confirmClearDialog) {
        AlertDialog(
            onDismissRequest = { confirmClearDialog = false },
            title = { Text("Clear Local Workspace?") },
            text = { Text("This removes your saved clips, library items, and schedules from this phone.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmClearDialog = false
                        onClearWorkspace()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Surface(
        color = ObsidianBg,
        border = BorderStroke(1.dp, ObsidianOutline),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(checkedTrackColor = EmeraldSuccess)
            )
        }
    }
}
