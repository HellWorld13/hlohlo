package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.media.StudioSpeechHelper
import com.example.data.model.CaptionCue
import com.example.data.model.CaptionPosition
import com.example.data.model.ClipTransition
import com.example.data.model.ExportBitrate
import com.example.data.model.ExportFormat
import com.example.data.model.ExportResolution
import com.example.data.model.FilterPreset
import com.example.data.model.MusicTrack
import com.example.data.model.SocialPlatform
import com.example.data.model.SpeedCurvePreset
import com.example.data.model.StudioTemplate
import com.example.data.model.SubtitleStyle
import com.example.data.model.ThumbnailTemplate
import com.example.data.model.VideoEffect
import com.example.data.model.ViralClipDoc
import com.example.data.model.VoiceEffect
import com.example.ui.components.formatSec
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse
import com.example.ui.viewmodel.ExportStatus
import kotlin.math.roundToLong

@Composable
private fun FreeStudioBadge(label: String = "FREE") {
    Surface(
        color = EmeraldSuccess.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = EmeraldSuccess,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun StudioTrimSpeedPanel(
    draft: ViralClipDoc,
    playheadSec: Long,
    onSplitAtPlayhead: () -> Unit,
    onCleanFillers: () -> Unit = {},
    onUpdate: (ViralClipDoc) -> Unit
) {
    val maxBounds = maxOf(draft.endSec + 60L, 300L).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Trim, Split & Speed Curve", style = MaterialTheme.typography.titleSmall)
                FreeStudioBadge()
            }
            Text(
                text = "${formatSec(draft.startSec)} → ${formatSec(draft.endSec)} (${(draft.endSec - draft.startSec).coerceAtLeast(1L)}s)",
                style = MaterialTheme.typography.labelMedium,
                color = CyberCyan
            )
        }
        RangeSlider(
            value = draft.startSec.toFloat()..draft.endSec.toFloat().coerceAtLeast(draft.startSec + 2f),
            onValueChange = { range ->
                val s = range.start.roundToLong().coerceAtLeast(0L)
                val e = range.endInclusive.roundToLong().coerceAtLeast(s + 2L)
                onUpdate(draft.copy(startSec = s, endSec = e))
            },
            valueRange = 0f..maxBounds,
            colors = SliderDefaults.colors(
                thumbColor = CoralPrimary,
                activeTrackColor = CoralPrimary
            )
        )

        // Quick Transform Actions (Split, Clean Fillers, Rotate 90, Mirror Flip)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onSplitAtPlayhead,
                enabled = playheadSec > draft.startSec + 1L && playheadSec < draft.endSec - 1L,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("studio_split_button")
            ) {
                Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Split", maxLines = 1)
            }
            OutlinedButton(
                onClick = onCleanFillers,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.65f)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("studio_clean_fillers_button")
            ) {
                Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    if (draft.silenceRemoved) "Fillers Cleaned" else "Clean Fillers",
                    color = EmeraldSuccess,
                    maxLines = 1
                )
            }
            OutlinedButton(
                onClick = {
                    val nextRot = (draft.rotationDeg + 90) % 360
                    onUpdate(draft.copy(rotationDeg = nextRot))
                },
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("studio_rotate_button")
            ) {
                Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("${draft.rotationDeg}°", maxLines = 1)
            }
            OutlinedButton(
                onClick = { onUpdate(draft.copy(flipHorizontal = !draft.flipHorizontal)) },
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (draft.flipHorizontal) CyberCyan else ObsidianOutline
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier.testTag("studio_flip_button")
            ) {
                Icon(
                    Icons.Default.Flip,
                    contentDescription = null,
                    tint = if (draft.flipHorizontal) CyberCyan else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    if (draft.flipHorizontal) "Mirrored" else "Mirror",
                    color = if (draft.flipHorizontal) CyberCyan else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
            }
        }

        Text("TikTok Speed Curve Presets (Free)", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SpeedCurvePreset.entries.forEach { curve ->
                val selected = draft.speedCurvePreset == curve.name
                Surface(
                    color = if (selected) CoralPrimary.copy(alpha = 0.22f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) CoralPrimary else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable {
                        onUpdate(
                            draft.copy(
                                speedCurvePreset = curve.name,
                                playbackSpeed = curve.speedMultiplier
                            )
                        )
                    }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(curve.label, style = MaterialTheme.typography.labelLarge, color = if (selected) CoralPrimary else Color.White)
                        Text("${curve.speedMultiplier}x • ${curve.badge}", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                }
            }
        }

        Text("Manual Speed (${draft.playbackSpeed}x)", style = MaterialTheme.typography.bodySmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(0.25, 0.5, 0.75, 1.0, 1.08, 1.25, 1.5, 2.0, 3.0).forEach { speed ->
                FilterChip(
                    selected = kotlin.math.abs(draft.playbackSpeed - speed) < 0.04,
                    onClick = { onUpdate(draft.copy(playbackSpeed = speed)) },
                    label = { Text("${speed}x") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                        selectedLabelColor = CoralPrimary
                    )
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Dynamic Reframe Zoom (9:16 Crop)", style = MaterialTheme.typography.titleSmall)
            Text("${String.format("%.2f", draft.zoomScale)}x", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
        }
        Slider(
            value = draft.zoomScale.toFloat().coerceIn(0.8f, 2.5f),
            onValueChange = { onUpdate(draft.copy(zoomScale = it.toDouble())) },
            valueRange = 0.8f..2.5f,
            colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
        )
    }
}

@Composable
fun StudioFiltersPanel(
    draft: ViralClipDoc,
    onUpdate: (ViralClipDoc) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = remember {
        listOf("All", "Pro", "Viral", "Portrait", "Warm", "Cinema", "Retro", "Film", "Mono")
    }
    val visibleFilters = remember(selectedCategory) {
        if (selectedCategory == "All") FilterPreset.entries
        else FilterPreset.entries.filter { it.category.equals(selectedCategory, ignoreCase = true) || it == FilterPreset.NONE }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("TikTok & CapCut LUT Filters", style = MaterialTheme.typography.titleSmall)
                FreeStudioBadge("ALL 16 FREE")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = {
                        onUpdate(
                            draft.copy(
                                filterPreset = FilterPreset.CRISP_STUDIO.name,
                                filterIntensity = 0.95,
                                brightness = 0.04,
                                contrast = 1.15,
                                saturation = 1.18,
                                warmth = 0.06,
                                vignette = 0.14
                            )
                        )
                    },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Auto HD", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                }
                IconButton(
                    onClick = {
                        onUpdate(
                            draft.copy(
                                filterPreset = FilterPreset.NONE.name,
                                filterIntensity = 1.0,
                                brightness = 0.0,
                                contrast = 1.0,
                                saturation = 1.0,
                                warmth = 0.0,
                                vignette = 0.0
                            )
                        )
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset filters", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Category pills
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            visibleFilters.forEach { preset ->
                val selected = draft.filterPreset == preset.name
                Surface(
                    color = if (selected) CyberCyan.copy(alpha = 0.2f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) CyberCyan else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onUpdate(draft.copy(filterPreset = preset.name)) }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(preset.label, style = MaterialTheme.typography.labelLarge, color = if (selected) CyberCyan else Color.White)
                        Text("${preset.category} • FREE", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Filter Intensity", style = MaterialTheme.typography.bodySmall)
            Text("${(draft.filterIntensity * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
        }
        Slider(
            value = draft.filterIntensity.toFloat().coerceIn(0f, 1f),
            onValueChange = { onUpdate(draft.copy(filterIntensity = it.toDouble())) },
            valueRange = 0f..1f,
            colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
        )

        Text("Brightness (${String.format("%+.2f", draft.brightness)})", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.brightness.toFloat().coerceIn(-0.5f, 0.5f),
            onValueChange = { onUpdate(draft.copy(brightness = it.toDouble())) },
            valueRange = -0.5f..0.5f
        )

        Text("Contrast (${String.format("%.2f", draft.contrast)}x)", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.contrast.toFloat().coerceIn(0.5f, 1.9f),
            onValueChange = { onUpdate(draft.copy(contrast = it.toDouble())) },
            valueRange = 0.5f..1.9f
        )

        Text("Saturation (${String.format("%.2f", draft.saturation)}x)", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.saturation.toFloat().coerceIn(0.0f, 1.9f),
            onValueChange = { onUpdate(draft.copy(saturation = it.toDouble())) },
            valueRange = 0.0f..1.9f
        )

        Text("Warmth / Temp (${String.format("%+.2f", draft.warmth)})", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.warmth.toFloat().coerceIn(-0.8f, 0.8f),
            onValueChange = { onUpdate(draft.copy(warmth = it.toDouble())) },
            valueRange = -0.8f..0.8f,
            colors = SliderDefaults.colors(thumbColor = AmberViral, activeTrackColor = AmberViral)
        )

        Text("Cinematic Vignette (${(draft.vignette * 100).toInt()}%)", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.vignette.toFloat().coerceIn(0f, 0.85f),
            onValueChange = { onUpdate(draft.copy(vignette = it.toDouble())) },
            valueRange = 0f..0.85f
        )
    }
}

@Composable
fun StudioEffectsPanel(
    draft: ViralClipDoc,
    onUpdate: (ViralClipDoc) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TikTok & CapCut Video Effects", style = MaterialTheme.typography.titleSmall)
            FreeStudioBadge("ALL 12 FX FREE")
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VideoEffect.entries.forEach { fx ->
                val selected = draft.videoEffect == fx.name
                Surface(
                    color = if (selected) VioletPulse.copy(alpha = 0.24f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) VioletPulse else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onUpdate(draft.copy(videoEffect = fx.name)) }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(fx.label, style = MaterialTheme.typography.labelLarge, color = Color.White)
                        Text("${fx.badge} • FREE", style = MaterialTheme.typography.labelSmall, color = AmberViral)
                    }
                }
            }
        }

        Text("Clip Transitions (Free)", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ClipTransition.entries.forEach { trans ->
                FilterChip(
                    selected = draft.transitionType == trans.name,
                    onClick = { onUpdate(draft.copy(transitionType = trans.name)) },
                    label = { Text(trans.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                        selectedLabelColor = CoralPrimary
                    )
                )
            }
        }

        Text("Viral Hook Stickers & Text Badges (Free)", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("", "WAIT FOR IT", "POV:", "PRO TIP", "NO WAY", "HOT TAKE", "PART 2", "MUST WATCH").forEach { badge ->
                FilterChip(
                    selected = draft.overlayText == badge,
                    onClick = { onUpdate(draft.copy(overlayText = badge)) },
                    label = { Text(if (badge.isEmpty()) "None" else badge) }
                )
            }
        }
    }
}

@Composable
fun StudioSubtitlesPanel(
    draft: ViralClipDoc,
    isGeneratingCaptions: Boolean,
    onUpdate: (ViralClipDoc) -> Unit,
    onRegenerateCaptions: () -> Unit,
    onSyncScript: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var showScriptDialog by remember { mutableStateOf(false) }
    var scriptInput by remember { mutableStateOf("") }
    var isSpeaking by remember { mutableStateOf(false) }
    val speechHelper = remember(context) {
        StudioSpeechHelper(context) { active -> isSpeaking = active }
    }
    DisposableEffect(speechHelper) {
        onDispose { speechHelper.shutdown() }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            color = ObsidianBg,
            border = BorderStroke(1.dp, ObsidianOutline),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ClosedCaption,
                        contentDescription = null,
                        tint = if (draft.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (draft.subtitlesEnabled) "Subtitles Enabled" else "Subtitles Removed",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Toggle captions on/off for export",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = draft.subtitlesEnabled,
                    onCheckedChange = { onUpdate(draft.copy(subtitlesEnabled = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = EmeraldSuccess),
                    modifier = Modifier.testTag("studio_subtitles_switch")
                )
            }
        }

        // Caption Utilities Row: Re-Caption + Paste Script Sync + Offline TTS Read Aloud
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onRegenerateCaptions,
                enabled = !isGeneratingCaptions,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                if (isGeneratingCaptions) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text("Auto Re-Caption", style = MaterialTheme.typography.labelLarge, color = CyberCyan)
            }

            OutlinedButton(
                onClick = { showScriptDialog = true },
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("studio_paste_script_button")
            ) {
                Icon(Icons.Default.Description, contentDescription = null, tint = AmberViral, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Paste Script", style = MaterialTheme.typography.labelLarge, color = AmberViral)
            }

            OutlinedButton(
                onClick = {
                    if (isSpeaking) {
                        speechHelper.stop()
                    } else {
                        val combinedText = draft.captions.joinToString(". ") { it.text }
                            .ifBlank { draft.hook.ifBlank { draft.title } }
                        speechHelper.speak(combinedText)
                    }
                },
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("studio_tts_preview_button")
            ) {
                Icon(
                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.RecordVoiceOver,
                    contentDescription = null,
                    tint = if (isSpeaking) CoralPrimary else EmeraldSuccess,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSpeaking) "Stop Voice" else "TTS Read Aloud",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isSpeaking) CoralPrimary else EmeraldSuccess
                )
            }
        }

        if (showScriptDialog) {
            AlertDialog(
                onDismissRequest = { showScriptDialog = false },
                title = { Text("Paste Script -> Auto-Sync Captions") },
                text = {
                    OutlinedTextField(
                        value = scriptInput,
                        onValueChange = { scriptInput = it },
                        label = { Text("Paste voiceover or transcript") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (scriptInput.isNotBlank()) {
                                onSyncScript(scriptInput)
                            }
                            showScriptDialog = false
                        }
                    ) {
                        Text("Sync Timeline")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showScriptDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        Text("Caption Style", style = MaterialTheme.typography.titleSmall)

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SubtitleStyle.entries.forEach { style ->
                val selected = draft.subtitleStyle == style.name
                Surface(
                    color = if (selected) VioletPulse.copy(alpha = 0.2f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) VioletPulse else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onUpdate(draft.copy(subtitleStyle = style.name)) }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(style.label, style = MaterialTheme.typography.labelLarge, color = Color.White)
                        Text(style.badge, style = MaterialTheme.typography.labelSmall, color = AmberViral)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Position:", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CaptionPosition.entries.forEach { pos ->
                    FilterChip(
                        selected = draft.captionPosition == pos.name,
                        onClick = { onUpdate(draft.copy(captionPosition = pos.name)) },
                        label = { Text(pos.label) }
                    )
                }
            }
        }

        Text("Caption Size (${String.format("%.1f", draft.captionScale)}x)", style = MaterialTheme.typography.bodySmall)
        Slider(
            value = draft.captionScale.toFloat().coerceIn(0.8f, 1.6f),
            onValueChange = { onUpdate(draft.copy(captionScale = it.toDouble())) },
            valueRange = 0.8f..1.6f
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Caption Cues (${draft.captions.size})", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(
                onClick = {
                    val lastEnd = draft.captions.lastOrNull()?.endSec ?: draft.startSec
                    val newCue = CaptionCue(lastEnd, (lastEnd + 4L).coerceAtMost(draft.endSec), "New viral caption line")
                    onUpdate(draft.copy(captions = draft.captions + newCue, subtitlesEnabled = true))
                },
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Cue")
            }
        }

        draft.captions.forEachIndexed { index, cue ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatSec(cue.startSec),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
                OutlinedTextField(
                    value = cue.text,
                    onValueChange = { newText ->
                        val updatedList = draft.captions.toMutableList()
                        updatedList[index] = cue.copy(text = newText)
                        onUpdate(draft.copy(captions = updatedList))
                    },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = {
                        val updatedList = draft.captions.toMutableList().apply { removeAt(index) }
                        onUpdate(draft.copy(captions = updatedList))
                    }
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Remove cue", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun StudioAudioPanel(
    draft: ViralClipDoc,
    onUpdate: (ViralClipDoc) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Original Voice Gain", style = MaterialTheme.typography.titleSmall)
            Text("${(draft.voiceVolume * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
        }
        Slider(
            value = draft.voiceVolume.toFloat().coerceIn(0f, 1.2f),
            onValueChange = { onUpdate(draft.copy(voiceVolume = it.toDouble())) },
            valueRange = 0f..1.2f
        )

        Text("Voice FX Preset", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            VoiceEffect.entries.forEach { fx ->
                FilterChip(
                    selected = draft.voiceEffect == fx.name,
                    onClick = { onUpdate(draft.copy(voiceEffect = fx.name)) },
                    label = { Text(fx.label) }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = draft.audioFadeIn,
                onClick = { onUpdate(draft.copy(audioFadeIn = !draft.audioFadeIn)) },
                label = { Text("Fade In") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = draft.audioFadeOut,
                onClick = { onUpdate(draft.copy(audioFadeOut = !draft.audioFadeOut)) },
                label = { Text("Fade Out") },
                modifier = Modifier.weight(1f)
            )
        }

        Text("Background Music Track", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MusicTrack.entries.forEach { track ->
                val selected = draft.musicTrack == track.name
                Surface(
                    color = if (selected) CoralPrimary.copy(alpha = 0.2f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) CoralPrimary else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onUpdate(draft.copy(musicTrack = track.name)) }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(track.label, style = MaterialTheme.typography.labelLarge)
                        Text(track.bpmLabel, style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Music Mix Level", style = MaterialTheme.typography.titleSmall)
            Text("${(draft.musicVolume * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = CoralPrimary)
        }
        Slider(
            value = draft.musicVolume.toFloat().coerceIn(0f, 1f),
            onValueChange = { onUpdate(draft.copy(musicVolume = it.toDouble())) },
            valueRange = 0f..1f
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AI Voice Isolation & -14 LUFS", style = MaterialTheme.typography.titleSmall)
                Text("Removes room echo & normalizes loudness", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
                checked = draft.noiseReduction,
                onCheckedChange = { onUpdate(draft.copy(noiseReduction = it)) }
            )
        }
    }
}

@Composable
fun StudioTemplatesSeoPanel(
    draft: ViralClipDoc,
    isGeneratingSeo: Boolean,
    isLocalVideo: Boolean = false,
    onUpdate: (ViralClipDoc) -> Unit,
    onApplyTemplate: (StudioTemplate) -> Unit = {},
    onCaptureCover: () -> Unit = {},
    onGenerateSeo: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("1-Tap TikTok & CapCut Templates", style = MaterialTheme.typography.titleSmall)
            FreeStudioBadge("ALL 8 FREE")
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StudioTemplate.entries.forEach { tpl ->
                val selected = draft.studioTemplateId == tpl.name
                Surface(
                    color = if (selected) CoralPrimary.copy(alpha = 0.22f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) CoralPrimary else ObsidianOutline),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .clickable { onApplyTemplate(tpl) }
                        .testTag("studio_template_${tpl.name.lowercase()}")
                ) {
                    Column(
                        modifier = Modifier
                            .width(164.dp)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = tpl.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) CoralPrimary else Color.White,
                                maxLines = 1
                            )
                            Text(
                                text = "FREE",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = tpl.tagline,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                    }
                }
            }
        }

        OutlinedTextField(
            value = draft.title,
            onValueChange = { onUpdate(draft.copy(title = it)) },
            label = { Text("Clip Title") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = draft.overlayText,
            onValueChange = { onUpdate(draft.copy(overlayText = it)) },
            label = { Text("Hook Sticker Overlay") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (isLocalVideo) {
            OutlinedButton(
                onClick = onCaptureCover,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Capture HD Cover Frame at Playhead", color = CyberCyan)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Cover Frame Template", style = MaterialTheme.typography.titleSmall)
            FreeStudioBadge()
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ThumbnailTemplate.entries.forEach { tpl ->
                val selected = draft.thumbnailTemplate == tpl.name
                Surface(
                    color = if (selected) AmberViral.copy(alpha = 0.18f) else ObsidianSurfaceVariant,
                    border = BorderStroke(1.dp, if (selected) AmberViral else ObsidianOutline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.clickable { onUpdate(draft.copy(thumbnailTemplate = tpl.name)) }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(tpl.label, style = MaterialTheme.typography.labelLarge, color = if (selected) AmberViral else Color.White)
                        Text(tpl.subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Search Engine (SEO) Copy", style = MaterialTheme.typography.titleSmall)
            Button(
                onClick = onGenerateSeo,
                enabled = !isGeneratingSeo,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("studio_generate_seo_button")
            ) {
                if (isGeneratingSeo) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text("SEO Boost", fontWeight = FontWeight.Bold)
            }
        }

        OutlinedTextField(
            value = draft.seoTitle,
            onValueChange = { onUpdate(draft.copy(seoTitle = it)) },
            label = { Text("SEO Title") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = draft.seoDescription,
            onValueChange = { onUpdate(draft.copy(seoDescription = it)) },
            label = { Text("SEO Description") },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = "Tags: ${draft.seoTags.joinToString(" ")}",
            style = MaterialTheme.typography.labelSmall,
            color = CyberCyan
        )
    }
}

@Composable
fun StudioExportPanel(
    draft: ViralClipDoc,
    exportStatus: ExportStatus,
    onUpdate: (ViralClipDoc) -> Unit,
    onExportClip: () -> Unit
) {
    val context = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Auto-Optimize for Platform", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SocialPlatform.entries.forEach { platform ->
                val selected = draft.optimizedPlatform == platform.name
                FilterChip(
                    selected = selected,
                    onClick = {
                        val optimalFps = if (platform == SocialPlatform.TIKTOK || platform == SocialPlatform.YOUTUBE_SHORTS) 60L else 30L
                        onUpdate(
                            draft.copy(
                                optimizedPlatform = platform.name,
                                aspectRatio = platform.targetRatio,
                                exportResolution = "1080p",
                                exportFps = optimalFps
                            )
                        )
                    },
                    label = { Text(platform.shortLabel) }
                )
            }
        }

        val currentPlatform = SocialPlatform.fromRaw(draft.optimizedPlatform)
        Text(
            text = "Applied Spec: ${currentPlatform.optimizationSpec}",
            style = MaterialTheme.typography.labelSmall,
            color = CyberCyan
        )

        Text("HD Export Resolution & FPS", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExportResolution.entries.forEach { res ->
                FilterChip(
                    selected = draft.exportResolution == res.label,
                    onClick = { onUpdate(draft.copy(exportResolution = res.label)) },
                    label = { Text(res.label) }
                )
            }
            listOf(24L, 30L, 60L).forEach { fps ->
                FilterChip(
                    selected = draft.exportFps == fps,
                    onClick = { onUpdate(draft.copy(exportFps = fps)) },
                    label = { Text("${fps}fps") }
                )
            }
        }

        Text("Bitrate & Codec", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExportBitrate.entries.forEach { br ->
                FilterChip(
                    selected = draft.exportBitrate == br.name,
                    onClick = { onUpdate(draft.copy(exportBitrate = br.name)) },
                    label = { Text("${br.label} (${br.mbps})") }
                )
            }
            ExportFormat.entries.forEach { fmt ->
                FilterChip(
                    selected = draft.exportFormat == fmt.name,
                    onClick = { onUpdate(draft.copy(exportFormat = fmt.name)) },
                    label = { Text(fmt.label) }
                )
            }
        }

        Button(
            onClick = onExportClip,
            enabled = exportStatus !is ExportStatus.Exporting,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("studio_export_button")
        ) {
            Icon(Icons.Default.FileDownload, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Export HD Clip (${draft.exportResolution} ${draft.exportFps}fps)", fontWeight = FontWeight.Bold)
        }

        when (exportStatus) {
            is ExportStatus.Exporting -> {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    LinearProgressIndicator(
                        progress = { exportStatus.progress / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = CyberCyan
                    )
                    Text(
                        text = "Rendering HD MP4 with Media3 Transformer... ${exportStatus.progress}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan
                    )
                }
            }
            is ExportStatus.Completed -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = EmeraldSuccess.copy(alpha = 0.14f)),
                    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = exportStatus.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldSuccess
                            )
                        }
                        if (exportStatus.outputPath.startsWith("content://")) {
                            OutlinedButton(
                                onClick = {
                                    runCatching {
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "video/mp4"
                                            putExtra(Intent.EXTRA_STREAM, Uri.parse(exportStatus.outputPath))
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share HD Clip"))
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share Exported HD Video")
                            }
                        }
                    }
                }
            }
            is ExportStatus.Error -> {
                Text(
                    text = exportStatus.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            ExportStatus.Idle -> {}
        }
    }
}
