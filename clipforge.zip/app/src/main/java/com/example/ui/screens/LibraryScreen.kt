package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoDelete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.MediaItemDoc
import com.example.data.model.MediaSourceType
import com.example.data.model.MediaStatus
import com.example.data.model.SocialPlatform
import com.example.data.model.UiState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.LocalVideoPlayer
import com.example.ui.components.formatSec
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse

@Composable
fun LibraryScreen(
    mediaState: UiState<List<MediaItemDoc>>,
    autoDelete24hEnabled: Boolean,
    onToggleAutoDelete24h: (Boolean) -> Unit,
    onUploadVideo: (Uri) -> Unit,
    onAutoClipMedia: (MediaItemDoc, SocialPlatform, Boolean) -> Unit,
    onDeleteMedia: (String) -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf<MediaSourceType?>(null) }
    var viewingMedia by remember { mutableStateOf<MediaItemDoc?>(null) }
    var deletingMedia by remember { mutableStateOf<MediaItemDoc?>(null) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) onUploadVideo(uri)
        }
    )

    val allItems = (mediaState as? UiState.Success)?.data.orEmpty()
    val clippedCount = remember(allItems) {
        allItems.count { it.sourceType == MediaSourceType.CLIP.name }
    }
    val filteredItems = remember(allItems, searchQuery, filterType) {
        allItems.filter { item ->
            val matchesFilter = filterType == null || item.sourceType == filterType?.name
            val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header + Zero-Permission Photo Picker Upload Button
        item(key = "library_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Media Library", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "${allItems.size} assets • $clippedCount clipped video(s)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (clippedCount >= 10) EmeraldSuccess else CyberCyan
                    )
                }
                Button(
                    onClick = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                    modifier = Modifier.testTag("library_upload_button")
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Upload", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Optional 24-Hour Auto-Delete Toggle Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(
                    1.dp,
                    if (autoDelete24hEnabled) AmberViral.copy(alpha = 0.65f) else ObsidianOutline
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = if (autoDelete24hEnabled) AmberViral.copy(alpha = 0.16f) else ObsidianBg,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoDelete,
                                contentDescription = "24-hour auto-delete",
                                tint = if (autoDelete24hEnabled) AmberViral else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(8.dp).size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (autoDelete24hEnabled) "24h Auto-Delete: ON" else "24h Auto-Delete: OFF",
                                style = MaterialTheme.typography.titleSmall,
                                color = if (autoDelete24hEnabled) AmberViral else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (autoDelete24hEnabled) {
                                    "Clips & videos automatically delete 24 hours after creation"
                                } else {
                                    "Turn ON to automatically purge Library items after 24 hours"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = autoDelete24hEnabled,
                        onCheckedChange = onToggleAutoDelete24h,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = AmberViral
                        ),
                        modifier = Modifier.testTag("library_auto_delete_24h_switch")
                    )
                }
            }
        }

        // Search & Source Type Filter
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search videos, clips, exports...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = filterType == null,
                        onClick = { filterType = null },
                        label = { Text("All (${allItems.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                            selectedLabelColor = CyberCyan
                        )
                    )
                    MediaSourceType.entries.forEach { src ->
                        val count = allItems.count { it.sourceType == src.name }
                        FilterChip(
                            selected = filterType == src,
                            onClick = { filterType = src },
                            label = { Text("${src.label} ($count)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                selectedLabelColor = CyberCyan
                            )
                        )
                    }
                }
            }
        }

        when (mediaState) {
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = CyberCyan)
                    }
                }
            }
            is UiState.Error -> {
                item {
                    EmptyStateCard(title = "Unable to Load Media", subtitle = mediaState.message)
                }
            }
            is UiState.Success -> {
                if (filteredItems.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Media Files Found",
                            subtitle = "Tap \"Upload\" to pick a video from your device, or clip a YouTube URL in the Clipper tab."
                        )
                    }
                } else {
                    items(filteredItems, key = { it.id }) { item ->
                        MediaLibraryCard(
                            item = item,
                            autoDelete24hEnabled = autoDelete24hEnabled,
                            onView = { viewingMedia = item },
                            onAutoClip = { onAutoClipMedia(item, SocialPlatform.TIKTOK, true) },
                            onDelete = { deletingMedia = item }
                        )
                    }
                }
            }
        }
    }

    // Video View / Playback Modal
    viewingMedia?.let { item ->
        val isLocal = item.sourceUrl.startsWith("content://") || item.sourceUrl.startsWith("file://")
        AlertDialog(
            onDismissRequest = { viewingMedia = null },
            title = {
                Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLocal) {
                            LocalVideoPlayer(
                                videoUri = item.sourceUrl,
                                isPlaying = true,
                                playbackSpeed = 1f,
                                volume = 1f,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            val modalData: Any = item.thumbnailUrl.ifBlank { R.drawable.img_clip_preview_tech }
                            val modalImageReq = remember(context, modalData) {
                                ImageRequest.Builder(context)
                                    .data(modalData)
                                    .size(640, 420)
                                    .crossfade(false)
                                    .build()
                            }
                            AsyncImage(
                                model = modalImageReq,
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Text(
                        text = "Type: ${MediaSourceType.fromRaw(item.sourceType).label} • ${item.aspectRatio} • ${formatSec(item.durationSeconds)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan
                    )

                    if (item.sourceUrl.startsWith("http")) {
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.sourceUrl)))
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open on YouTube")
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAutoClipMedia(item, SocialPlatform.TIKTOK, true)
                        viewingMedia = null
                    }
                ) {
                    Text("Auto-Clip with AI")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewingMedia = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    deletingMedia?.let { item ->
        AlertDialog(
            onDismissRequest = { deletingMedia = null },
            title = { Text("Delete Media File?") },
            text = { Text("Remove \"${item.title}\" from your ClipForge media library?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteMedia(item.id)
                        deletingMedia = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingMedia = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MediaLibraryCard(
    item: MediaItemDoc,
    autoDelete24hEnabled: Boolean,
    onView: () -> Unit,
    onAutoClip: () -> Unit,
    onDelete: () -> Unit
) {
    val sourceType = MediaSourceType.fromRaw(item.sourceType)
    val status = MediaStatus.fromRaw(item.status)
    val remainingLabel = remember(item.createdEpochMs, item.createdAt, autoDelete24hEnabled) {
        if (!autoDelete24hEnabled) null
        else {
            val ageMs = (System.currentTimeMillis() - item.effectiveCreatedEpochMs()).coerceAtLeast(0L)
            val leftMs = (86_400_000L - ageMs).coerceAtLeast(0L)
            val hrs = leftMs / 3_600_000L
            val mins = (leftMs % 3_600_000L) / 60_000L
            if (leftMs == 0L) "Expiring now" else "Auto-deletes in ${hrs}h ${mins}m"
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianOutline),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onView() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val thumbData: Any = item.thumbnailUrl.ifBlank { R.drawable.img_clip_preview_pod }
            val thumbRequest = remember(context, thumbData) {
                ImageRequest.Builder(context)
                    .data(thumbData)
                    .size(240, 200)
                    .crossfade(false)
                    .build()
            }
            Box(
                modifier = Modifier
                    .width(92.dp)
                    .height(74.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ObsidianSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = thumbRequest,
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Icon(
                    imageVector = Icons.Default.PlayCircleFilled,
                    contentDescription = "Preview video",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = VioletPulse.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (item.superAiGenerated) "Super AI" else sourceType.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = VioletPulse,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "${item.aspectRatio} • ${formatSec(item.durationSeconds)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = remainingLabel ?: status.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = when {
                        remainingLabel != null -> AmberViral
                        status == MediaStatus.EXPORTED -> EmeraldSuccess
                        else -> CyberCyan
                    }
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                IconButton(onClick = onAutoClip) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Auto-Clip with AI",
                        tint = CyberCyan
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete media",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
