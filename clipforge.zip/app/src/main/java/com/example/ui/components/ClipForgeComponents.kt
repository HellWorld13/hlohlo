package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.OptIn
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ClosedCaptionDisabled
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.CaptionPosition
import com.example.data.model.FilterPreset
import com.example.data.model.SocialPlatform
import com.example.data.model.SubtitleStyle
import com.example.data.model.ThumbnailTemplate
import com.example.data.model.VideoEffect
import com.example.data.model.ViralClipDoc
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse
import kotlinx.coroutines.delay

fun formatSec(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0L)
    val m = safe / 60L
    val s = safe % 60L
    return "%02d:%02d".format(m, s)
}

fun formatCompactCount(count: Long): String {
    return when {
        count >= 1_000_000L -> String.format("%.1fM", count / 1_000_000.0)
        count >= 1_000L -> String.format("%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}

fun buildFilterColorMatrix(
    preset: FilterPreset,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    warmth: Float = 0f,
    intensity: Float = 1f
): ColorMatrix {
    val k = intensity.coerceIn(0f, 1f)
    val presetSat = when (preset) {
        FilterPreset.VIVID_POP -> saturation * (1f + 0.28f * k)
        FilterPreset.TIKTOK_GLOW -> saturation * (1f + 0.16f * k)
        FilterPreset.MOODY_NOIR, FilterPreset.BW_DRAMATIC -> saturation * (1f - k)
        FilterPreset.ANIME_BLOOM -> saturation * (1f + 0.18f * k)
        FilterPreset.PASTEL_CREAM -> saturation * (1f - 0.10f * k)
        else -> saturation
    }
    val satMatrix = ColorMatrix().apply { setToSaturation(presetSat.coerceIn(0f, 2.2f)) }
    val rawTint = when (preset) {
        FilterPreset.NONE -> floatArrayOf(1f, 1f, 1f)
        FilterPreset.CRISP_STUDIO -> floatArrayOf(1.06f, 1.06f, 1.08f)
        FilterPreset.VIVID_POP -> floatArrayOf(1.08f, 1.04f, 1.08f)
        FilterPreset.TIKTOK_GLOW -> floatArrayOf(1.06f, 1.04f, 1.02f)
        FilterPreset.CYBER_CYAN -> floatArrayOf(0.84f, 1.08f, 1.18f)
        FilterPreset.TEAL_ORANGE -> floatArrayOf(1.12f, 0.97f, 1.08f)
        FilterPreset.GOLDEN_HOUR -> floatArrayOf(1.18f, 1.06f, 0.80f)
        FilterPreset.SUNSET_WARM -> floatArrayOf(1.20f, 0.97f, 0.90f)
        FilterPreset.OBSIDIAN -> floatArrayOf(0.88f, 0.92f, 1.08f)
        FilterPreset.TUNGSTEN -> floatArrayOf(1.14f, 0.98f, 0.82f)
        FilterPreset.MOODY_NOIR -> floatArrayOf(0.95f, 0.95f, 0.98f)
        FilterPreset.VINTAGE -> floatArrayOf(1.12f, 1.02f, 0.78f)
        FilterPreset.BW_DRAMATIC -> floatArrayOf(1.10f, 1.10f, 1.10f)
        FilterPreset.ANIME_BLOOM -> floatArrayOf(1.05f, 1.03f, 1.10f)
        FilterPreset.KODAK_FILM -> floatArrayOf(1.10f, 1.03f, 0.88f)
        FilterPreset.PASTEL_CREAM -> floatArrayOf(1.08f, 1.04f, 1.04f)
    }
    val presetTint = floatArrayOf(
        1f + (rawTint[0] - 1f) * k,
        1f + (rawTint[1] - 1f) * k,
        1f + (rawTint[2] - 1f) * k
    )
    val w = warmth.coerceIn(-0.8f, 0.8f)
    val b = brightness * 80f
    val c = contrast.coerceIn(0.4f, 2.2f)
    val t = (1f - c) * 128f + b
    val adjustMatrix = ColorMatrix(
        floatArrayOf(
            c * presetTint[0] * (1f + w * 0.22f), 0f, 0f, 0f, t,
            0f, c * presetTint[1], 0f, 0f, t,
            0f, 0f, c * presetTint[2] * (1f - w * 0.22f), 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    )
    adjustMatrix.timesAssign(satMatrix)
    return adjustMatrix
}

fun filterOverlayTint(preset: FilterPreset, warmth: Float, intensity: Float = 1f): Color {
    val k = intensity.coerceIn(0f, 1f)
    val base = when (preset) {
        FilterPreset.NONE -> Color.Transparent
        FilterPreset.CRISP_STUDIO -> Color(0x14E0F7FA)
        FilterPreset.VIVID_POP -> Color(0x18FF4D6D)
        FilterPreset.TIKTOK_GLOW -> Color(0x18FFE5D9)
        FilterPreset.CYBER_CYAN -> Color(0x2800E5FF)
        FilterPreset.TEAL_ORANGE -> Color(0x24008B8B)
        FilterPreset.GOLDEN_HOUR -> Color(0x2CFFB703)
        FilterPreset.SUNSET_WARM -> Color(0x28FF5E7E)
        FilterPreset.OBSIDIAN -> Color(0x2C0D1B2A)
        FilterPreset.TUNGSTEN -> Color(0x26FF9E44)
        FilterPreset.MOODY_NOIR -> Color(0x42121212)
        FilterPreset.VINTAGE -> Color(0x2AD4A373)
        FilterPreset.BW_DRAMATIC -> Color(0x4A101010)
        FilterPreset.ANIME_BLOOM -> Color(0x20E0AAFF)
        FilterPreset.KODAK_FILM -> Color(0x24E9C46A)
        FilterPreset.PASTEL_CREAM -> Color(0x1CFDF0D5)
    }
    if (base != Color.Transparent) {
        return base.copy(alpha = (base.alpha * k).coerceIn(0f, 0.55f))
    }
    if (warmth > 0.1f) {
        return Color(0xFFFFA500).copy(alpha = (warmth * 0.18f).coerceAtMost(0.22f))
    }
    if (warmth < -0.1f) {
        return Color(0xFF00B4D8).copy(alpha = (-warmth * 0.18f).coerceAtMost(0.22f))
    }
    return Color.Transparent
}

@Composable
fun ViralScorePill(score: Long, modifier: Modifier = Modifier) {
    val color = when {
        score >= 90 -> CyberCyan
        score >= 80 -> AmberViral
        else -> CoralPrimary
    }
    Surface(
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.TrendingUp,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$score% Viral",
                style = MaterialTheme.typography.labelMedium,
                color = color
            )
        }
    }
}

@Composable
fun PlatformChipBadge(platform: SocialPlatform, modifier: Modifier = Modifier) {
    val accent = when (platform) {
        SocialPlatform.TIKTOK -> CoralPrimary
        SocialPlatform.YOUTUBE_SHORTS -> Color(0xFFFF4B4B)
        SocialPlatform.INSTAGRAM_REELS -> VioletPulse
        SocialPlatform.X -> CyberCyan
        SocialPlatform.LINKEDIN -> Color(0xFF38BDF8)
    }
    Surface(
        color = accent.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = platform.shortLabel,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun SubtitleStatusBadge(enabled: Boolean) {
    Surface(
        color = if (enabled) EmeraldSuccess.copy(alpha = 0.16f) else ObsidianSurfaceVariant,
        border = BorderStroke(
            1.dp,
            if (enabled) EmeraldSuccess.copy(alpha = 0.5f) else ObsidianSurfaceVariant
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (enabled) Icons.Default.ClosedCaption else Icons.Default.ClosedCaptionDisabled,
                contentDescription = null,
                tint = if (enabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (enabled) "CC ON" else "CC OFF",
                style = MaterialTheme.typography.labelSmall,
                color = if (enabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ClipThumbnailTemplateCard(
    clip: ViralClipDoc,
    activeCaptionText: String?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val template = ThumbnailTemplate.fromRaw(clip.thumbnailTemplate)
    val filterPreset = FilterPreset.fromRaw(clip.filterPreset)
    val hasCustomFilter = filterPreset != FilterPreset.NONE ||
        clip.brightness != 0.0 ||
        clip.contrast != 1.0 ||
        clip.saturation != 1.0 ||
        clip.warmth != 0.0

    val colorFilter = remember(
        hasCustomFilter,
        filterPreset,
        clip.filterIntensity,
        clip.brightness,
        clip.contrast,
        clip.saturation,
        clip.warmth
    ) {
        if (!hasCustomFilter) null
        else ColorFilter.colorMatrix(
            buildFilterColorMatrix(
                preset = filterPreset,
                brightness = clip.brightness.toFloat(),
                contrast = clip.contrast.toFloat(),
                saturation = clip.saturation.toFloat(),
                warmth = clip.warmth.toFloat(),
                intensity = clip.filterIntensity.toFloat()
            )
        )
    }

    val overlayBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                ObsidianBg.copy(alpha = 0.35f),
                Color.Transparent,
                ObsidianBg.copy(alpha = 0.85f)
            )
        )
    }

    val frameAccent = when (template) {
        ThumbnailTemplate.BOLD_SPLIT -> AmberViral
        ThumbnailTemplate.NEON_HOOK -> CoralPrimary
        ThumbnailTemplate.PODCAST_QUOTE -> Color(0xFFFF8A3D)
        ThumbnailTemplate.TECH_GLOW -> CyberCyan
        ThumbnailTemplate.MINIMAL_CLEAN -> Color.White
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(ObsidianSurface)
            .border(
                width = if (template == ThumbnailTemplate.NEON_HOOK || template == ThumbnailTemplate.TECH_GLOW) 2.dp else 1.dp,
                color = frameAccent.copy(alpha = 0.65f),
                shape = RoundedCornerShape(18.dp)
            )
    ) {
        val fallbackDrawable = if (template == ThumbnailTemplate.TECH_GLOW) {
            R.drawable.img_clip_preview_tech
        } else {
            R.drawable.img_clip_preview_pod
        }
        val imageData: Any = clip.thumbnailUrl.ifBlank { fallbackDrawable }
        val imageRequest = remember(context, imageData) {
            ImageRequest.Builder(context)
                .data(imageData)
                .size(360, 540)
                .crossfade(false)
                .build()
        }
        val zoom = clip.zoomScale.toFloat().coerceIn(0.8f, 2.5f)
        val flipSign = if (clip.flipHorizontal) -1f else 1f
        val rot = clip.rotationDeg.toFloat()
        val imageModifier = if (zoom > 1.01f || clip.flipHorizontal || rot != 0f) {
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom * flipSign
                    scaleY = zoom
                    rotationZ = rot
                }
        } else {
            Modifier.fillMaxSize()
        }

        AsyncImage(
            model = imageRequest,
            contentDescription = clip.title,
            contentScale = ContentScale.Crop,
            colorFilter = colorFilter,
            modifier = imageModifier
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(overlayBrush)
        )

        if (clip.vignette > 0.02) {
            val vigAlpha = clip.vignette.toFloat().coerceIn(0f, 0.85f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = vigAlpha))
                        )
                    )
            )
        }

        val fx = VideoEffect.fromRaw(clip.videoEffect)
        if (fx != VideoEffect.NONE) {
            Surface(
                color = VioletPulse.copy(alpha = 0.85f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
            ) {
                Text(
                    text = fx.label.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Overlay sticker / template badge
        if (clip.overlayText.isNotBlank()) {
            Surface(
                color = frameAccent.copy(alpha = 0.92f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 14.dp, start = 12.dp, end = 12.dp)
            ) {
                Text(
                    text = clip.overlayText.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (frameAccent == Color.White || frameAccent == AmberViral || frameAccent == CyberCyan) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // Dynamic Subtitle Preview
        if (clip.subtitlesEnabled && !activeCaptionText.isNullOrBlank()) {
            val style = SubtitleStyle.fromRaw(clip.subtitleStyle)
            val pos = CaptionPosition.fromRaw(clip.captionPosition)
            val align = when (pos) {
                CaptionPosition.TOP -> Alignment.TopCenter
                CaptionPosition.CENTER -> Alignment.Center
                CaptionPosition.BOTTOM -> Alignment.BottomCenter
            }
            SubtitleCaptionOverlay(
                text = activeCaptionText,
                style = style,
                scale = clip.captionScale.toFloat(),
                modifier = Modifier
                    .align(align)
                    .padding(
                        horizontal = 12.dp,
                        vertical = if (pos == CaptionPosition.TOP) 48.dp else 20.dp
                    )
            )
        }
    }
}

@Composable
fun SubtitleCaptionOverlay(
    text: String,
    style: SubtitleStyle,
    scale: Float = 1f,
    modifier: Modifier = Modifier
) {
    val bgColor = when (style) {
        SubtitleStyle.HORMOZI_POP -> Color.Black.copy(alpha = 0.82f)
        SubtitleStyle.KARAOKE_GLOW -> VioletPulse.copy(alpha = 0.88f)
        SubtitleStyle.MINIMAL_PILL -> ObsidianSurface.copy(alpha = 0.88f)
        SubtitleStyle.NEON_BOX -> ObsidianBg.copy(alpha = 0.90f)
        SubtitleStyle.CAPTION_OUTLINE -> Color.Black.copy(alpha = 0.65f)
        SubtitleStyle.YELLOW_CREATOR -> AmberViral
    }
    val textColor = when (style) {
        SubtitleStyle.HORMOZI_POP -> Color.White
        SubtitleStyle.KARAOKE_GLOW -> Color.White
        SubtitleStyle.MINIMAL_PILL -> Color.White
        SubtitleStyle.NEON_BOX -> CyberCyan
        SubtitleStyle.CAPTION_OUTLINE -> Color.White
        SubtitleStyle.YELLOW_CREATOR -> Color.Black
    }
    val popAccent = when (style) {
        SubtitleStyle.HORMOZI_POP -> AmberViral
        SubtitleStyle.KARAOKE_GLOW -> CyberCyan
        SubtitleStyle.NEON_BOX -> CoralPrimary
        SubtitleStyle.YELLOW_CREATOR -> Color(0xFFB91C1C)
        else -> AmberViral
    }
    val border = when (style) {
        SubtitleStyle.NEON_BOX -> BorderStroke(1.5.dp, CyberCyan)
        SubtitleStyle.HORMOZI_POP -> BorderStroke(1.dp, AmberViral.copy(alpha = 0.65f))
        SubtitleStyle.CAPTION_OUTLINE -> BorderStroke(1.dp, Color.White.copy(alpha = 0.7f))
        else -> null
    }

    val safeFontSize = (14f * scale.coerceIn(0.75f, 1.6f)).sp
    val formatted = if (style == SubtitleStyle.HORMOZI_POP || style == SubtitleStyle.YELLOW_CREATOR) {
        text.uppercase()
    } else {
        text
    }

    val annotated = remember(formatted, style) {
        val words = formatted.split(Regex("\\s+")).filter { it.isNotEmpty() }
        buildAnnotatedString {
            words.forEachIndexed { idx, w ->
                val isPowerWord = w.length >= 5 || w.contains("?") || w.contains("!") || idx == words.lastIndex
                if (isPowerWord && (style == SubtitleStyle.HORMOZI_POP || style == SubtitleStyle.KARAOKE_GLOW || style == SubtitleStyle.NEON_BOX || style == SubtitleStyle.YELLOW_CREATOR)) {
                    withStyle(SpanStyle(color = popAccent, fontWeight = FontWeight.Black)) {
                        append(w)
                    }
                } else {
                    withStyle(SpanStyle(color = textColor, fontWeight = FontWeight.ExtraBold)) {
                        append(w)
                    }
                }
                if (idx < words.lastIndex) append(" ")
            }
        }
    }

    Surface(
        color = bgColor,
        border = border,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Text(
            text = annotated,
            fontSize = safeFontSize,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
fun LocalVideoPlayer(
    videoUri: String,
    isPlaying: Boolean,
    playbackSpeed: Float,
    volume: Float,
    clipStartSec: Long = 0L,
    clipEndSec: Long = 0L,
    zoomScale: Float = 1f,
    rotationDeg: Int = 0,
    flipHorizontal: Boolean = false,
    filterPreset: FilterPreset = FilterPreset.NONE,
    filterIntensity: Float = 1f,
    videoEffect: VideoEffect = VideoEffect.NONE,
    warmth: Float = 0f,
    brightness: Float = 0f,
    vignette: Float = 0f,
    seekPositionMs: Long? = null,
    onPositionUpdateSec: (Long) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val player = remember(videoUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(videoUri)))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
        }
    }

    val startMs = (clipStartSec * 1000L).coerceAtLeast(0L)
    val endMs = if (clipEndSec > clipStartSec) clipEndSec * 1000L else Long.MAX_VALUE

    LaunchedEffect(isPlaying) {
        player.playWhenReady = isPlaying
        if (isPlaying) {
            val pos = player.currentPosition
            if (pos < startMs || pos >= endMs) {
                player.seekTo(startMs)
            }
        }
    }
    LaunchedEffect(playbackSpeed) {
        player.playbackParameters = PlaybackParameters(playbackSpeed.coerceIn(0.25f, 3.0f))
    }
    LaunchedEffect(volume) {
        player.volume = volume.coerceIn(0f, 1f)
    }
    LaunchedEffect(seekPositionMs) {
        if (seekPositionMs != null && seekPositionMs >= 0L) {
            player.seekTo(seekPositionMs.coerceIn(startMs, endMs))
        }
    }
    LaunchedEffect(startMs, endMs) {
        val pos = player.currentPosition
        if (pos < startMs || pos > endMs) {
            player.seekTo(startMs)
            onPositionUpdateSec(clipStartSec)
        }
    }
    LaunchedEffect(isPlaying, startMs, endMs) {
        while (isPlaying) {
            val currentPos = player.currentPosition
            if (endMs < Long.MAX_VALUE && currentPos >= endMs) {
                player.seekTo(startMs)
                onPositionUpdateSec(clipStartSec)
            } else {
                onPositionUpdateSec((currentPos / 1000L).coerceAtLeast(clipStartSec))
            }
            delay(80L)
        }
    }

    DisposableEffect(player) {
        onDispose {
            player.release()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "fx_anim")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "zoom_pulse"
    )
    val fxScale = if (isPlaying && videoEffect == VideoEffect.ZOOM_PULSE) pulsePhase else 1f
    val fxShiftX = if (isPlaying && videoEffect == VideoEffect.SHAKE_IMPACT) {
        ((pulsePhase - 1.03f) * 120f)
    } else 0f

    val flipSign = if (flipHorizontal) -1f else 1f
    val zoom = (zoomScale.coerceIn(0.8f, 2.5f)) * fxScale
    val tintColor = remember(filterPreset, warmth, filterIntensity) {
        filterOverlayTint(filterPreset, warmth, filterIntensity)
    }

    Box(modifier = modifier.clip(RoundedCornerShape(14.dp))) {
        AndroidView(
            factory = { ctx ->
                (LayoutInflater.from(ctx).inflate(R.layout.view_texture_player, null, false) as PlayerView).apply {
                    this.player = player
                }
            },
            update = { view ->
                if (view.player != player) {
                    view.player = player
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom * flipSign
                    scaleY = zoom
                    translationX = fxShiftX
                    rotationZ = rotationDeg.toFloat()
                }
        )

        if (tintColor != Color.Transparent) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tintColor)
            )
        }

        LiveVideoEffectOverlay(
            effect = videoEffect,
            isPlaying = isPlaying,
            pulsePhase = pulsePhase
        )

        if (brightness > 0.03f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = (brightness * 0.35f).coerceAtMost(0.3f)))
            )
        } else if (brightness < -0.03f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = (-brightness * 0.55f).coerceAtMost(0.45f)))
            )
        }

        val effectiveVignette = if (videoEffect == VideoEffect.BLUR_VIGNETTE) {
            maxOf(vignette, 0.42f)
        } else {
            vignette
        }
        if (effectiveVignette > 0.02f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = effectiveVignette.coerceIn(0f, 0.85f)))
                        )
                    )
            )
        }
    }
}

@Composable
fun LiveVideoEffectOverlay(
    effect: VideoEffect,
    isPlaying: Boolean,
    pulsePhase: Float = 1.03f
) {
    when (effect) {
        VideoEffect.NONE -> Unit
        VideoEffect.GLITCH_RGB, VideoEffect.CHROMA_SPLIT -> {
            val alpha = if (isPlaying) 0.14f + (pulsePhase - 1f) * 1.4f else 0.14f
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                CoralPrimary.copy(alpha = alpha.coerceIn(0.08f, 0.25f)),
                                Color.Transparent,
                                CyberCyan.copy(alpha = alpha.coerceIn(0.08f, 0.25f))
                            )
                        )
                    )
            )
        }
        VideoEffect.VHS_SCAN, VideoEffect.FILM_GRAIN -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x16D4A373))
                    .border(1.dp, AmberViral.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            )
        }
        VideoEffect.FLASH_CUT, VideoEffect.STROBE_PULSE -> {
            if (isPlaying && pulsePhase > 1.045f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.White.copy(alpha = 0.16f))
                )
            }
        }
        VideoEffect.NEON_EDGE -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(
                        width = 2.dp,
                        brush = Brush.linearGradient(listOf(CoralPrimary, CyberCyan, VioletPulse)),
                        shape = RoundedCornerShape(14.dp)
                    )
            )
        }
        VideoEffect.MIRROR_TWIN -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.5.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            )
        }
        else -> Unit
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeClipSegmentPlayer(
    youtubeVideoId: String,
    sourceUrl: String,
    startSec: Long,
    endSec: Long,
    isPlaying: Boolean,
    playbackSpeed: Float = 1f,
    filterPreset: FilterPreset = FilterPreset.NONE,
    filterIntensity: Float = 1f,
    videoEffect: VideoEffect = VideoEffect.NONE,
    warmth: Float = 0f,
    vignette: Float = 0f,
    seekRequestSec: Long? = null,
    onPositionUpdateSec: (Long) -> Unit = {},
    onPlaybackStateChanged: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier,
    fallbackContent: @Composable () -> Unit
) {
    val context = LocalContext.current
    var embedFailed by remember(youtubeVideoId) { mutableStateOf(false) }
    var playerReady by remember(youtubeVideoId) { mutableStateOf(false) }
    var webViewRef by remember(youtubeVideoId) { mutableStateOf<WebView?>(null) }

    val safeStart = startSec.coerceAtLeast(0L)
    val safeEnd = endSec.coerceAtLeast(safeStart + 10L)

    if (embedFailed || youtubeVideoId.isBlank()) {
        Box(modifier = modifier) {
            fallbackContent()
            if (youtubeVideoId.isNotBlank()) {
                Button(
                    onClick = {
                        val url = "https://www.youtube.com/watch?v=$youtubeVideoId&t=${safeStart}s"
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralPrimary),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 12.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Watch Segment (${formatSec(safeStart)}–${formatSec(safeEnd)})", maxLines = 1)
                }
            }
        }
        return
    }

    val htmlContent = remember(youtubeVideoId, safeStart, safeEnd) {
        """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
          <style>
            html, body { margin: 0; padding: 0; width: 100%; height: 100%; background: #000; overflow: hidden; }
            #player { position: fixed; top: 0; left: 0; width: 100%; height: 100%; }
          </style>
        </head>
        <body>
          <div id="player"></div>
          <script src="https://www.youtube.com/iframe_api"></script>
          <script>
            var ytPlayer = null;
            var segStart = $safeStart;
            var segEnd = $safeEnd;
            var pollTimer = null;

            function onYouTubeIframeAPIReady() {
              ytPlayer = new YT.Player('player', {
                videoId: '$youtubeVideoId',
                playerVars: {
                  autoplay: ${if (isPlaying) 1 else 0},
                  controls: 0,
                  playsinline: 1,
                  rel: 0,
                  modestbranding: 1,
                  start: segStart,
                  end: segEnd,
                  origin: 'https://www.youtube.com'
                },
                events: {
                  onReady: function(e) {
                    if (window.ClipForgeBridge) window.ClipForgeBridge.onReady();
                    e.target.seekTo(segStart, true);
                    if (${if (isPlaying) "true" else "false"}) e.target.playVideo();
                    startPolling();
                  },
                  onStateChange: function(e) {
                    if (e.data === 0) {
                      e.target.seekTo(segStart, true);
                      e.target.playVideo();
                    }
                    if (window.ClipForgeBridge) {
                      window.ClipForgeBridge.onState(e.data === 1);
                    }
                  },
                  onError: function(e) {
                    if (window.ClipForgeBridge) window.ClipForgeBridge.onError(e.data);
                  }
                }
              });
            }

            function startPolling() {
              if (pollTimer) clearInterval(pollTimer);
              pollTimer = setInterval(function() {
                if (ytPlayer && ytPlayer.getCurrentTime) {
                  var t = Math.floor(ytPlayer.getCurrentTime());
                  if (t >= segEnd) {
                    ytPlayer.seekTo(segStart, true);
                    t = segStart;
                  }
                  if (window.ClipForgeBridge) window.ClipForgeBridge.onTime(t);
                }
              }, 250);
            }

            function cfSetPlaying(play) {
              if (!ytPlayer || !ytPlayer.playVideo) return;
              if (play) {
                var t = ytPlayer.getCurrentTime ? ytPlayer.getCurrentTime() : segStart;
                if (t < segStart || t >= segEnd) ytPlayer.seekTo(segStart, true);
                ytPlayer.playVideo();
              } else {
                ytPlayer.pauseVideo();
              }
            }

            function cfSeekTo(sec) {
              if (ytPlayer && ytPlayer.seekTo) ytPlayer.seekTo(sec, true);
            }

            function cfSetBounds(s, e) {
              segStart = s;
              segEnd = e;
            }

            function cfSetSpeed(spd) {
              if (ytPlayer && ytPlayer.setPlaybackRate) ytPlayer.setPlaybackRate(spd);
            }
          </script>
        </body>
        </html>
        """.trimIndent()
    }

    LaunchedEffect(isPlaying, playerReady) {
        if (playerReady) {
            webViewRef?.evaluateJavascript("cfSetPlaying($isPlaying);", null)
        }
    }
    LaunchedEffect(playbackSpeed, playerReady) {
        if (playerReady) {
            val safeSpd = playbackSpeed.coerceIn(0.5f, 2.0f)
            webViewRef?.evaluateJavascript("cfSetSpeed($safeSpd);", null)
        }
    }
    LaunchedEffect(safeStart, safeEnd, playerReady) {
        if (playerReady) {
            webViewRef?.evaluateJavascript("cfSetBounds($safeStart, $safeEnd);", null)
        }
    }
    LaunchedEffect(seekRequestSec, playerReady) {
        if (playerReady && seekRequestSec != null) {
            val clamped = seekRequestSec.coerceIn(safeStart, safeEnd)
            webViewRef?.evaluateJavascript("cfSeekTo($clamped);", null)
        }
    }

    DisposableEffect(youtubeVideoId) {
        onDispose {
            webViewRef?.destroy()
            webViewRef = null
        }
    }

    val tintColor = remember(filterPreset, warmth, filterIntensity) {
        filterOverlayTint(filterPreset, warmth, filterIntensity)
    }

    Box(modifier = modifier.clip(RoundedCornerShape(14.dp))) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.loadWithOverviewMode = true
                    settings.useWideViewPort = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    setBackgroundColor(android.graphics.Color.BLACK)
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            if (request?.isForMainFrame == true) {
                                embedFailed = true
                            }
                        }
                    }
                    addJavascriptInterface(
                        object {
                            @JavascriptInterface
                            fun onReady() {
                                post { playerReady = true }
                            }

                            @JavascriptInterface
                            fun onTime(sec: Long) {
                                post { onPositionUpdateSec(sec.coerceIn(safeStart, safeEnd)) }
                            }

                            @JavascriptInterface
                            fun onState(playing: Boolean) {
                                post { onPlaybackStateChanged(playing) }
                            }

                            @JavascriptInterface
                            fun onError(code: Int) {
                                post { embedFailed = true }
                            }
                        },
                        "ClipForgeBridge"
                    )
                    loadDataWithBaseURL("https://www.youtube.com", htmlContent, "text/html", "utf-8", null)
                    webViewRef = this
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (!playerReady) {
            fallbackContent()
        }

        if (tintColor != Color.Transparent) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tintColor)
            )
        }
        LiveVideoEffectOverlay(effect = videoEffect, isPlaying = isPlaying)
        if (vignette > 0.02f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = vignette.coerceIn(0f, 0.85f)))
                        )
                    )
            )
        }
    }
}

@Composable
fun EmptyStateCard(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = ObsidianSurface,
        border = BorderStroke(1.dp, ObsidianSurfaceVariant),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = CyberCyan.copy(alpha = 0.14f),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = CyberCyan
                    )
                }
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}
