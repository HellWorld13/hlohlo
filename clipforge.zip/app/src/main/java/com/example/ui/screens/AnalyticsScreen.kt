package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddChart
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AnalyticsRecordDoc
import com.example.data.model.SocialPlatform
import com.example.data.model.UiState
import com.example.data.model.ViralClipDoc
import com.example.data.remote.GrowthInsightResult
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.PlatformChipBadge
import com.example.ui.components.formatCompactCount
import com.example.ui.theme.AmberViral
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse

@Composable
fun AnalyticsScreen(
    analyticsState: UiState<List<AnalyticsRecordDoc>>,
    clipsState: UiState<List<ViralClipDoc>>,
    aiInsightsState: UiState<GrowthInsightResult>?,
    onGenerateInsights: (List<AnalyticsRecordDoc>, List<ViralClipDoc>) -> Unit,
    onLogMetric: (
        clipTitle: String,
        clipId: String,
        platform: SocialPlatform,
        dayLabel: String,
        views: Long,
        likes: Long,
        comments: Long,
        shares: Long,
        retentionPercent: Long
    ) -> Unit
) {
    val records = (analyticsState as? UiState.Success)?.data.orEmpty()
    val clips = (clipsState as? UiState.Success)?.data.orEmpty()
    var selectedPlatformFilter by remember { mutableStateOf<SocialPlatform?>(null) }
    var showLogDialog by remember { mutableStateOf(false) }

    val filtered = remember(records, selectedPlatformFilter) {
        if (selectedPlatformFilter == null) records
        else records.filter { it.platform == selectedPlatformFilter?.name }
    }

    val totalViews = remember(filtered) { filtered.sumOf { it.views } }
    val totalInteractions = remember(filtered) { filtered.sumOf { it.likes + it.comments + it.shares } }
    val engagementRate = remember(totalViews, totalInteractions) {
        if (totalViews > 0L) (totalInteractions * 100.0 / totalViews) else 0.0
    }
    val avgRetention = remember(filtered) {
        if (filtered.isNotEmpty()) filtered.map { it.retentionPercent }.average().toInt() else 0
    }
    val totalShares = remember(filtered) { filtered.sumOf { it.shares } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Log Metric Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Engagement Analytics", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Cross-platform views, retention & peak hours",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = { showLogDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("log_analytics_button")
                ) {
                    Icon(Icons.Default.AddChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Log Stats", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Platform Filter Chips
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedPlatformFilter == null,
                    onClick = { selectedPlatformFilter = null },
                    label = { Text("All Platforms") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                        selectedLabelColor = CoralPrimary
                    )
                )
                SocialPlatform.entries.forEach { platform ->
                    FilterChip(
                        selected = selectedPlatformFilter == platform,
                        onClick = { selectedPlatformFilter = platform },
                        label = { Text(platform.shortLabel) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                            selectedLabelColor = CoralPrimary
                        )
                    )
                }
            }
        }

        // 4 KPI Metric Cards (2x2 Grid)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Total Views",
                        value = formatCompactCount(totalViews),
                        subtitle = "${filtered.size} tracked drops",
                        accent = CoralPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Engagement Rate",
                        value = "${String.format("%.1f", engagementRate)}%",
                        subtitle = "${formatCompactCount(totalInteractions)} actions",
                        accent = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Avg Retention",
                        value = "$avgRetention%",
                        subtitle = "Hook hold rate",
                        accent = VioletPulse,
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "Viral Shares",
                        value = formatCompactCount(totalShares),
                        subtitle = "Reposts & DMs",
                        accent = AmberViral,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Views Velocity Trend Chart
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Views & Engagement Velocity", style = MaterialTheme.typography.titleMedium)
                        Text("Last ${maxOf(filtered.size, 7)} Points", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                    }
                    val series = if (filtered.isEmpty()) {
                        listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f)
                    } else {
                        filtered.takeLast(10).map { it.views.toFloat().coerceAtLeast(1f) }
                    }
                    TrendAreaChart(
                        values = series,
                        lineColor = CyberCyan,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )
                }
            }
        }

        // Platform Performance Breakdown + Peak Audience Heatmap
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Platform Views Distribution", style = MaterialTheme.typography.titleMedium)
                    val platformTotals = SocialPlatform.entries.map { p ->
                        p to records.filter { it.platform == p.name }.sumOf { it.views }
                    }
                    val maxViews = (platformTotals.maxOfOrNull { it.second } ?: 1L).coerceAtLeast(1L)
                    platformTotals.forEach { (platform, views) ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = platform.shortLabel,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.width(74.dp)
                            )
                            Box(modifier = Modifier.weight(1f).height(10.dp)) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawRoundRect(
                                        color = ObsidianSurfaceVariant,
                                        cornerRadius = CornerRadius(12f, 12f)
                                    )
                                    val fraction = (views.toFloat() / maxViews.toFloat()).coerceIn(0f, 1f)
                                    if (fraction > 0f) {
                                        drawRoundRect(
                                            brush = Brush.horizontalGradient(listOf(CoralPrimary, CyberCyan)),
                                            size = Size(size.width * fraction, size.height),
                                            cornerRadius = CornerRadius(12f, 12f)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = formatCompactCount(views),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(48.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = AmberViral, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Peak Audience Activity Matrix (Mon–Sun)", style = MaterialTheme.typography.titleSmall)
                    }
                    AudienceHeatmapCanvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(74.dp)
                    )
                }
            }
        }

        // Gemini AI Growth Coach
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, VioletPulse.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Insights, contentDescription = null, tint = VioletPulse)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Growth Strategist", style = MaterialTheme.typography.titleMedium)
                        }
                        OutlinedButton(
                            onClick = { onGenerateInsights(records, clips) },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("generate_ai_insights_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Analyze", color = CyberCyan)
                        }
                    }

                    when (aiInsightsState) {
                        null -> {
                            Text(
                                text = "Tap Analyze to let Gemini 3.8 Flash review your clip retention and suggest your next viral hook and peak slot.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        is UiState.Loading -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = CyberCyan)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("Generating personalized growth insights...", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        is UiState.Error -> {
                            Text(aiInsightsState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        is UiState.Success -> {
                            val insight = aiInsightsState.data
                            Text(insight.headline, style = MaterialTheme.typography.titleSmall, color = CyberCyan)
                            Text(insight.recommendation, style = MaterialTheme.typography.bodySmall)
                            Text("Best Window: ${insight.bestPostingWindow}", style = MaterialTheme.typography.labelSmall, color = AmberViral)
                            Text("Next Hook Idea: ${insight.nextHookIdea}", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                        }
                    }
                }
            }
        }

        // Tracked Engagement Records
        item {
            Text("Clip Performance Log (${filtered.size})", style = MaterialTheme.typography.titleLarge)
        }

        if (filtered.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "No Analytics Logged Yet",
                    subtitle = "Tap \"Log Stats\" above or publish a scheduled post to start tracking multi-platform views, likes, shares, and retention."
                )
            }
        } else {
            items(filtered, key = { it.id }) { rec ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(1.dp, ObsidianOutline),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PlatformChipBadge(platform = SocialPlatform.fromRaw(rec.platform))
                                Text(rec.dayLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = rec.clipTitle,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${formatCompactCount(rec.likes)} likes • ${formatCompactCount(rec.comments)} comments • ${formatCompactCount(rec.shares)} shares",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = formatCompactCount(rec.views),
                                style = MaterialTheme.typography.titleLarge,
                                color = CyberCyan
                            )
                            Text(
                                text = "${rec.retentionPercent}% hold",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess
                            )
                        }
                    }
                }
            }
        }
    }

    if (showLogDialog) {
        var clipTitle by remember { mutableStateOf(clips.firstOrNull()?.title ?: "Viral Hook Clip") }
        var platform by remember { mutableStateOf(SocialPlatform.TIKTOK) }
        var viewsText by remember { mutableStateOf("14200") }
        var likesText by remember { mutableStateOf("1680") }
        var commentsText by remember { mutableStateOf("145") }
        var sharesText by remember { mutableStateOf("320") }
        var retentionText by remember { mutableStateOf("79") }

        AlertDialog(
            onDismissRequest = { showLogDialog = false },
            title = { Text("Log Engagement Snapshot") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = clipTitle,
                        onValueChange = { clipTitle = it },
                        label = { Text("Clip Title") },
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SocialPlatform.entries.forEach { p ->
                            FilterChip(
                                selected = p == platform,
                                onClick = { platform = p },
                                label = { Text(p.shortLabel) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = viewsText,
                            onValueChange = { viewsText = it.filter(Char::isDigit) },
                            label = { Text("Views") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = likesText,
                            onValueChange = { likesText = it.filter(Char::isDigit) },
                            label = { Text("Likes") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = commentsText,
                            onValueChange = { commentsText = it.filter(Char::isDigit) },
                            label = { Text("Comments") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = sharesText,
                            onValueChange = { sharesText = it.filter(Char::isDigit) },
                            label = { Text("Shares") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = retentionText,
                        onValueChange = { retentionText = it.filter(Char::isDigit) },
                        label = { Text("Retention % (0-100)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onLogMetric(
                            clipTitle.ifBlank { "Untitled Clip" },
                            clips.firstOrNull { it.title == clipTitle }?.id.orEmpty(),
                            platform,
                            "Today",
                            viewsText.toLongOrNull() ?: 0L,
                            likesText.toLongOrNull() ?: 0L,
                            commentsText.toLongOrNull() ?: 0L,
                            sharesText.toLongOrNull() ?: 0L,
                            (retentionText.toLongOrNull() ?: 70L).coerceIn(0L, 100L)
                        )
                        showLogDialog = false
                    }
                ) {
                    Text("Save Metrics")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = accent)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TrendAreaChart(
    values: List<Float>,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val maxVal = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val count = values.size.coerceAtLeast(2)
        val stepX = size.width / (count - 1).coerceAtLeast(1)

        val points = values.mapIndexed { idx, v ->
            val x = idx * stepX
            val y = size.height - ((v / maxVal) * (size.height * 0.85f)) - 10f
            Offset(x, y)
        }

        val linePath = Path().apply {
            points.forEachIndexed { idx, pt ->
                if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }

        val fillPath = Path().apply {
            addPath(linePath)
            lineTo(points.last().x, size.height)
            lineTo(points.first().x, size.height)
            close()
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(lineColor.copy(alpha = 0.35f), Color.Transparent)
            )
        )
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 5f, cap = StrokeCap.Round)
        )
        points.forEach { pt ->
            drawCircle(color = CoralPrimary, radius = 6f, center = pt)
        }
    }
}

@Composable
private fun AudienceHeatmapCanvas(modifier: Modifier = Modifier) {
    val intensities = remember {
        listOf(
            0.25f, 0.35f, 0.50f, 0.65f, 0.45f, 0.78f, 0.94f, 0.85f,
            0.30f, 0.42f, 0.60f, 0.70f, 0.55f, 0.88f, 0.96f, 0.72f,
            0.20f, 0.38f, 0.72f, 0.82f, 0.60f, 0.84f, 0.91f, 0.68f
        )
    }
    Canvas(modifier = modifier) {
        val cols = 8
        val rows = 3
        val gap = 6f
        val cellW = (size.width - gap * (cols - 1)) / cols
        val cellH = (size.height - gap * (rows - 1)) / rows
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val intensity = intensities[r * cols + c]
                val color = if (intensity >= 0.85f) CyberCyan.copy(alpha = intensity)
                else VioletPulse.copy(alpha = intensity * 0.8f)
                drawRoundRect(
                    color = color,
                    topLeft = Offset(c * (cellW + gap), r * (cellH + gap)),
                    size = Size(cellW, cellH),
                    cornerRadius = CornerRadius(8f, 8f)
                )
            }
        }
    }
}
