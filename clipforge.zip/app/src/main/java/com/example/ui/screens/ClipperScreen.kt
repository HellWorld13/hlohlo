package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ClosedCaptionDisabled
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.model.CaptionPosition
import com.example.data.model.FilterPreset
import com.example.data.model.MediaItemDoc
import com.example.data.model.MediaSourceType
import com.example.data.model.SocialPlatform
import com.example.data.model.SubtitleStyle
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.VideoEffect
import com.example.data.model.ViralClipDoc
import com.example.data.remote.YouTubeMetadataService
import com.example.ui.components.ClipThumbnailTemplateCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.LocalVideoPlayer
import com.example.ui.components.PlatformChipBadge
import com.example.ui.components.SubtitleCaptionOverlay
import com.example.ui.components.SubtitleStatusBadge
import com.example.ui.components.SuperAiAutopilotPanel
import com.example.ui.components.ViralScorePill
import com.example.ui.components.YouTubeClipSegmentPlayer
import com.example.ui.components.formatSec
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.VioletPulse
import com.example.ui.viewmodel.AiClipperStatus
import com.example.ui.viewmodel.SuperAiStatus

private enum class ClipDurationPreset(
    val label: String,
    val minSec: Long,
    val maxSec: Long
) {
    AUTO_30_90("30–90s Auto", 30L, 90L),
    FAST_30_45("30–45s", 30L, 45L),
    SHORTS_45_60("45–60s", 45L, 60L),
    STORY_60_90("60–90s", 60L, 90L)
}

@Composable
fun ClipperScreen(
    clipsState: UiState<List<ViralClipDoc>>,
    mediaState: UiState<List<MediaItemDoc>>,
    userProfileState: UiState<UserProfile>,
    aiStatus: AiClipperStatus,
    superAiStatus: SuperAiStatus,
    onToggleSuperAi: (Boolean, String, String, Boolean, List<String>) -> Unit,
    onRunSuperAiNow: (String, String, Boolean, List<String>) -> Unit,
    onSaveSuperAiPrefs: (Boolean, String, String, Boolean, List<String>) -> Unit,
    onDismissSuperAiStatus: () -> Unit,
    onClipYouTubeUrl: (
        url: String,
        platform: SocialPlatform,
        includeSubtitles: Boolean,
        clipCount: Int,
        minSec: Long,
        maxSec: Long
    ) -> Unit,
    onUploadLocalVideo: (Uri) -> Unit,
    onToggleSubtitles: (ViralClipDoc) -> Unit,
    onEditInStudio: (ViralClipDoc) -> Unit,
    onScheduleClip: (ViralClipDoc) -> Unit,
    onDeleteClip: (String) -> Unit,
    onDismissStatus: () -> Unit
) {
    val context = LocalContext.current
    var youtubeUrl by remember { mutableStateOf("") }
    var selectedPlatform by remember { mutableStateOf(SocialPlatform.TIKTOK) }
    var selectedDurationPreset by remember { mutableStateOf(ClipDurationPreset.AUTO_30_90) }
    var selectedClipCount by remember { mutableStateOf(3) }
    var includeSubtitles by remember { mutableStateOf(true) }
    var previewClip by remember { mutableStateOf<ViralClipDoc?>(null) }
    val userProfile = (userProfileState as? UiState.Success)?.data ?: UserProfile()
    val libraryClippedCount = remember(mediaState) {
        (mediaState as? UiState.Success)?.data?.count { it.sourceType == MediaSourceType.CLIP.name } ?: 0
    }
    val heroBannerRequest = remember(context) {
        ImageRequest.Builder(context)
            .data(R.drawable.img_studio_hero)
            .size(720, 320)
            .crossfade(false)
            .build()
    }
    val heroScrimBrush = remember {
        Brush.horizontalGradient(
            colors = listOf(
                ObsidianBg.copy(alpha = 0.92f),
                ObsidianBg.copy(alpha = 0.55f)
            )
        )
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onUploadLocalVideo(uri)
            }
        }
    )

    val isProcessing = aiStatus is AiClipperStatus.Processing

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero AI Clipper Banner
        item(key = "hero_banner") {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(136.dp)
                    .clip(RoundedCornerShape(22.dp))
            ) {
                AsyncImage(
                    model = heroBannerRequest,
                    contentDescription = "ClipForge Autonomous Clipper",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(heroScrimBrush)
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AUTONOMOUS AI CLIPPER",
                            style = MaterialTheme.typography.labelMedium,
                            color = CyberCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "YouTube URL to Viral Shorts",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "AI detects hooks, cuts 9:16 highlights, captions & SEO.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Auto Clipping Super AI Autopilot Panel
        item {
            SuperAiAutopilotPanel(
                userProfile = userProfile,
                superAiStatus = superAiStatus,
                libraryClippedCount = libraryClippedCount,
                onToggleSuperAi = onToggleSuperAi,
                onRunSuperAiNow = onRunSuperAiNow,
                onSavePreferences = onSaveSuperAiPrefs,
                onDismissStatus = onDismissSuperAiStatus
            )
        }

        // URL Input & Auto-Clip Configuration Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, ObsidianOutline),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = youtubeUrl,
                        onValueChange = { youtubeUrl = it },
                        placeholder = {
                            Text("https://www.youtube.com/watch?v=...", maxLines = 1)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Link,
                                contentDescription = null,
                                tint = CyberCyan
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = ObsidianOutline,
                            focusedContainerColor = ObsidianBg,
                            unfocusedContainerColor = ObsidianBg
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("youtube_url_input")
                    )

                    // Quick-test sample YouTube URL chips
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val quickSamples = listOf(
                            "Tech Keynote" to "https://www.youtube.com/watch?v=M7lc1UVf-VE",
                            "Creator Podcast" to "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
                            "Shorts Demo" to "https://youtu.be/YE7VzlLtp-4"
                        )
                        quickSamples.forEach { (label, url) ->
                            Surface(
                                color = ObsidianSurfaceVariant,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier.clickable { youtubeUrl = url }
                            ) {
                                Text(
                                    text = "+ $label",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // Target Platform Optimizer Chips
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Optimize Clips For",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SocialPlatform.entries.forEach { platform ->
                                val selected = platform == selectedPlatform
                                FilterChip(
                                    selected = selected,
                                    onClick = { selectedPlatform = platform },
                                    label = { Text(platform.shortLabel) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CoralPrimary.copy(alpha = 0.22f),
                                        selectedLabelColor = CoralPrimary
                                    )
                                )
                            }
                        }
                        Text(
                            text = selectedPlatform.optimizationSpec,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan
                        )
                    }

                    // Clip Duration Range (30-90s) & Clip Count
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Clip Duration (30–90s Highlights)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ClipDurationPreset.entries.forEach { preset ->
                                val selected = preset == selectedDurationPreset
                                FilterChip(
                                    selected = selected,
                                    onClick = { selectedDurationPreset = preset },
                                    label = { Text(preset.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CyberCyan.copy(alpha = 0.22f),
                                        selectedLabelColor = CyberCyan
                                    ),
                                    modifier = Modifier.testTag("duration_preset_${preset.name}")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Clips to Generate",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(3, 5, 8).forEach { count ->
                                    FilterChip(
                                        selected = selectedClipCount == count,
                                        onClick = { selectedClipCount = count },
                                        label = { Text("$count clips") },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = VioletPulse.copy(alpha = 0.25f),
                                            selectedLabelColor = VioletPulse
                                        ),
                                        modifier = Modifier.testTag("clip_count_$count")
                                    )
                                }
                            }
                        }
                    }

                    // Subtitles Toggle (User Choice: Add / Remove)
                    Surface(
                        color = ObsidianBg,
                        border = BorderStroke(1.dp, ObsidianOutline),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (includeSubtitles) Icons.Default.ClosedCaption else Icons.Default.ClosedCaptionDisabled,
                                    contentDescription = null,
                                    tint = if (includeSubtitles) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (includeSubtitles) "AI Subtitles: Included" else "AI Subtitles: Off",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "Add or remove captions anytime per clip",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = includeSubtitles,
                                onCheckedChange = { includeSubtitles = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = EmeraldSuccess
                                ),
                                modifier = Modifier.testTag("global_subtitles_switch")
                            )
                        }
                    }

                    // Primary CTA + Upload Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onClipYouTubeUrl(
                                    youtubeUrl,
                                    selectedPlatform,
                                    includeSubtitles,
                                    selectedClipCount,
                                    selectedDurationPreset.minSec,
                                    selectedDurationPreset.maxSec
                                )
                            },
                            enabled = !isProcessing && youtubeUrl.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CoralPrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("auto_clip_button")
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Clipping...")
                            } else {
                                Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Auto-Clip", fontWeight = FontWeight.Bold)
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("upload_video_clipper_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.UploadFile,
                                contentDescription = "Upload Video",
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upload", color = CyberCyan)
                        }
                    }

                    // Status Banner
                    AnimatedVisibility(visible = aiStatus !is AiClipperStatus.Idle) {
                        when (aiStatus) {
                            is AiClipperStatus.Processing -> {
                                Surface(
                                    color = VioletPulse.copy(alpha = 0.16f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(18.dp),
                                            color = CyberCyan,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = aiStatus.stepMessage,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            is AiClipperStatus.Success -> {
                                Surface(
                                    color = EmeraldSuccess.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onDismissStatus() }
                                ) {
                                    Text(
                                        text = "Created ${aiStatus.generatedCount} viral clips from \"${aiStatus.sourceTitle}\". Tap a clip below to edit or schedule.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = EmeraldSuccess,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                            is AiClipperStatus.Error -> {
                                Surface(
                                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onDismissStatus() }
                                ) {
                                    Text(
                                        text = aiStatus.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                            AiClipperStatus.Idle -> {}
                        }
                    }
                }
            }
        }

        // Generated Viral Clips Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Generated Viral Clips",
                    style = MaterialTheme.typography.titleLarge
                )
                if (clipsState is UiState.Success) {
                    Text(
                        text = "${clipsState.data.size} clips",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan
                    )
                }
            }
        }

        when (clipsState) {
            is UiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = CoralPrimary)
                    }
                }
            }
            is UiState.Error -> {
                item {
                    EmptyStateCard(
                        title = "Unable to Load Clips",
                        subtitle = clipsState.message
                    )
                }
            }
            is UiState.Success -> {
                if (clipsState.data.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Viral Clips Yet",
                            subtitle = "Paste any YouTube video URL above to auto-clip 30–90s highlights, launch Super AI Autopilot, or upload an HD device video."
                        )
                    }
                } else {
                    items(clipsState.data, key = { it.id }) { clip ->
                        ViralClipResultCard(
                            clip = clip,
                            onPreviewClip = { previewClip = clip },
                            onToggleSubtitles = { onToggleSubtitles(clip) },
                            onEditInStudio = { onEditInStudio(clip) },
                            onScheduleClip = { onScheduleClip(clip) },
                            onOpenSource = {
                                if (clip.sourceUrl.startsWith("http") || clip.youtubeVideoId.isNotBlank()) {
                                    val urlToOpen = YouTubeMetadataService.buildTimestampedUrl(
                                        clip.sourceUrl,
                                        clip.youtubeVideoId,
                                        clip.startSec
                                    )
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(urlToOpen)))
                                    }
                                }
                            },
                            onDelete = { onDeleteClip(clip.id) }
                        )
                    }
                }
            }
        }
    }

    val activePreview = previewClip
    if (activePreview != null) {
        ClipPreviewDialog(
            clip = activePreview,
            onDismiss = { previewClip = null },
            onEditInStudio = {
                previewClip = null
                onEditInStudio(activePreview)
            },
            onScheduleClip = {
                previewClip = null
                onScheduleClip(activePreview)
            },
            onOpenYouTube = {
                val url = YouTubeMetadataService.buildTimestampedUrl(
                    activePreview.sourceUrl,
                    activePreview.youtubeVideoId,
                    activePreview.startSec
                )
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
        )
    }
}

@Composable
private fun ViralClipResultCard(
    clip: ViralClipDoc,
    onPreviewClip: () -> Unit,
    onToggleSubtitles: () -> Unit,
    onEditInStudio: () -> Unit,
    onScheduleClip: () -> Unit,
    onOpenSource: () -> Unit,
    onDelete: () -> Unit
) {
    val platform = SocialPlatform.fromRaw(clip.optimizedPlatform)
    val previewCaption = clip.captions.firstOrNull()?.text ?: clip.hook

    Card(
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(1.dp, ObsidianOutline),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier
                        .width(104.dp)
                        .height(166.dp)
                        .clickable { onPreviewClip() }
                ) {
                    ClipThumbnailTemplateCard(
                        clip = clip,
                        activeCaptionText = previewCaption,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = Color.Black.copy(alpha = 0.65f),
                        shape = CircleShape,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.55f)),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Preview 30-90s clip",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ViralScorePill(score = clip.viralScore)
                        Surface(
                            color = VioletPulse.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, VioletPulse.copy(alpha = 0.45f)),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "Hook ${clip.hookScore}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Delete clip",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Text(
                        text = clip.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = "\"${clip.hook}\"",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (clip.viralReason.isNotBlank()) {
                        Text(
                            text = clip.viralReason,
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSuccess,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlatformChipBadge(platform = platform)
                        val clipDurationSec = (clip.endSec - clip.startSec).coerceAtLeast(1L)
                        Surface(
                            color = ObsidianSurfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "${formatSec(clip.startSec)}–${formatSec(clip.endSec)} (${clipDurationSec}s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        SubtitleStatusBadge(enabled = clip.subtitlesEnabled)
                    }

                    if (clip.seoTitle.isNotBlank()) {
                        Text(
                            text = "SEO: ${clip.seoTitle}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Action Row: Optional Add/Remove Subtitles Button + Studio + Schedule + Source Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onToggleSubtitles,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (clip.subtitlesEnabled) EmeraldSuccess.copy(alpha = 0.6f) else ObsidianOutline
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("toggle_subtitles_button_${clip.id}")
                ) {
                    Icon(
                        imageVector = if (clip.subtitlesEnabled) Icons.Default.ClosedCaption else Icons.Default.ClosedCaptionDisabled,
                        contentDescription = "Toggle Subtitles",
                        tint = if (clip.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (clip.subtitlesEnabled) "Remove CC" else "Add CC",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (clip.subtitlesEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurface
                    )
                }

                Button(
                    onClick = onEditInStudio,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("edit_in_studio_button_${clip.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Studio", maxLines = 1)
                }

                Button(
                    onClick = onScheduleClip,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = Color.Black
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Post", maxLines = 1, fontWeight = FontWeight.Bold)
                }

                if (clip.sourceUrl.startsWith("http")) {
                    IconButton(onClick = onOpenSource) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Open source video",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClipPreviewDialog(
    clip: ViralClipDoc,
    onDismiss: () -> Unit,
    onEditInStudio: () -> Unit,
    onScheduleClip: () -> Unit,
    onOpenYouTube: () -> Unit
) {
    val isLocalVideo = clip.sourceUrl.startsWith("content://") || clip.sourceUrl.startsWith("file://")
    var isPlaying by remember(clip.id) { mutableStateOf(true) }
    var playheadSec by remember(clip.id) { mutableLongStateOf(clip.startSec) }
    var seekReqMs by remember(clip.id) { mutableStateOf<Long?>(null) }
    var seekReqSec by remember(clip.id) { mutableStateOf<Long?>(null) }
    val clipDurationSec = (clip.endSec - clip.startSec).coerceAtLeast(1L)

    val activeCueText = remember(clip.captions, playheadSec, clip.subtitlesEnabled) {
        if (!clip.subtitlesEnabled) null
        else clip.captions.firstOrNull { playheadSec in it.startSec..it.endSec }?.text
            ?: clip.captions.firstOrNull()?.text
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
            border = BorderStroke(1.dp, ObsidianOutline),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = clip.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${formatSec(clip.startSec)}–${formatSec(clip.endSec)} (${clipDurationSec}s) • ${SocialPlatform.fromRaw(clip.optimizedPlatform).shortLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close preview")
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(310.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLocalVideo) {
                        LocalVideoPlayer(
                            videoUri = clip.sourceUrl,
                            isPlaying = isPlaying,
                            playbackSpeed = clip.playbackSpeed.toFloat(),
                            volume = clip.voiceVolume.toFloat(),
                            clipStartSec = clip.startSec,
                            clipEndSec = clip.endSec,
                            zoomScale = clip.zoomScale.toFloat(),
                            rotationDeg = clip.rotationDeg,
                            flipHorizontal = clip.flipHorizontal,
                            filterPreset = FilterPreset.fromRaw(clip.filterPreset),
                            filterIntensity = clip.filterIntensity.toFloat(),
                            videoEffect = VideoEffect.fromRaw(clip.videoEffect),
                            warmth = clip.warmth.toFloat(),
                            brightness = clip.brightness.toFloat(),
                            vignette = clip.vignette.toFloat(),
                            seekPositionMs = seekReqMs,
                            onPositionUpdateSec = { sec -> playheadSec = sec },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (clip.youtubeVideoId.isNotBlank()) {
                        YouTubeClipSegmentPlayer(
                            youtubeVideoId = clip.youtubeVideoId,
                            sourceUrl = clip.sourceUrl,
                            startSec = clip.startSec,
                            endSec = clip.endSec,
                            isPlaying = isPlaying,
                            playbackSpeed = clip.playbackSpeed.toFloat(),
                            filterPreset = FilterPreset.fromRaw(clip.filterPreset),
                            filterIntensity = clip.filterIntensity.toFloat(),
                            videoEffect = VideoEffect.fromRaw(clip.videoEffect),
                            warmth = clip.warmth.toFloat(),
                            vignette = clip.vignette.toFloat(),
                            seekRequestSec = seekReqSec,
                            onPositionUpdateSec = { sec -> playheadSec = sec },
                            modifier = Modifier.fillMaxSize(),
                            fallbackContent = {
                                ClipThumbnailTemplateCard(
                                    clip = clip,
                                    activeCaptionText = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        )
                    } else {
                        ClipThumbnailTemplateCard(
                            clip = clip,
                            activeCaptionText = null,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    if (clip.overlayText.isNotBlank()) {
                        Surface(
                            color = CoralPrimary.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp)
                        ) {
                            Text(
                                text = clip.overlayText.uppercase(),
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (clip.subtitlesEnabled && !activeCueText.isNullOrBlank()) {
                        val pos = CaptionPosition.fromRaw(clip.captionPosition)
                        val align = when (pos) {
                            CaptionPosition.TOP -> Alignment.TopCenter
                            CaptionPosition.CENTER -> Alignment.Center
                            CaptionPosition.BOTTOM -> Alignment.BottomCenter
                        }
                        SubtitleCaptionOverlay(
                            text = activeCueText,
                            style = SubtitleStyle.fromRaw(clip.subtitleStyle),
                            scale = clip.captionScale.toFloat(),
                            modifier = Modifier
                                .align(align)
                                .padding(horizontal = 14.dp, vertical = 38.dp)
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = ObsidianBg.copy(alpha = 0.78f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .size(48.dp)
                    ) {
                        IconButton(onClick = { isPlaying = !isPlaying }) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause clip" else "Play clip",
                                tint = Color.White
                            )
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatSec(playheadSec),
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberCyan
                        )
                        Text(
                            text = formatSec(clip.endSec),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Slider(
                        value = playheadSec.toFloat().coerceIn(clip.startSec.toFloat(), clip.endSec.toFloat().coerceAtLeast(clip.startSec + 1f)),
                        onValueChange = { sec ->
                            val newSec = sec.toLong()
                            playheadSec = newSec
                            if (isLocalVideo) seekReqMs = newSec * 1000L else seekReqSec = newSec
                        },
                        valueRange = clip.startSec.toFloat()..clip.endSec.toFloat().coerceAtLeast(clip.startSec + 1f),
                        colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = CoralPrimary)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onEditInStudio,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = VioletPulse),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Studio")
                    }
                    Button(
                        onClick = onScheduleClip,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color.Black),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Post", fontWeight = FontWeight.Bold)
                    }
                    if (!isLocalVideo && clip.youtubeVideoId.isNotBlank()) {
                        OutlinedButton(
                            onClick = onOpenYouTube,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Watch on YouTube", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
