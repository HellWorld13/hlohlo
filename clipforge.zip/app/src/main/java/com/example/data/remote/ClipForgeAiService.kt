package com.example.data.remote

import android.net.Uri
import android.util.Log
import com.example.BuildConfig
import com.example.data.local.AppSettings
import com.example.data.local.AppSettingsStore
import com.example.data.media.OnDeviceSignalAnalyzer
import com.example.data.model.AnalyticsRecordDoc
import com.example.data.model.CaptionCue
import com.example.data.model.ClipTransition
import com.example.data.model.FilterPreset
import com.example.data.model.MusicTrack
import com.example.data.model.SocialPlatform
import com.example.data.model.SpeedCurvePreset
import com.example.data.model.StudioTemplate
import com.example.data.model.SubtitleStyle
import com.example.data.model.ThumbnailTemplate
import com.example.data.model.VideoEffect
import com.example.data.model.ViralClipDoc
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

data class SeoMetadataResult(
    val seoTitle: String,
    val seoDescription: String,
    val seoTags: List<String>
)

data class GrowthInsightResult(
    val headline: String,
    val recommendation: String,
    val bestPostingWindow: String,
    val nextHookIdea: String
)

data class SuperAiResult(
    val clips: List<ViralClipDoc>,
    val searchQueriesUsed: List<String>,
    val discoveredSourcesSummary: String
)

/**
 * Hybrid Groq LLM + On-Device Autonomous Studio Engine.
 * - Reads GROQ_API_KEY securely from BuildConfig (Secrets Gradle Plugin -> .env / AI Studio Secrets panel).
 * - Uses Groq (llama-3.3-70b-versatile) when configured for ultra-smart transcript/chapter highlight selection,
 *   viral hooks, synced subtitles, CapCut Smart Director tuning, SEO boost, and analytics insights.
 * - Seamlessly falls back to the built-in on-device transcript, chapter, and MediaCodec RMS signal engine
 *   whenever offline or before GROQ_API_KEY is configured.
 */
class ClipForgeAiService(
    private val youTubeMetadataService: YouTubeMetadataService = YouTubeMetadataService(),
    private val settingsStore: AppSettingsStore? = null,
    private val signalAnalyzer: OnDeviceSignalAnalyzer? = null
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun isGroqConfigured(): Boolean {
        val key = BuildConfig.GROQ_API_KEY.trim()
        return key.isNotBlank() &&
            !key.equals("MY_GROQ_API_KEY", ignoreCase = true) &&
            !key.equals("null", ignoreCase = true) &&
            key.length > 12
    }

    private suspend fun callGroqJson(prompt: String, temperature: Double = 0.35): String? = withContext(Dispatchers.IO) {
        if (!isGroqConfigured()) return@withContext null
        val apiKey = BuildConfig.GROQ_API_KEY.trim()
        try {
            val payload = JSONObject().apply {
                put("model", GROQ_MODEL)
                put("temperature", temperature)
                put(
                    "messages",
                    JSONArray().apply {
                        put(
                            JSONObject().apply {
                                put("role", "system")
                                put(
                                    "content",
                                    "You are ClipForge Pro AI, an elite viral short-form video producer and CapCut/TikTok strategist. Always output ONLY valid JSON matching the requested schema."
                                )
                            }
                        )
                        put(
                            JSONObject().apply {
                                put("role", "user")
                                put("content", prompt)
                            }
                        )
                    }
                )
                put("response_format", JSONObject().apply { put("type", "json_object") })
            }

            val req = Request.Builder()
                .url(GROQ_CHAT_ENDPOINT)
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    Log.w(TAG, "Groq HTTP ${resp.code}: ${raw.take(220)}")
                    return@withContext null
                }
                val root = JSONObject(raw)
                val choices = root.optJSONArray("choices") ?: return@withContext null
                if (choices.length() == 0) return@withContext null
                val content = choices.getJSONObject(0)
                    .optJSONObject("message")
                    ?.optString("content")
                    .orEmpty()
                    .trim()
                stripJsonFences(content).ifBlank { null }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Groq fallback triggered: ${e.message}")
            null
        }
    }

    private fun stripJsonFences(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("```")) {
            val firstNewline = trimmed.indexOf('\n')
            val lastFence = trimmed.lastIndexOf("```")
            if (firstNewline > 0 && lastFence > firstNewline) {
                return trimmed.substring(firstNewline + 1, lastFence).trim()
            }
        }
        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        return if (firstBrace >= 0 && lastBrace > firstBrace) {
            trimmed.substring(firstBrace, lastBrace + 1)
        } else trimmed
    }

    private suspend fun loadSettings(): AppSettings {
        return runCatching { settingsStore?.currentSettings() }.getOrNull() ?: AppSettings()
    }

    suspend fun suggestSmartStudioEdits(
        clip: ViralClipDoc,
        platform: SocialPlatform
    ): Result<ViralClipDoc> = withContext(Dispatchers.Default) {
        val settings = loadSettings()
        val keywords = extractKeywords("${clip.title} ${clip.hook}")

        val groqPrompt = """
            Tune CapCut/TikTok studio parameters for this ${(clip.endSec - clip.startSec).coerceAtLeast(5L)}s video clip.
            Tone preference: "${settings.smartDirectorTone}"
            Target Platform: ${platform.label} (${platform.optimizationSpec})
            Title: "${clip.title}"
            Hook: "${clip.hook}"

            Return ONLY JSON with keys:
            {
              "hook": "punchy 3-second viral opening line",
              "overlayText": "2-4 word visual badge",
              "filterPreset": one of [${FilterPreset.entries.joinToString { "\"${it.name}\"" }}],
              "videoEffect": one of [${VideoEffect.entries.joinToString { "\"${it.name}\"" }}],
              "transitionType": one of [${ClipTransition.entries.joinToString { "\"${it.name}\"" }}],
              "subtitleStyle": one of [${SubtitleStyle.entries.joinToString { "\"${it.name}\"" }}],
              "musicTrack": one of [${MusicTrack.entries.joinToString { "\"${it.name}\"" }}],
              "playbackSpeed": number 1.0..1.25,
              "zoomScale": number 1.05..1.18,
              "brightness": number -0.05..0.10,
              "contrast": number 1.05..1.25,
              "saturation": number 1.05..1.25,
              "warmth": number -0.25..0.25,
              "vignette": number 0.0..0.32,
              "seoTitle": "high-CTR SEO title",
              "seoDescription": "2-sentence search description",
              "seoTags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"]
            }
        """.trimIndent()

        val groqRaw = callGroqJson(groqPrompt)
        if (groqRaw != null) {
            runCatching {
                val obj = JSONObject(groqRaw)
                val tags = parseTagsArray(obj.optJSONArray("seoTags"))
                return@withContext Result.success(
                    clip.copy(
                        hook = obj.optString("hook").ifBlank { clip.hook },
                        overlayText = obj.optString("overlayText").ifBlank { clip.overlayText.ifBlank { "WATCH THIS" } },
                        filterPreset = FilterPreset.fromRaw(obj.optString("filterPreset")).name,
                        videoEffect = VideoEffect.fromRaw(obj.optString("videoEffect")).name,
                        transitionType = ClipTransition.fromRaw(obj.optString("transitionType")).name,
                        subtitleStyle = SubtitleStyle.fromRaw(obj.optString("subtitleStyle")).name,
                        musicTrack = MusicTrack.fromRaw(obj.optString("musicTrack")).name,
                        playbackSpeed = obj.optDouble("playbackSpeed", 1.08).coerceIn(0.5, 2.0),
                        zoomScale = obj.optDouble("zoomScale", 1.10).coerceIn(1.0, 2.0),
                        brightness = obj.optDouble("brightness", 0.04).coerceIn(-0.4, 0.4),
                        contrast = obj.optDouble("contrast", 1.15).coerceIn(0.6, 1.8),
                        saturation = obj.optDouble("saturation", 1.16).coerceIn(0.0, 1.8),
                        warmth = obj.optDouble("warmth", 0.05).coerceIn(-0.8, 0.8),
                        vignette = obj.optDouble("vignette", 0.16).coerceIn(0.0, 0.8),
                        seoTitle = obj.optString("seoTitle").ifBlank { clip.seoTitle.ifBlank { clip.title } },
                        seoDescription = obj.optString("seoDescription").ifBlank { clip.seoDescription },
                        seoTags = tags.ifEmpty { clip.seoTags },
                        optimizedPlatform = platform.name,
                        aspectRatio = platform.targetRatio
                    )
                )
            }
        }

        // On-device fallback director
        val tone = settings.smartDirectorTone.lowercase(Locale.US)
        val primaryTopic = keywords.firstOrNull()?.replaceFirstChar { it.titlecase(Locale.US) } ?: "Moment"
        val preset = when {
            tone.contains("cinematic") -> DirectorPreset(
                FilterPreset.TEAL_ORANGE, VideoEffect.BLUR_VIGNETTE, ClipTransition.FADE_BLACK,
                SubtitleStyle.CAPTION_OUTLINE, MusicTrack.CINEMATIC_PULSE, 1.0, 1.06, 0.02, 1.18, 1.08, 0.12, 0.30, "WATCH CLOSELY"
            )
            tone.contains("podcast") -> DirectorPreset(
                FilterPreset.TUNGSTEN, VideoEffect.NONE, ClipTransition.ZOOM_IN,
                SubtitleStyle.YELLOW_CREATOR, MusicTrack.LOFI_CHILL, 1.05, 1.10, 0.04, 1.14, 1.12, 0.14, 0.14, "HOT TAKE"
            )
            tone.contains("fast") -> DirectorPreset(
                FilterPreset.CYBER_CYAN, VideoEffect.SHAKE_IMPACT, ClipTransition.WHIP_PAN,
                SubtitleStyle.NEON_BOX, MusicTrack.PHONK_DRIVE, 1.15, 1.16, 0.05, 1.22, 1.24, -0.06, 0.18, "WAIT FOR IT"
            )
            else -> DirectorPreset(
                FilterPreset.VIVID_POP, VideoEffect.ZOOM_PULSE, ClipTransition.ZOOM_IN,
                SubtitleStyle.HORMOZI_POP, MusicTrack.HYPER_BEAT, 1.08, 1.12, 0.04, 1.16, 1.20, 0.05, 0.16,
                "VIRAL $primaryTopic".take(18).uppercase(Locale.US)
            )
        }
        val seo = buildSeoForTopic(clip.title, clip.hook, keywords, platform)
        Result.success(
            clip.copy(
                hook = clip.hook.ifBlank { "Nobody talks about this $primaryTopic moment until now." },
                overlayText = preset.sticker,
                filterPreset = preset.filter.name,
                videoEffect = preset.fx.name,
                transitionType = preset.trans.name,
                subtitleStyle = preset.subStyle.name,
                musicTrack = preset.music.name,
                playbackSpeed = preset.speed,
                zoomScale = preset.zoom,
                brightness = preset.bright,
                contrast = preset.contrast,
                saturation = preset.sat,
                warmth = preset.warmth,
                vignette = preset.vig,
                seoTitle = seo.seoTitle,
                seoDescription = seo.seoDescription,
                seoTags = seo.seoTags,
                optimizedPlatform = platform.name,
                aspectRatio = platform.targetRatio
            )
        )
    }

    suspend fun runSuperAiAutopilot(
        niche: String,
        specificChannel: String,
        targetCount: Int = 10,
        onProgress: (String) -> Unit = {}
    ): Result<SuperAiResult> {
        return try {
            val desiredCount = targetCount.coerceAtLeast(10)
            val cleanNiche = niche.trim().ifBlank { "Trending Viral Moments & Podcasts" }
            val cleanChannel = specificChannel.trim()
            val settings = loadSettings()

            val searchQuery = if (cleanChannel.isNotBlank()) {
                "$cleanChannel $cleanNiche highlights"
            } else {
                "$cleanNiche viral clips highlights"
            }

            onProgress("Searching YouTube for \"$searchQuery\"...")
            val liveMetas = youTubeMetadataService.searchYouTubeVideos(searchQuery, maxResults = 8)
            val sources = if (liveMetas.isNotEmpty()) liveMetas else fallbackPublicSources(cleanNiche, cleanChannel)

            val engineLabel = if (isGroqConfigured()) "Groq Llama-3.3 70B" else "On-Device AI"
            onProgress("$engineLabel crafting $desiredCount pro-edited clips (30–90s)...")

            val sourcesSummary = sources.joinToString("\n") {
                "- Title: \"${it.title}\" | Channel: ${it.authorName} | URL: ${it.canonicalUrl} | ID: ${it.videoId}"
            }

            val groqPrompt = """
                Produce EXACTLY $desiredCount distinct, high-retention viral short clips (strictly 30 to 90 seconds each) from these YouTube videos:
                Niche: "$cleanNiche" ${if (cleanChannel.isNotBlank()) "| Channel: \"$cleanChannel\"" else ""}
                Sources:
                $sourcesSummary

                Return ONLY JSON:
                {
                  "clips": [
                    {
                      "sourceUrl": "https://www.youtube.com/watch?v=...",
                      "youtubeVideoId": "11-char ID",
                      "title": "punchy title max 55 chars",
                      "hook": "3-second viral opening hook",
                      "viralScore": 84..99,
                      "startSec": integer >= 0,
                      "durationSec": integer strictly between 30 and 90,
                      "subtitleStyle": one of [${SubtitleStyle.entries.joinToString { "\"${it.name}\"" }}],
                      "filterPreset": one of [${FilterPreset.entries.joinToString { "\"${it.name}\"" }}],
                      "thumbnailTemplate": one of [${ThumbnailTemplate.entries.joinToString { "\"${it.name}\"" }}],
                      "musicTrack": one of [${MusicTrack.entries.joinToString { "\"${it.name}\"" }}],
                      "optimizedPlatform": one of [${SocialPlatform.entries.joinToString { "\"${it.name}\"" }}],
                      "overlayText": "2-4 word viral sticker",
                      "seoTitle": "SEO optimized title",
                      "seoDescription": "2-sentence SEO description",
                      "seoTags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"],
                      "captions": [
                        {"startSec": integer, "endSec": integer, "text": "short caption line"}
                      ]
                    }
                  ]
                }
            """.trimIndent()

            val groqClips = callGroqJson(groqPrompt, temperature = 0.45)?.let { raw ->
                runCatching {
                    val root = JSONObject(raw)
                    val arr = root.getJSONArray("clips")
                    val nowMs = System.currentTimeMillis()
                    (0 until arr.length()).map { i ->
                        val obj = arr.getJSONObject(i)
                        val fallbackSrc = sources[i % sources.size]
                        val vidId = youTubeMetadataService.extractVideoId(
                            obj.optString("youtubeVideoId").ifBlank { obj.optString("sourceUrl") }
                        ) ?: fallbackSrc.videoId
                        val startSec = obj.optLong("startSec", (i * 65L) + 15L).coerceIn(0L, 7200L)
                        val dur = obj.optLong("durationSec", 48L).coerceIn(30L, 90L)
                        val endSec = startSec + dur
                        val title = obj.optString("title").ifBlank { "${fallbackSrc.title.take(32)} • Highlight #${i + 1}" }
                        val hook = obj.optString("hook").ifBlank { "Wait for the turning point." }
                        val captions = parseCaptionsArray(obj.optJSONArray("captions"), startSec, endSec)
                            .ifEmpty { buildRhythmicCaptions(title, hook, startSec, endSec) }
                        val tags = parseTagsArray(obj.optJSONArray("seoTags"))
                            .ifEmpty { listOf("#viral", "#shorts", "#fyp", "#trending") }

                        val styleTpl = StudioTemplate.entries[i % StudioTemplate.entries.size]
                        ViralClipDoc(
                            mediaId = "",
                            sourceUrl = "https://www.youtube.com/watch?v=$vidId",
                            youtubeVideoId = vidId,
                            thumbnailUrl = "https://img.youtube.com/vi/$vidId/hqdefault.jpg",
                            title = title,
                            hook = hook,
                            viralScore = obj.optLong("viralScore", 91L).coerceIn(80L, 99L),
                            hookScore = obj.optLong("hookScore", 92L).coerceIn(78L, 99L),
                            viralReason = obj.optString("viralReason")
                                .ifBlank { "Strong 3s hook • ${dur}s retention arc • Auto-cleaned pacing" },
                            startSec = startSec,
                            endSec = endSec,
                            subtitlesEnabled = true,
                            subtitleStyle = SubtitleStyle.fromRaw(obj.optString("subtitleStyle")).name,
                            captions = captions,
                            aspectRatio = "9:16",
                            filterPreset = FilterPreset.fromRaw(obj.optString("filterPreset")).name,
                            filterIntensity = 0.92,
                            playbackSpeed = styleTpl.speed,
                            speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
                            zoomScale = styleTpl.zoom,
                            brightness = 0.03,
                            contrast = styleTpl.contrast,
                            saturation = styleTpl.saturation,
                            videoEffect = styleTpl.effect.name,
                            transitionType = styleTpl.transition.name,
                            silenceRemoved = true,
                            studioTemplateId = styleTpl.name,
                            voiceVolume = 1.0,
                            musicTrack = MusicTrack.fromRaw(obj.optString("musicTrack")).name.let {
                                if (it == MusicTrack.NONE.name) styleTpl.musicTrack.name else it
                            },
                            musicVolume = 0.22,
                            noiseReduction = true,
                            overlayText = obj.optString("overlayText").ifBlank { styleTpl.overlayBadge },
                            thumbnailTemplate = ThumbnailTemplate.fromRaw(obj.optString("thumbnailTemplate")).name,
                            exportResolution = settings.defaultExportResolution,
                            exportFps = settings.defaultExportFps,
                            exportBitrate = settings.defaultExportBitrate,
                            exportFormat = settings.defaultExportFormat,
                            optimizedPlatform = SocialPlatform.fromRaw(obj.optString("optimizedPlatform")).name,
                            seoTitle = obj.optString("seoTitle").ifBlank { title },
                            seoDescription = obj.optString("seoDescription").ifBlank { "Auto-edited 30-90s highlight clip." },
                            seoTags = tags,
                            exportedPath = "superai://pro_edit_${i + 1}.mp4",
                            waveformBars = OnDeviceSignalAnalyzer.generateSynthesizedWaveform(title + vidId),
                            createdEpochMs = nowMs + i,
                            superAiGenerated = true
                        )
                    }
                }.getOrNull()
            }.orEmpty()

            val builtClips = if (groqClips.size >= desiredCount) {
                groqClips.take(desiredCount)
            } else {
                val needed = desiredCount - groqClips.size
                groqClips + buildFallbackSuperClips(needed, sources, cleanNiche, settings, groqClips.size)
            }

            val summary = buildString {
                append(if (isGroqConfigured()) "Groq Llama-3.3 70B" else "On-Device AI")
                if (liveMetas.isNotEmpty()) append(" • ${liveMetas.size} live YT videos")
                if (cleanChannel.isNotBlank()) append(" ($cleanChannel)")
            }

            Result.success(
                SuperAiResult(
                    clips = builtClips,
                    searchQueriesUsed = listOf(searchQuery),
                    discoveredSourcesSummary = summary
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun analyzeVideoAndGenerateClips(
        videoTitle: String,
        authorName: String,
        sourceUrl: String,
        youtubeVideoId: String,
        thumbnailUrl: String,
        mediaId: String,
        targetPlatform: SocialPlatform,
        includeSubtitles: Boolean,
        durationHintSec: Long = 480L,
        clipCount: Int = 3,
        minClipSec: Long = 30L,
        maxClipSec: Long = 90L,
        description: String = "",
        chapters: List<YouTubeChapter> = emptyList(),
        transcriptCues: List<YouTubeTranscriptCue> = emptyList(),
        heatMarkers: List<YouTubeHeatMarker> = emptyList()
    ): Result<List<ViralClipDoc>> {
        return try {
            val settings = loadSettings()
            val desiredCount = clipCount.coerceIn(1, 10)
            val safeMin = minClipSec.coerceIn(30L, 90L)
            val safeMax = maxClipSec.coerceIn(safeMin, 90L)
            val isLocalFile = sourceUrl.startsWith("content://") || sourceUrl.startsWith("file://")
            val keywords = extractKeywords("$videoTitle $authorName $description")

            if (isLocalFile && signalAnalyzer != null) {
                val signal = signalAnalyzer.analyzeVideoHighlights(
                    uri = Uri.parse(sourceUrl),
                    seedTitle = videoTitle,
                    durationHintSec = durationHintSec,
                    clipCount = desiredCount,
                    minClipSec = safeMin,
                    maxClipSec = safeMax
                )
                val templates = listOf(
                    StudioTemplate.VIRAL_HOOK,
                    StudioTemplate.OPUS_HORMOZI,
                    StudioTemplate.CINEMA_REEL,
                    StudioTemplate.CYBER_REVIEW
                )
                val clips = signal.peakWindows.take(desiredCount).mapIndexed { idx, window ->
                    val tpl = templates[idx % templates.size]
                    val title = "${videoTitle.take(30)} • ${window.label}"
                    val hook = buildHookLine(videoTitle, authorName, window.label, idx)
                    val captions = buildRhythmicCaptions(title, hook, window.startSec, window.endSec)
                    val seo = buildSeoForTopic(title, hook, keywords, targetPlatform)

                    ViralClipDoc(
                        mediaId = mediaId,
                        sourceUrl = sourceUrl,
                        youtubeVideoId = "",
                        thumbnailUrl = window.thumbnailPath.ifBlank { thumbnailUrl },
                        title = title,
                        hook = hook,
                        viralScore = window.peakScore,
                        hookScore = (window.peakScore + 2L).coerceIn(80L, 99L),
                        viralReason = "RMS audio peak (${window.peakScore}%) • ${window.endSec - window.startSec}s high-energy highlight",
                        startSec = window.startSec,
                        endSec = window.endSec,
                        subtitlesEnabled = includeSubtitles,
                        subtitleStyle = tpl.subtitleStyle.name,
                        captions = captions,
                        aspectRatio = targetPlatform.targetRatio,
                        filterPreset = tpl.filter.name,
                        filterIntensity = 0.90,
                        playbackSpeed = tpl.speed,
                        speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
                        zoomScale = tpl.zoom,
                        contrast = tpl.contrast,
                        saturation = tpl.saturation,
                        videoEffect = tpl.effect.name,
                        transitionType = tpl.transition.name,
                        studioTemplateId = tpl.name,
                        overlayText = tpl.overlayBadge,
                        thumbnailTemplate = tpl.thumbnailTemplate.name,
                        exportResolution = settings.defaultExportResolution,
                        exportFps = settings.defaultExportFps,
                        exportBitrate = settings.defaultExportBitrate,
                        exportFormat = settings.defaultExportFormat,
                        optimizedPlatform = targetPlatform.name,
                        seoTitle = seo.seoTitle,
                        seoDescription = seo.seoDescription,
                        seoTags = seo.seoTags,
                        waveformBars = signal.waveformBars,
                        createdEpochMs = System.currentTimeMillis() + idx
                    )
                }
                return Result.success(clips)
            }

            // YouTube / Remote Video: ensure strictly 30..90s clips when video >= 30s
            val actualDur = durationHintSec.coerceAtLeast(15L)
            val effectiveCount = if (actualDur < safeMin) 1 else desiredCount
            val chaptersSnippet = if (chapters.isNotEmpty()) {
                "Video Chapters:\n" + chapters.joinToString("\n") { "[${it.startSec}s] ${it.title}" }
            } else ""

            val heatmapSnippet = if (heatMarkers.isNotEmpty()) {
                "YouTube Most-Replayed Viewer Retention Spikes:\n" + heatMarkers.take(10).joinToString("\n") {
                    "[${it.startSec}s-${it.endSec}s] Replay Intensity=${(it.intensity * 100).toInt()}%"
                }
            } else ""

            val transcriptSnippet = if (transcriptCues.isNotEmpty()) {
                val sampled = if (transcriptCues.size <= 80) transcriptCues else {
                    val step = (transcriptCues.size / 80).coerceAtLeast(1)
                    transcriptCues.filterIndexed { index, _ -> index % step == 0 }
                }
                "Transcript Excerpts with Timestamps:\n" + sampled.joinToString("\n") {
                    "[${it.startSec}s] ${it.text}"
                }.take(6500)
            } else {
                "Description:\n${description.take(1200)}"
            }

            val wave = OnDeviceSignalAnalyzer.generateSynthesizedWaveform(videoTitle + youtubeVideoId)

            // Try Groq LLM first if configured!
            if (isGroqConfigured()) {
                val groqPrompt = """
                    Analyze this YouTube video using Opus Clip / Vizard virality principles and extract EXACTLY $effectiveCount distinct, non-overlapping viral clips.
                    - Video Title: "$videoTitle"
                    - Channel: "$authorName"
                    - Total Video Duration: ${actualDur}s
                    - Target Platform: ${targetPlatform.label} (${targetPlatform.optimizationSpec})
                    $heatmapSnippet
                    $chaptersSnippet
                    $transcriptSnippet

                    STRICT RULES:
                    1. EVERY clip duration (endSec - startSec) MUST be strictly between $safeMin and $safeMax seconds (inclusive: $safeMin..$safeMax), unless total video duration < $safeMin.
                    2. startSec >= 0 and endSec <= $actualDur.
                    3. Prioritize Most-Replayed heatmap spikes, strong 3-second opening hooks, controversies, emotional peaks, and complete story arcs.
                    4. Start and end on natural spoken sentence/topic boundaries (never cut mid-thought).
                    5. Captions must lie inside [startSec, endSec] and reflect the real video topic/transcript.

                    Return ONLY JSON:
                    {
                      "clips": [
                        {
                          "title": "short punchy title (max 55 chars)",
                          "hook": "3-second attention-grabbing opening hook",
                          "viralScore": 82..99,
                          "hookScore": 80..99,
                          "viralReason": "short 1-line reason why viewers won't scroll past",
                          "startSec": integer,
                          "endSec": integer,
                          "subtitleStyle": one of [${SubtitleStyle.entries.joinToString { "\"${it.name}\"" }}],
                          "filterPreset": one of [${FilterPreset.entries.joinToString { "\"${it.name}\"" }}],
                          "thumbnailTemplate": one of [${ThumbnailTemplate.entries.joinToString { "\"${it.name}\"" }}],
                          "overlayText": "2-4 word viral sticker",
                          "seoTitle": "search-optimized title",
                          "seoDescription": "2-sentence SEO description",
                          "seoTags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"],
                          "captions": [
                            {"startSec": integer, "endSec": integer, "text": "caption line"}
                          ]
                        }
                      ]
                    }
                """.trimIndent()

                val groqRaw = callGroqJson(groqPrompt, temperature = 0.35)
                if (groqRaw != null) {
                    val parsed = runCatching {
                        val root = JSONObject(groqRaw)
                        val arr = root.getJSONArray("clips")
                        val nowMs = System.currentTimeMillis()
                        (0 until arr.length()).take(effectiveCount).map { idx ->
                            val obj = arr.getJSONObject(idx)
                            val maxPossibleLen = actualDur.coerceAtMost(safeMax)
                            val minPossibleLen = actualDur.coerceAtMost(safeMin)
                            val rawStart = obj.optLong("startSec", idx * safeMin).coerceIn(0L, (actualDur - minPossibleLen).coerceAtLeast(0L))
                            val rawEnd = obj.optLong("endSec", rawStart + ((safeMin + safeMax) / 2L))
                            val clampedDur = (rawEnd - rawStart).coerceIn(minPossibleLen, maxPossibleLen)
                            val candidateStart = rawStart.coerceAtMost((actualDur - clampedDur).coerceAtLeast(0L))
                            val candidateEnd = (candidateStart + clampedDur).coerceAtMost(actualDur)
                            val (finalStart, finalEnd) = snapWindowToTranscript(
                                startSec = candidateStart,
                                endSec = candidateEnd,
                                totalDur = actualDur,
                                minLen = minPossibleLen,
                                maxLen = maxPossibleLen,
                                transcriptCues = transcriptCues
                            )

                            val title = obj.optString("title").ifBlank { "${videoTitle.take(32)} • Highlight #${idx + 1}" }
                            val hook = obj.optString("hook").ifBlank { buildHookLine(videoTitle, authorName, "Viral Cut", idx) }
                            val transcriptSlice = sliceTranscriptCues(transcriptCues, finalStart, finalEnd)
                            val rawCaptions = transcriptSlice.ifEmpty {
                                parseCaptionsArray(obj.optJSONArray("captions"), finalStart, finalEnd)
                            }.ifEmpty {
                                buildRhythmicCaptions(title, hook, finalStart, finalEnd)
                            }
                            val captions = cleanCaptionCuesFillers(rawCaptions)
                            val tags = parseTagsArray(obj.optJSONArray("seoTags"))
                                .ifEmpty { buildSeoForTopic(title, hook, keywords, targetPlatform).seoTags }
                            val matchingHeat = heatMarkers.firstOrNull { it.startSec in finalStart..finalEnd }
                            val reason = obj.optString("viralReason").ifBlank {
                                if (matchingHeat != null) {
                                    "Replay spike ${(matchingHeat.intensity * 100).toInt()}% • Strong 3s hook • ${finalEnd - finalStart}s story arc"
                                } else {
                                    "Strong 3s hook • Clean transcript arc • ${finalEnd - finalStart}s pacing"
                                }
                            }
                            val tpl = StudioTemplate.entries[idx % StudioTemplate.entries.size]

                            ViralClipDoc(
                                mediaId = mediaId,
                                sourceUrl = sourceUrl,
                                youtubeVideoId = youtubeVideoId,
                                thumbnailUrl = thumbnailUrl,
                                title = title,
                                hook = hook,
                                viralScore = obj.optLong("viralScore", 92L).coerceIn(78L, 99L),
                                hookScore = obj.optLong("hookScore", 91L).coerceIn(78L, 99L),
                                viralReason = reason,
                                startSec = finalStart,
                                endSec = finalEnd,
                                subtitlesEnabled = includeSubtitles,
                                subtitleStyle = SubtitleStyle.fromRaw(obj.optString("subtitleStyle")).name,
                                captions = captions,
                                aspectRatio = targetPlatform.targetRatio,
                                filterPreset = FilterPreset.fromRaw(obj.optString("filterPreset")).name,
                                filterIntensity = 0.92,
                                playbackSpeed = tpl.speed,
                                speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
                                zoomScale = tpl.zoom,
                                contrast = tpl.contrast,
                                saturation = tpl.saturation,
                                videoEffect = tpl.effect.name,
                                transitionType = tpl.transition.name,
                                silenceRemoved = true,
                                studioTemplateId = tpl.name,
                                overlayText = obj.optString("overlayText").ifBlank { tpl.overlayBadge },
                                thumbnailTemplate = ThumbnailTemplate.fromRaw(obj.optString("thumbnailTemplate")).name,
                                exportResolution = settings.defaultExportResolution,
                                exportFps = settings.defaultExportFps,
                                exportBitrate = settings.defaultExportBitrate,
                                exportFormat = settings.defaultExportFormat,
                                optimizedPlatform = targetPlatform.name,
                                seoTitle = obj.optString("seoTitle").ifBlank { title },
                                seoDescription = obj.optString("seoDescription").ifBlank { "Viral highlight clipped by Groq AI." },
                                seoTags = tags,
                                waveformBars = wave,
                                createdEpochMs = nowMs + idx
                            )
                        }
                    }.getOrNull()

                    if (!parsed.isNullOrEmpty()) {
                        return Result.success(parsed)
                    }
                }
            }

            // Deterministic On-Device Retention Heatmap + Transcript + Chapter Highlight Slicer (strictly 30..90s!)
            val slots = computeSmartWindows(
                totalDurationSec = actualDur,
                count = effectiveCount,
                minLenSec = safeMin,
                maxLenSec = safeMax,
                chapters = chapters,
                transcriptCues = transcriptCues,
                heatMarkers = heatMarkers
            )
            val templates = listOf(
                StudioTemplate.VIRAL_HOOK,
                StudioTemplate.OPUS_HORMOZI,
                StudioTemplate.CYBER_REVIEW,
                StudioTemplate.CINEMA_REEL,
                StudioTemplate.PODCAST_SPLIT
            )

            val clips = slots.mapIndexed { idx, slot ->
                val (s, e, contextReason) = slot
                val tpl = templates[idx % templates.size]
                val cleanBase = contextReason?.substringBefore("•")?.trim()?.take(32)
                    ?: videoTitle.split(Regex("[-|:]")).first().trim().take(30).ifBlank { videoTitle.take(28) }
                val angleLabel = listOf("Retention Peak", "Hook Cut", "Core Secret", "Climax Takeaway", "Pro Breakdown")[idx % 5]
                val title = "$cleanBase • $angleLabel"
                val realCues = cleanCaptionCuesFillers(sliceTranscriptCues(transcriptCues, s, e))
                val hook = realCues.firstOrNull()?.text?.take(110)
                    ?: buildHookLine(videoTitle, authorName, angleLabel, idx)
                val captions = realCues.ifEmpty { buildRhythmicCaptions(title, hook, s, e) }
                val seo = buildSeoForTopic(title, hook, keywords, targetPlatform)
                val hookScoreVal = computeHookScore(hook, realCues.size)
                val viralScoreVal = ((94L - idx * 2L) + if (contextReason?.contains("Heatmap", true) == true) 3L else 0L).coerceIn(82L, 98L)
                val reason = contextReason ?: "High speech density • ${e - s}s complete arc • Cleaned fillers"

                ViralClipDoc(
                    mediaId = mediaId,
                    sourceUrl = sourceUrl,
                    youtubeVideoId = youtubeVideoId,
                    thumbnailUrl = thumbnailUrl,
                    title = title,
                    hook = hook,
                    viralScore = viralScoreVal,
                    hookScore = hookScoreVal,
                    viralReason = reason,
                    startSec = s,
                    endSec = e,
                    subtitlesEnabled = includeSubtitles,
                    subtitleStyle = tpl.subtitleStyle.name,
                    captions = captions,
                    aspectRatio = targetPlatform.targetRatio,
                    filterPreset = tpl.filter.name,
                    filterIntensity = 0.90,
                    playbackSpeed = tpl.speed,
                    speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
                    zoomScale = tpl.zoom,
                    contrast = tpl.contrast,
                    saturation = tpl.saturation,
                    videoEffect = tpl.effect.name,
                    transitionType = tpl.transition.name,
                    silenceRemoved = true,
                    studioTemplateId = tpl.name,
                    overlayText = tpl.overlayBadge,
                    thumbnailTemplate = tpl.thumbnailTemplate.name,
                    exportResolution = settings.defaultExportResolution,
                    exportFps = settings.defaultExportFps,
                    exportBitrate = settings.defaultExportBitrate,
                    exportFormat = settings.defaultExportFormat,
                    optimizedPlatform = targetPlatform.name,
                    seoTitle = seo.seoTitle,
                    seoDescription = seo.seoDescription,
                    seoTags = seo.seoTags,
                    waveformBars = wave,
                    createdEpochMs = System.currentTimeMillis() + idx
                )
            }
            Result.success(clips)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun generateSeoMetadata(
        clipTitle: String,
        hook: String,
        captionSummary: String,
        platform: SocialPlatform
    ): Result<SeoMetadataResult> = withContext(Dispatchers.Default) {
        val keywords = extractKeywords("$clipTitle $hook $captionSummary")
        if (isGroqConfigured()) {
            val prompt = """
                Generate high-CTR short-form SEO copy for ${platform.label} (${platform.optimizationSpec}):
                Title: "$clipTitle"
                Hook: "$hook"
                Transcript/Summary: "${captionSummary.take(400)}"
                Return ONLY JSON: {"seoTitle": "max 85 chars", "seoDescription": "2-sentence CTA description", "seoTags": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5", "#tag6"]}
            """.trimIndent()
            callGroqJson(prompt)?.let { raw ->
                runCatching {
                    val obj = JSONObject(raw)
                    val seoTitle = obj.optString("seoTitle").trim()
                    val seoDesc = obj.optString("seoDescription").trim()
                    val tags = parseTagsArray(obj.optJSONArray("seoTags"))
                    if (seoTitle.isNotBlank() && seoDesc.isNotBlank()) {
                        return@withContext Result.success(
                            SeoMetadataResult(seoTitle, seoDesc, tags.ifEmpty { keywords.map { "#$it" } })
                        )
                    }
                }
            }
        }
        Result.success(buildSeoForTopic(clipTitle, hook, keywords, platform))
    }

    suspend fun regenerateCaptions(
        clipTitle: String,
        hook: String,
        startSec: Long,
        endSec: Long
    ): Result<List<CaptionCue>> = withContext(Dispatchers.Default) {
        if (isGroqConfigured()) {
            val prompt = """
                Generate 5 punchy short-form subtitle cues for a clip from ${startSec}s to ${endSec}s.
                Title: "$clipTitle"
                Hook: "$hook"
                Return ONLY JSON: {"captions": [{"startSec": int, "endSec": int, "text": "max 9 words"}]}
            """.trimIndent()
            callGroqJson(prompt)?.let { raw ->
                runCatching {
                    val arr = JSONObject(raw).optJSONArray("captions")
                    val cues = parseCaptionsArray(arr, startSec, endSec)
                    if (cues.isNotEmpty()) return@withContext Result.success(cues)
                }
            }
        }
        Result.success(buildRhythmicCaptions(clipTitle, hook, startSec, endSec))
    }

    suspend fun syncScriptToCaptions(
        rawScript: String,
        startSec: Long,
        endSec: Long
    ): List<CaptionCue> = withContext(Dispatchers.Default) {
        val totalDur = (endSec - startSec).coerceAtLeast(4L)
        val rawSentences = rawScript
            .replace("\r", "\n")
            .split(Regex("[.!?\n]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val phrases = mutableListOf<String>()
        rawSentences.forEach { sentence ->
            val words = sentence.split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (words.size <= 6) {
                phrases.add(words.joinToString(" "))
            } else {
                words.chunked(5).forEach { chunk ->
                    phrases.add(chunk.joinToString(" "))
                }
            }
        }

        val finalLines = phrases.take(36).ifEmpty { listOf("Add your caption line here") }
        val step = (totalDur.toDouble() / finalLines.size).coerceAtLeast(1.0)
        finalLines.mapIndexed { idx, line ->
            val cStart = (startSec + (idx * step).toLong()).coerceIn(startSec, endSec - 1L)
            val cEnd = if (idx == finalLines.lastIndex) {
                endSec
            } else {
                (startSec + ((idx + 1) * step).toLong()).coerceIn(cStart + 1L, endSec)
            }
            CaptionCue(startSec = cStart, endSec = cEnd, text = line.take(90))
        }
    }

    suspend fun generateAnalyticsGrowthInsights(
        records: List<AnalyticsRecordDoc>,
        clips: List<ViralClipDoc>
    ): Result<GrowthInsightResult> = withContext(Dispatchers.Default) {
        if (isGroqConfigured() && records.isNotEmpty()) {
            val summary = records.take(12).joinToString("\n") {
                "${it.platform} | ${it.clipTitle} | views=${it.views}, likes=${it.likes}, shares=${it.shares}, retention=${it.retentionPercent}%"
            }
            val prompt = """
                Analyze this creator's short-form performance and provide actionable advice:
                $summary
                Return ONLY JSON: {"headline": "short punchy metric headline", "recommendation": "2 sentences", "bestPostingWindow": "e.g. 6:30 PM - 9:30 PM", "nextHookIdea": "sample opening hook"}
            """.trimIndent()
            callGroqJson(prompt)?.let { raw ->
                runCatching {
                    val obj = JSONObject(raw)
                    val headline = obj.optString("headline")
                    val rec = obj.optString("recommendation")
                    if (headline.isNotBlank() && rec.isNotBlank()) {
                        return@withContext Result.success(
                            GrowthInsightResult(
                                headline = headline,
                                recommendation = rec,
                                bestPostingWindow = obj.optString("bestPostingWindow").ifBlank { "6:30 PM – 9:30 PM" },
                                nextHookIdea = obj.optString("nextHookIdea").ifBlank { "\"Wait until you try this 30-second switch...\"" }
                            )
                        )
                    }
                }
            }
        }

        if (records.isEmpty()) {
            val topClip = clips.maxByOrNull { it.viralScore }
            val suggestedPlatform = topClip?.let { SocialPlatform.fromRaw(it.optimizedPlatform) } ?: SocialPlatform.TIKTOK
            return@withContext Result.success(
                GrowthInsightResult(
                    headline = "Ready for Launch • ${clips.size} Clip(s) Queued",
                    recommendation = if (topClip != null) {
                        "Publish \"${topClip.title.take(34)}\" (${topClip.viralScore}% Viral Score) with ${topClip.subtitleStyle.replace('_', ' ')} captions to capture your first engagement baseline."
                    } else {
                        "Clip a YouTube URL or upload a device video and publish to ${suggestedPlatform.shortLabel} to unlock retention benchmarks."
                    },
                    bestPostingWindow = suggestedPlatform.defaultPeakWindow,
                    nextHookIdea = "\"Here is the 1 thing nobody tells you about ${topClip?.title?.take(28) ?: "this workflow"}...\""
                )
            )
        }

        val totalViews = records.sumOf { it.views }.coerceAtLeast(1L)
        val avgRetention = records.map { it.retentionPercent }.average().toInt().coerceIn(0, 100)
        val byPlatform = records.groupBy { SocialPlatform.fromRaw(it.platform) }
        val topPlatform = byPlatform.maxByOrNull { (_, list) ->
            val v = list.sumOf { it.views }.coerceAtLeast(1L)
            val eng = list.sumOf { it.likes + it.comments * 2L + it.shares * 3L }
            (eng * 1000.0) / v + list.sumOf { it.views } * 0.01
        }?.key ?: SocialPlatform.TIKTOK
        val topRecord = records.maxByOrNull { it.views + it.shares * 8L }
        val engRate = ((records.sumOf { it.likes + it.comments + it.shares } * 100.0) / totalViews)
        val formattedRate = String.format(Locale.US, "%.1f", engRate)

        val recommendation = buildString {
            append("${topPlatform.label} leads with ${formattedRate}% engagement and ${avgRetention}% avg retention. ")
            if (avgRetention < 70) {
                append("Tighten your opening 3s hook with Beat Zoom + Hormozi Pop captions to lift retention above 75%.")
            } else {
                append("Double down on the pacing style of \"${topRecord?.clipTitle?.take(28) ?: "your top clip"}\" and cross-post to ${SocialPlatform.YOUTUBE_SHORTS.shortLabel}.")
            }
        }
        val hookTopic = extractKeywords(topRecord?.clipTitle.orEmpty() + " " + clips.firstOrNull()?.title.orEmpty()).firstOrNull() ?: "creator growth"

        Result.success(
            GrowthInsightResult(
                headline = "${topPlatform.shortLabel} Leading • $avgRetention% Avg Retention",
                recommendation = recommendation,
                bestPostingWindow = topPlatform.defaultPeakWindow,
                nextHookIdea = "\"Stop doing $hookTopic the slow way — try this 30-second switch instead.\""
            )
        )
    }

    private fun snapWindowToTranscript(
        startSec: Long,
        endSec: Long,
        totalDur: Long,
        minLen: Long,
        maxLen: Long,
        transcriptCues: List<YouTubeTranscriptCue>
    ): Pair<Long, Long> {
        if (transcriptCues.isEmpty()) return startSec to endSec
        val safeTotal = totalDur.coerceAtLeast(15L)
        val effMin = minLen.coerceAtMost(safeTotal)
        val effMax = maxLen.coerceIn(effMin, safeTotal)

        // Snap start to a nearby spoken cue start (±5s)
        val nearestStart = transcriptCues
            .filter { abs(it.startSec - startSec) <= 5L }
            .minByOrNull { abs(it.startSec - startSec) }
            ?.startSec
            ?.coerceIn(0L, (safeTotal - effMin).coerceAtLeast(0L))
            ?: startSec

        // Snap end to a cue ending cleanly within [effMin, effMax]
        val idealEnd = (nearestStart + (endSec - startSec)).coerceIn(nearestStart + effMin, (nearestStart + effMax).coerceAtMost(safeTotal))
        val nearestEnd = transcriptCues
            .filter { it.endSec in (nearestStart + effMin)..(nearestStart + effMax).coerceAtMost(safeTotal) && abs(it.endSec - idealEnd) <= 6L }
            .minByOrNull { abs(it.endSec - idealEnd) }
            ?.endSec
            ?: idealEnd

        return nearestStart to nearestEnd.coerceIn(nearestStart + effMin, safeTotal)
    }

    fun cleanClipFillersAndPacing(clip: ViralClipDoc): ViralClipDoc {
        val cleanedCaptions = cleanCaptionCuesFillers(clip.captions)
        val trimmedPacingSpeed = if (clip.playbackSpeed < 1.06) 1.08 else clip.playbackSpeed
        val reason = if (clip.viralReason.contains("Dead-air", ignoreCase = true)) {
            clip.viralReason
        } else {
            val base = clip.viralReason.ifBlank { "30–90s highlight" }
            "$base • Dead-air & fillers removed"
        }
        return clip.copy(
            captions = cleanedCaptions,
            playbackSpeed = trimmedPacingSpeed,
            speedCurvePreset = SpeedCurvePreset.JUMP_CUT.name,
            silenceRemoved = true,
            viralReason = reason
        )
    }

    private fun cleanCaptionCuesFillers(cues: List<CaptionCue>): List<CaptionCue> {
        if (cues.isEmpty()) return emptyList()
        val fillerRegex = Regex(
            """\b(?:um+|uh+|er+|ah+|you know|sort of|kind of|basically|literally)\b[,\s]*""",
            RegexOption.IGNORE_CASE
        )
        return cues.mapNotNull { cue ->
            val cleaned = fillerRegex.replace(cue.text, " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .trimStart(',', ' ')
            if (cleaned.isBlank()) null else cue.copy(text = cleaned.take(96))
        }
    }

    private fun computeHookScore(hook: String, cueCount: Int): Long {
        var score = 83L
        val lower = hook.lowercase(Locale.US)
        if (hook.contains("?") || hook.contains("!")) score += 5L
        if (listOf("secret", "never", "stop", "why", "wait", "truth", "mistake", "how", "nobody").any { lower.contains(it) }) {
            score += 6L
        }
        if (cueCount >= 5) score += 3L
        return score.coerceIn(78L, 99L)
    }

    private fun computeSmartWindows(
        totalDurationSec: Long,
        count: Int,
        minLenSec: Long,
        maxLenSec: Long,
        chapters: List<YouTubeChapter>,
        transcriptCues: List<YouTubeTranscriptCue>,
        heatMarkers: List<YouTubeHeatMarker> = emptyList()
    ): List<Triple<Long, Long, String?>> {
        val safeTotal = totalDurationSec.coerceAtLeast(15L)
        if (safeTotal < minLenSec) {
            return listOf(Triple(0L, safeTotal, chapters.firstOrNull()?.title))
        }

        val effMin = minLenSec.coerceIn(30L, 90L).coerceAtMost(safeTotal)
        val effMax = maxLenSec.coerceIn(effMin, 90L).coerceAtMost(safeTotal)
        val midTarget = ((effMin + effMax) / 2L).coerceIn(effMin, effMax)

        if (safeTotal <= 90L) {
            val len1 = safeTotal.coerceIn(effMin, effMax)
            val res = mutableListOf(Triple(0L, len1, chapters.firstOrNull()?.title))
            if (count > 1 && safeTotal >= effMin + 10L) {
                val len2 = (safeTotal - 8L).coerceIn(effMin, effMax)
                val s2 = (safeTotal - len2).coerceAtLeast(0L)
                if (s2 >= 4L) res.add(Triple(s2, safeTotal, chapters.getOrNull(1)?.title))
            }
            return res.take(count)
        }

        val chosen = mutableListOf<Triple<Long, Long, String?>>()

        // Priority 1: Real YouTube "Most Replayed" Retention Heatmap Spikes
        heatMarkers.sortedByDescending { it.intensity }.forEach { marker ->
            if (chosen.size >= count) return@forEach
            val targetLen = (effMin + ((chosen.size * 11L) % (effMax - effMin + 1L))).coerceIn(effMin, effMax)
            // Start 4s before the rewatch peak so the opening 3s hook leads right into the climax!
            val rawS = (marker.startSec - 4L).coerceIn(0L, (safeTotal - targetLen).coerceAtLeast(0L))
            val rawE = (rawS + targetLen).coerceAtMost(safeTotal)
            val (s, e) = snapWindowToTranscript(rawS, rawE, safeTotal, effMin, effMax, transcriptCues)
            if ((e - s) >= effMin && chosen.none { s < it.second - 6L && e > it.first + 6L }) {
                chosen.add(Triple(s, e, "Heatmap ${(marker.intensity * 100).toInt()}% Peak"))
            }
        }

        // Priority 2: Use real YouTube creator chapters snapped to cue boundaries
        chapters.forEach { chap ->
            if (chosen.size >= count) return@forEach
            val targetLen = (effMin + ((chosen.size * 13L) % (effMax - effMin + 1L))).coerceIn(effMin, effMax)
            val rawS = chap.startSec.coerceIn(0L, (safeTotal - targetLen).coerceAtLeast(0L))
            val rawE = (rawS + targetLen).coerceAtMost(safeTotal)
            val (s, e) = snapWindowToTranscript(rawS, rawE, safeTotal, effMin, effMax, transcriptCues)
            if (chosen.none { s < it.second - 6L && e > it.first + 6L } && (e - s) >= effMin) {
                chosen.add(Triple(s, e, chap.title))
            }
        }

        // Priority 3: Sliding-window transcript density & hook scoring across the whole timeline
        if (chosen.size < count && transcriptCues.isNotEmpty()) {
            val cueCandidates = transcriptCues.indices.filter { it % 2 == 0 }.map { startIdx ->
                val startCue = transcriptCues[startIdx]
                val targetLen = (effMin + ((startIdx * 9L) % (effMax - effMin + 1L))).coerceIn(effMin, effMax)
                val candStart = startCue.startSec.coerceIn(0L, (safeTotal - effMin).coerceAtLeast(0L))
                val candEnd = (candStart + targetLen).coerceAtMost(safeTotal)

                var windowScore = 0
                for (j in startIdx until transcriptCues.size) {
                    val c = transcriptCues[j]
                    if (c.startSec > candEnd) break
                    val txt = c.text
                    windowScore += txt.length.coerceAtMost(80)
                    if (txt.contains("?") || txt.contains("!")) windowScore += 45
                    if (txt.contains("secret", true) || txt.contains("never", true) ||
                        txt.contains("important", true) || txt.contains("reason", true) ||
                        txt.contains("best", true) || txt.contains("mistake", true)
                    ) {
                        windowScore += 35
                    }
                }
                Triple(candStart, candEnd, windowScore)
            }.sortedByDescending { it.third }

            for ((rawS, rawE, _) in cueCandidates) {
                if (chosen.size >= count) break
                val (s, e) = snapWindowToTranscript(rawS, rawE, safeTotal, effMin, effMax, transcriptCues)
                if ((e - s) >= effMin && chosen.none { s < it.second - 8L && e > it.first + 8L }) {
                    chosen.add(Triple(s, e, "Transcript Hook & High Density"))
                }
            }
        }

        // Priority 4: Distribute evenly across the timeline strictly respecting 30..90s
        var attempt = 0
        while (chosen.size < count && attempt < count * 3) {
            val targetLen = (effMin + ((attempt * 15L) % (effMax - effMin + 1L))).coerceIn(effMin, effMax)
            val usableSpan = (safeTotal - targetLen).coerceAtLeast(0L)
            val stride = (usableSpan / count.coerceAtLeast(1)).coerceAtLeast(1L)
            val rawS = ((attempt * stride) + (if (attempt == 0) 8L else 0L)).coerceIn(0L, usableSpan)
            val rawE = (rawS + targetLen).coerceAtMost(safeTotal)
            val (s, e) = snapWindowToTranscript(rawS, rawE, safeTotal, effMin, effMax, transcriptCues)
            if ((e - s) >= effMin && chosen.none { s < it.second - 8L && e > it.first + 8L }) {
                chosen.add(Triple(s, e, "Timeline Peak Arc #${chosen.size + 1}"))
            }
            attempt++
        }

        if (chosen.isEmpty()) {
            val s = 0L
            val e = midTarget.coerceIn(effMin, safeTotal)
            chosen.add(Triple(s, e, chapters.firstOrNull()?.title))
        }

        return chosen.take(count).sortedBy { it.first }
    }

    private fun sliceTranscriptCues(
        transcriptCues: List<YouTubeTranscriptCue>,
        startSec: Long,
        endSec: Long
    ): List<CaptionCue> {
        if (transcriptCues.isEmpty()) return emptyList()
        val inWindow = transcriptCues.filter { it.endSec >= startSec && it.startSec <= endSec }
        if (inWindow.isEmpty()) return emptyList()

        // Group tiny caption fragments into crisp 2-4 second short-form subtitle blocks covering up to 90s clips
        val merged = mutableListOf<CaptionCue>()
        var bufferText = StringBuilder()
        var blockStart = inWindow.first().startSec.coerceIn(startSec, endSec)
        var blockEnd = blockStart

        for (cue in inWindow) {
            if (bufferText.isEmpty()) {
                blockStart = cue.startSec.coerceIn(startSec, endSec)
                bufferText.append(cue.text)
                blockEnd = cue.endSec.coerceIn(blockStart + 1L, endSec)
            } else if (bufferText.length + cue.text.length < 48 && (cue.endSec - blockStart) <= 4L) {
                bufferText.append(" ").append(cue.text)
                blockEnd = cue.endSec.coerceIn(blockStart + 1L, endSec)
            } else {
                merged.add(CaptionCue(blockStart, blockEnd, bufferText.toString().trim().take(84)))
                bufferText = StringBuilder(cue.text)
                blockStart = cue.startSec.coerceIn(startSec, endSec)
                blockEnd = cue.endSec.coerceIn(blockStart + 1L, endSec)
            }
            if (merged.size >= 36) break
        }
        if (bufferText.isNotEmpty() && merged.size < 36) {
            merged.add(CaptionCue(blockStart, blockEnd, bufferText.toString().trim().take(84)))
        }
        return merged
    }

    private fun buildFallbackSuperClips(
        count: Int,
        sources: List<YouTubeVideoMetadata>,
        niche: String,
        settings: AppSettings,
        offset: Int
    ): List<ViralClipDoc> {
        val nowMs = System.currentTimeMillis()
        val angles = listOf(
            "Controversial Hook", "Hidden Breakdown", "Turning Point", "Pro Secret",
            "Mind-Blowing Fact", "Unfiltered Take", "Retention Peak", "Rapid Summary",
            "Behind The Scenes", "Final Plot Twist", "Creator Playbook", "Viral Moment"
        )
        val platforms = SocialPlatform.entries
        val subStyles = SubtitleStyle.entries
        val filters = listOf(
            FilterPreset.VIVID_POP, FilterPreset.CRISP_STUDIO, FilterPreset.TEAL_ORANGE,
            FilterPreset.CYBER_CYAN, FilterPreset.TUNGSTEN, FilterPreset.GOLDEN_HOUR
        )
        val templates = ThumbnailTemplate.entries
        val tracks = listOf(MusicTrack.HYPER_BEAT, MusicTrack.PHONK_DRIVE, MusicTrack.LOFI_CHILL, MusicTrack.CINEMATIC_PULSE)
        val stickers = listOf("WAIT FOR IT", "PRO SECRET", "NO WAY", "WATCH THIS", "HOT TAKE", "PART 1")

        return List(count) { idx ->
            val i = idx + offset
            val src = sources[i % sources.size]
            val angle = angles[i % angles.size]
            val platform = platforms[i % platforms.size]
            val durationSec = 30L + ((i * 11L) % 61L) // Strictly 30..90s
            val startSec = 15L + ((i / sources.size) * 95L) + ((i % 4) * 38L)
            val endSec = startSec + durationSec
            val keywords = extractKeywords("${src.title} $niche ${src.authorName}")
            val shortTopic = src.title.split(Regex("[-|:]")).first().trim().take(34).ifBlank { niche.take(30) }
            val title = "$shortTopic • $angle"
            val hook = buildHookLine(src.title, src.authorName, angle, i)
            val captions = buildRhythmicCaptions(title, hook, startSec, endSec)
            val seo = buildSeoForTopic(title, hook, keywords, platform)

            ViralClipDoc(
                mediaId = "",
                sourceUrl = src.canonicalUrl,
                youtubeVideoId = src.videoId,
                thumbnailUrl = src.thumbnailUrl,
                title = title,
                hook = hook,
                viralScore = (86L + ((i * 7L + keywords.size) % 13L)).coerceIn(84L, 98L),
                startSec = startSec,
                endSec = endSec,
                subtitlesEnabled = true,
                subtitleStyle = subStyles[i % subStyles.size].name,
                captions = captions,
                aspectRatio = "9:16",
                filterPreset = filters[i % filters.size].name,
                playbackSpeed = if (i % 3 == 0) 1.05 else 1.0,
                zoomScale = 1.10,
                brightness = 0.03,
                contrast = 1.14,
                saturation = 1.14,
                voiceVolume = 1.0,
                musicTrack = tracks[i % tracks.size].name,
                musicVolume = 0.22,
                noiseReduction = true,
                overlayText = stickers[i % stickers.size],
                thumbnailTemplate = templates[i % templates.size].name,
                exportResolution = settings.defaultExportResolution,
                exportFps = settings.defaultExportFps,
                exportBitrate = settings.defaultExportBitrate,
                exportFormat = settings.defaultExportFormat,
                optimizedPlatform = platform.name,
                seoTitle = seo.seoTitle,
                seoDescription = seo.seoDescription,
                seoTags = seo.seoTags,
                exportedPath = "superai://pro_edit_${i + 1}.mp4",
                waveformBars = OnDeviceSignalAnalyzer.generateSynthesizedWaveform(title + src.videoId),
                createdEpochMs = nowMs + i,
                superAiGenerated = true
            )
        }
    }

    private fun parseCaptionsArray(cuesArr: JSONArray?, startSec: Long, endSec: Long): List<CaptionCue> {
        if (cuesArr == null) return emptyList()
        return buildList {
            for (j in 0 until cuesArr.length()) {
                val cObj = cuesArr.optJSONObject(j) ?: continue
                val cStart = cObj.optLong("startSec", startSec + j * 5L).coerceIn(startSec, endSec)
                val cEnd = cObj.optLong("endSec", (cStart + 5L).coerceAtMost(endSec)).coerceIn(cStart, endSec)
                val cText = cObj.optString("text").trim()
                if (cText.isNotEmpty()) {
                    add(CaptionCue(cStart, cEnd, cText.take(120)))
                }
            }
        }
    }

    private fun parseTagsArray(tagsArr: JSONArray?): List<String> {
        if (tagsArr == null) return emptyList()
        return buildList {
            for (i in 0 until tagsArr.length()) {
                val t = tagsArr.optString(i).trim()
                if (t.isNotEmpty()) add(if (t.startsWith("#")) t else "#$t")
            }
        }
    }

    private fun extractKeywords(text: String): List<String> {
        val stopWords = setOf(
            "the", "and", "for", "with", "this", "that", "from", "your", "what", "when", "where",
            "how", "why", "into", "about", "just", "like", "more", "most", "viral", "video", "clip",
            "part", "shorts", "youtube", "watch", "will", "have", "they", "them", "then", "than",
            "over", "only", "make", "made", "been", "being", "here", "there"
        )
        return text.lowercase(Locale.US)
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length >= 3 && it !in stopWords }
            .distinct()
            .take(8)
            .ifEmpty { listOf("viral", "creator", "highlights", "tips") }
    }

    private fun buildHookLine(title: String, author: String, angle: String, idx: Int): String {
        val cleanTitle = title.split(Regex("[-|:]")).first().trim().take(48).ifBlank { "this moment" }
        val templates = listOf(
            "Wait until you hear what happens in \"$cleanTitle\".",
            "The $angle breakdown from ${author.ifBlank { "the creator" }} changes everything.",
            "3 seconds in and \"$cleanTitle\" already blew everyone away.",
            "Most people miss this hidden turning point in $cleanTitle."
        )
        return templates[abs(idx) % templates.size]
    }

    private fun buildRhythmicCaptions(
        title: String,
        hook: String,
        startSec: Long,
        endSec: Long
    ): List<CaptionCue> {
        val dur = (endSec - startSec).coerceAtLeast(6L)
        val cleanTitle = title.split("•").first().trim().take(38)
        val lines = listOf(
            hook.ifBlank { "Wait for this part..." }.take(64),
            "Breaking down: $cleanTitle".take(64),
            "Notice the shift in pacing & energy right here.",
            "This single insight is why retention skyrockets.",
            "Save & try this setup on your next edit."
        )
        val count = if (dur < 18L) 3 else 5
        val slice = lines.take(count)
        val step = (dur.toDouble() / slice.size).coerceAtLeast(1.0)
        return slice.mapIndexed { idx, line ->
            val cStart = (startSec + (idx * step).toLong()).coerceIn(startSec, endSec - 1L)
            val cEnd = if (idx == slice.lastIndex) endSec else (startSec + ((idx + 1) * step).toLong()).coerceIn(cStart + 1L, endSec)
            CaptionCue(startSec = cStart, endSec = cEnd, text = line)
        }
    }

    private fun buildSeoForTopic(
        title: String,
        hook: String,
        keywords: List<String>,
        platform: SocialPlatform
    ): SeoMetadataResult {
        val cleanTitle = title.trim().ifBlank { "Must-Watch Highlight" }
        val k1 = keywords.getOrElse(0) { "creator" }
        val k2 = keywords.getOrElse(1) { "viral" }
        val k3 = keywords.getOrElse(2) { "tips" }

        val platformSuffix = when (platform) {
            SocialPlatform.YOUTUBE_SHORTS -> "#Shorts"
            SocialPlatform.TIKTOK -> "(Watch Until The End)"
            SocialPlatform.INSTAGRAM_REELS -> "• Save For Later"
            SocialPlatform.X -> "Full Thread Breakdown"
            SocialPlatform.LINKEDIN -> "Key Strategy Takeaway"
        }

        val seoTitle = "${cleanTitle.take(58)} $platformSuffix".trim().take(90)
        val seoDesc = buildString {
            append(hook.ifBlank { cleanTitle })
            append(" Full breakdown covering $k1, $k2, and $k3 optimization. ")
            append("Follow for daily high-retention clips.")
        }

        val platformTags = when (platform) {
            SocialPlatform.YOUTUBE_SHORTS -> listOf("#Shorts", "#YouTubeShorts")
            SocialPlatform.TIKTOK -> listOf("#fyp", "#tiktokviral")
            SocialPlatform.INSTAGRAM_REELS -> listOf("#reels", "#explorepage")
            SocialPlatform.X -> listOf("#video", "#highlights")
            SocialPlatform.LINKEDIN -> listOf("#insights", "#growth")
        }
        val dynamicTags = keywords.take(4).map { "#$it" }
        val combinedTags = (platformTags + dynamicTags + "#viral").distinct().take(7)

        return SeoMetadataResult(
            seoTitle = seoTitle,
            seoDescription = seoDesc,
            seoTags = combinedTags
        )
    }

    private fun fallbackPublicSources(niche: String, channel: String): List<YouTubeVideoMetadata> {
        val prefix = channel.ifBlank { niche.split(" ").firstOrNull().orEmpty().ifBlank { "Creator" } }
        return listOf(
            YouTubeVideoMetadata(
                videoId = "M7lc1UVf-VE",
                canonicalUrl = "https://www.youtube.com/watch?v=M7lc1UVf-VE",
                title = "$prefix Keynote: High-Retention Strategy & Viral Architecture",
                authorName = channel.ifBlank { "Creator Studio Live" },
                thumbnailUrl = "https://img.youtube.com/vi/M7lc1UVf-VE/hqdefault.jpg"
            ),
            YouTubeVideoMetadata(
                videoId = "aqz-KE-bpKQ",
                canonicalUrl = "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
                title = "$niche Deep Dive: Visual Storytelling & Hooks",
                authorName = channel.ifBlank { "Open Cinema Lab" },
                thumbnailUrl = "https://img.youtube.com/vi/aqz-KE-bpKQ/hqdefault.jpg"
            ),
            YouTubeVideoMetadata(
                videoId = "YE7VzlLtp-4",
                canonicalUrl = "https://www.youtube.com/watch?v=YE7VzlLtp-4",
                title = "Fast-Cut $niche Secrets That Double Watch Time",
                authorName = channel.ifBlank { "Viral Lab Collective" },
                thumbnailUrl = "https://img.youtube.com/vi/YE7VzlLtp-4/hqdefault.jpg"
            )
        )
    }

    private data class DirectorPreset(
        val filter: FilterPreset,
        val fx: VideoEffect,
        val trans: ClipTransition,
        val subStyle: SubtitleStyle,
        val music: MusicTrack,
        val speed: Double,
        val zoom: Double,
        val bright: Double,
        val contrast: Double,
        val sat: Double,
        val warmth: Double,
        val vig: Double,
        val sticker: String
    )

    private companion object {
        const val TAG = "ClipForgeAiService"
        const val GROQ_CHAT_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
        const val GROQ_MODEL = "llama-3.3-70b-versatile"
    }
}
