package com.example.data.media

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.example.data.model.CaptionCue
import com.example.data.model.CaptionPosition
import com.example.data.model.ExportBitrate
import com.example.data.model.ExportFormat
import com.example.data.model.ExportResolution
import com.example.data.model.FilterPreset
import com.example.data.model.SubtitleStyle
import com.example.data.model.ViralClipDoc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.abs

data class LocalVideoMeta(
    val title: String,
    val durationSeconds: Long,
    val aspectRatio: String,
    val width: Int = 1080,
    val height: Int = 1920
)

class VideoExportEngine(private val appContext: Context) {

    suspend fun inspectLocalVideo(uri: Uri): LocalVideoMeta = withContext(Dispatchers.IO) {
        runCatching {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }

        var displayName = "Uploaded HD Video"
        try {
            appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIdx >= 0) {
                    displayName = cursor.getString(nameIdx)
                        ?.substringBeforeLast('.')
                        ?.take(100)
                        ?: displayName
                }
            }
        } catch (_: Exception) {
        }

        var durationSec = 45L
        var width = 1080
        var height = 1920
        var aspectRatio = "9:16"
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(appContext, uri)
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 45_000L
            durationSec = (durMs / 1000L).coerceAtLeast(1L)
            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            val rot = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                width = rawH
                height = rawW
            } else {
                width = rawW
                height = rawH
            }
            aspectRatio = when {
                height > width * 1.2 -> "9:16"
                width > height * 1.2 -> "16:9"
                else -> "1:1"
            }
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        LocalVideoMeta(
            title = displayName,
            durationSeconds = durationSec,
            aspectRatio = aspectRatio,
            width = width,
            height = height
        )
    }

    @androidx.annotation.OptIn(UnstableApi::class)
    suspend fun exportLocalClipWithMedia3(
        clip: ViralClipDoc,
        saveToGallery: Boolean = true,
        onProgress: (Int) -> Unit
    ): Result<String> = withContext(Dispatchers.Main) {
        val source = clip.sourceUrl
        if (!source.startsWith("content://") && !source.startsWith("file://")) {
            return@withContext Result.failure(
                IllegalStateException("Local HD Media3 export requires a video uploaded from your device.")
            )
        }

        // Read actual duration & bounds on IO thread to prevent out-of-range seek/trim errors
        val actualDurationMs = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(appContext, Uri.parse(source))
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.coerceAtLeast(1500L)
            } catch (_: Exception) {
                null
            } finally {
                runCatching { retriever.release() }
            }
        }

        val safeStartMs = if (actualDurationMs != null) {
            (clip.startSec * 1000L).coerceIn(0L, (actualDurationMs - 1000L).coerceAtLeast(0L))
        } else {
            (clip.startSec * 1000L).coerceAtLeast(0L)
        }
        val safeEndMs = if (actualDurationMs != null) {
            (clip.endSec * 1000L).coerceIn(safeStartMs + 1000L, actualDurationMs)
        } else {
            (clip.endSec * 1000L).coerceAtLeast(safeStartMs + 1000L)
        }

        val exportDir = File(appContext.filesDir, "exports").apply { mkdirs() }
        val safeName = clip.title.replace(Regex("[^A-Za-z0-9_-]"), "_").take(32).ifBlank { "clipforge_hd" }
        val fileName = "${safeName}_${System.currentTimeMillis()}.mp4"
        val outFile = File(exportDir, fileName)
        if (outFile.exists()) outFile.delete()

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(source))
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(safeStartMs)
                    .setEndPositionMs(safeEndMs)
                    .build()
            )
            .build()

        val (targetWidth, targetHeight) = resolveOutputDimensions(
            aspectRatio = clip.aspectRatio,
            resolution = ExportResolution.fromRaw(clip.exportResolution)
        )

        val videoEffects = buildList<Effect> {
            // Transform: Zoom, Rotation, Horizontal Flip
            val zoom = clip.zoomScale.toFloat().coerceIn(0.8f, 2.5f)
            val flipX = if (clip.flipHorizontal) -1f else 1f
            val rot = ((clip.rotationDeg % 360 + 360) % 360).toFloat()
            if (abs(zoom - 1f) > 0.01f || clip.flipHorizontal || rot != 0f) {
                add(
                    ScaleAndRotateTransformation.Builder()
                        .setScale(zoom * flipX, zoom)
                        .setRotationDegrees(rot)
                        .build()
                )
            }

            // CapCut / TikTok Free Filter Preset Effects scaled by filterIntensity
            val intensity = clip.filterIntensity.toFloat().coerceIn(0f, 1f)
            if (intensity > 0.05f) {
                when (FilterPreset.fromRaw(clip.filterPreset)) {
                    FilterPreset.NONE -> Unit
                    FilterPreset.CRISP_STUDIO -> add(Contrast(0.18f * intensity))
                    FilterPreset.VIVID_POP -> add(
                        HslAdjustment.Builder()
                            .adjustSaturation(28f * intensity)
                            .adjustLightness(4f * intensity)
                            .build()
                    )
                    FilterPreset.TIKTOK_GLOW -> add(
                        HslAdjustment.Builder()
                            .adjustSaturation(18f * intensity)
                            .adjustLightness(8f * intensity)
                            .build()
                    )
                    FilterPreset.OBSIDIAN -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f - 0.10f * intensity)
                            .setGreenScale(1f - 0.06f * intensity)
                            .setBlueScale(1f + 0.08f * intensity)
                            .build()
                    )
                    FilterPreset.TUNGSTEN -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + 0.12f * intensity)
                            .setGreenScale(1.0f)
                            .setBlueScale(1f - 0.16f * intensity)
                            .build()
                    )
                    FilterPreset.CYBER_CYAN -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f - 0.14f * intensity)
                            .setGreenScale(1f + 0.08f * intensity)
                            .setBlueScale(1f + 0.18f * intensity)
                            .build()
                    )
                    FilterPreset.TEAL_ORANGE -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + 0.10f * intensity)
                            .setGreenScale(1f - 0.04f * intensity)
                            .setBlueScale(1f + 0.06f * intensity)
                            .build()
                    )
                    FilterPreset.GOLDEN_HOUR -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + 0.18f * intensity)
                            .setGreenScale(1f + 0.06f * intensity)
                            .setBlueScale(1f - 0.18f * intensity)
                            .build()
                    )
                    FilterPreset.SUNSET_WARM -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + 0.20f * intensity)
                            .setGreenScale(1f - 0.03f * intensity)
                            .setBlueScale(1f - 0.10f * intensity)
                            .build()
                    )
                    FilterPreset.MOODY_NOIR -> {
                        add(RgbFilter.createGrayscaleFilter())
                        add(Contrast(0.32f * intensity))
                    }
                    FilterPreset.VINTAGE -> add(
                        RgbAdjustment.Builder()
                            .setRedScale(1f + 0.12f * intensity)
                            .setGreenScale(1f + 0.02f * intensity)
                            .setBlueScale(1f - 0.20f * intensity)
                            .build()
                    )
                    FilterPreset.BW_DRAMATIC -> {
                        add(RgbFilter.createGrayscaleFilter())
                        add(Contrast(0.42f * intensity))
                    }
                    FilterPreset.ANIME_BLOOM -> add(
                        HslAdjustment.Builder()
                            .adjustSaturation(20f * intensity)
                            .adjustLightness(10f * intensity)
                            .build()
                    )
                    FilterPreset.KODAK_FILM -> {
                        add(Contrast(0.14f * intensity))
                        add(
                            RgbAdjustment.Builder()
                                .setRedScale(1f + 0.10f * intensity)
                                .setGreenScale(1f + 0.03f * intensity)
                                .setBlueScale(1f - 0.12f * intensity)
                                .build()
                        )
                    }
                    FilterPreset.PASTEL_CREAM -> add(
                        HslAdjustment.Builder()
                            .adjustSaturation(-8f * intensity)
                            .adjustLightness(10f * intensity)
                            .build()
                    )
                }
            }

            // Custom Contrast, Brightness, Saturation & Warmth adjustments
            val contrastDelta = (clip.contrast.toFloat() - 1f).coerceIn(-0.6f, 0.8f)
            if (abs(contrastDelta) > 0.03f) {
                add(Contrast(contrastDelta))
            }
            val satDelta = ((clip.saturation.toFloat() - 1f) * 80f).coerceIn(-90f, 90f)
            val lightDelta = (clip.brightness.toFloat() * 45f).coerceIn(-45f, 45f)
            if (abs(satDelta) > 2f || abs(lightDelta) > 2f) {
                add(
                    HslAdjustment.Builder()
                        .adjustSaturation(satDelta)
                        .adjustLightness(lightDelta)
                        .build()
                )
            }
            val warmth = clip.warmth.toFloat().coerceIn(-0.8f, 0.8f)
            if (abs(warmth) > 0.04f) {
                add(
                    RgbAdjustment.Builder()
                        .setRedScale((1f + warmth * 0.22f).coerceIn(0.6f, 1.4f))
                        .setBlueScale((1f - warmth * 0.22f).coerceIn(0.6f, 1.4f))
                        .build()
                )
            }

            // Proportional Aspect Ratio Crop & Crisp HD Framing (Zero Squishing)
            add(
                Presentation.createForWidthAndHeight(
                    targetWidth,
                    targetHeight,
                    Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                )
            )

            // Burn dynamic Subtitles & Viral Overlay Badge directly into exported MP4 frames
            if ((clip.subtitlesEnabled && clip.captions.isNotEmpty()) || clip.overlayText.isNotBlank()) {
                val overlay = DynamicClipOverlay(
                    width = targetWidth,
                    height = targetHeight,
                    clipStartSec = safeStartMs / 1000L,
                    subtitlesEnabled = clip.subtitlesEnabled,
                    captions = clip.captions,
                    subtitleStyle = SubtitleStyle.fromRaw(clip.subtitleStyle),
                    captionPosition = CaptionPosition.fromRaw(clip.captionPosition),
                    captionScale = clip.captionScale.toFloat(),
                    overlayText = clip.overlayText
                )
                add(OverlayEffect(listOf(overlay)))
            }
        }

        val audioProcessors = buildList<AudioProcessor> {
            val speed = clip.playbackSpeed.toFloat().coerceIn(0.25f, 3.0f)
            if (abs(speed - 1f) > 0.02f) {
                add(SonicAudioProcessor().apply { setSpeed(speed) })
            }
        }

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(audioProcessors, videoEffects))
            .setRemoveAudio(clip.voiceVolume <= 0.01)
            .build()

        val mimeType = if (clip.exportFormat == ExportFormat.HEVC_H265.name) {
            MimeTypes.VIDEO_H265
        } else {
            MimeTypes.VIDEO_H264
        }

        val targetBitrate = ExportBitrate.fromRaw(clip.exportBitrate).bitsPerSec
        val encoderFactory = DefaultEncoderFactory.Builder(appContext)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder()
                    .setBitrate(targetBitrate)
                    .build()
            )
            .build()

        val transcodeRes = suspendCancellableCoroutine<Result<String>> { cont ->
            val handler = Handler(Looper.getMainLooper())
            val progressHolder = ProgressHolder()
            var transformerRef: Transformer? = null

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    onProgress(95)
                    if (cont.isActive) {
                        cont.resume(Result.success(outFile.absolutePath))
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacksAndMessages(null)
                    if (cont.isActive) {
                        cont.resume(Result.failure(exportException))
                    }
                }
            }

            val transformer = Transformer.Builder(appContext)
                .setVideoMimeType(mimeType)
                .setEncoderFactory(encoderFactory)
                .addListener(listener)
                .build()
            transformerRef = transformer

            cont.invokeOnCancellation {
                handler.removeCallbacksAndMessages(null)
                handler.post { transformerRef?.cancel() }
            }

            try {
                transformer.start(editedMediaItem, outFile.absolutePath)
                handler.post(object : Runnable {
                    override fun run() {
                        val state = transformer.getProgress(progressHolder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                            onProgress(progressHolder.progress.coerceIn(0, 94))
                        }
                        if (state != Transformer.PROGRESS_STATE_NOT_STARTED && cont.isActive) {
                            handler.postDelayed(this, 200L)
                        }
                    }
                })
            } catch (e: Exception) {
                handler.removeCallbacksAndMessages(null)
                if (cont.isActive) {
                    cont.resume(Result.failure(e))
                }
            }
        }

        val localPath = transcodeRes.getOrElse { return@withContext Result.failure(it) }
        val finalLocation = if (saveToGallery) {
            saveMp4ToGalleryMediaStore(File(localPath), fileName) ?: localPath
        } else {
            localPath
        }
        onProgress(100)
        Result.success(finalLocation)
    }

    private fun resolveOutputDimensions(
        aspectRatio: String,
        resolution: ExportResolution
    ): Pair<Int, Int> {
        val shortEdge = when (resolution) {
            ExportResolution.RES_720P -> 720
            ExportResolution.RES_1080P -> 1080
            ExportResolution.RES_2K -> 1440
            ExportResolution.RES_4K -> 2160
        }
        val pair = when (aspectRatio) {
            "16:9" -> ((shortEdge * 16) / 9) to shortEdge
            "1:1" -> shortEdge to shortEdge
            "4:5" -> shortEdge to ((shortEdge * 5) / 4)
            else -> shortEdge to ((shortEdge * 16) / 9) // 9:16 default vertical Shorts
        }
        // Keep even dimensions required by MediaCodec hardware encoders
        val evenW = pair.first and 1.inv()
        val evenH = pair.second and 1.inv()
        return evenW to evenH
    }

    private suspend fun saveMp4ToGalleryMediaStore(sourceFile: File, displayName: String): String? =
        withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return@withContext null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/ClipForge")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = appContext.contentResolver
                val itemUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext null

                resolver.openOutputStream(itemUri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                itemUri.toString()
            } catch (_: Exception) {
                null
            }
        }

    @androidx.annotation.OptIn(UnstableApi::class)
    private class DynamicClipOverlay(
        private val width: Int,
        private val height: Int,
        private val clipStartSec: Long,
        private val subtitlesEnabled: Boolean,
        private val captions: List<CaptionCue>,
        private val subtitleStyle: SubtitleStyle,
        private val captionPosition: CaptionPosition,
        private val captionScale: Float,
        private val overlayText: String
    ) : BitmapOverlay() {

        private val bitmap: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        private val canvas: Canvas = Canvas(bitmap)

        private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(235, 255, 77, 109)
        }
        private val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = (width * 0.040f).coerceIn(24f, 64f)
        }
        private val subBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val subBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = (width * 0.004f).coerceAtLeast(3f)
        }
        private val subTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        private var lastCueKey: String = "__INIT__"

        override fun getBitmap(presentationTimeUs: Long): Bitmap {
            val absoluteSec = clipStartSec + (presentationTimeUs / 1_000_000L)
            val activeCueText = if (!subtitlesEnabled) {
                ""
            } else {
                captions.firstOrNull { absoluteSec in it.startSec..it.endSec }?.text
                    ?: captions.firstOrNull()?.text.orEmpty()
            }

            val cueKey = "$overlayText|$activeCueText"
            if (cueKey == lastCueKey) {
                return bitmap
            }
            lastCueKey = cueKey

            bitmap.eraseColor(Color.TRANSPARENT)

            // Draw top viral badge if present
            if (overlayText.isNotBlank()) {
                val label = overlayText.trim().uppercase()
                val textW = badgeTextPaint.measureText(label)
                val padX = width * 0.035f
                val padY = height * 0.014f
                val cx = width / 2f
                val topY = height * 0.06f
                val rect = RectF(
                    (cx - textW / 2f - padX).coerceAtLeast(24f),
                    topY,
                    (cx + textW / 2f + padX).coerceAtMost(width - 24f),
                    topY + badgeTextPaint.textSize + padY * 2f
                )
                canvas.drawRoundRect(rect, 18f, 18f, badgeBgPaint)
                val baseline = rect.centerY() - (badgeTextPaint.descent() + badgeTextPaint.ascent()) / 2f
                canvas.drawText(label, cx, baseline, badgeTextPaint)
            }

            // Draw synced caption bar
            if (activeCueText.isNotBlank()) {
                val formatted = if (subtitleStyle == SubtitleStyle.HORMOZI_POP || subtitleStyle == SubtitleStyle.YELLOW_CREATOR) {
                    activeCueText.uppercase()
                } else {
                    activeCueText
                }

                subBgPaint.color = when (subtitleStyle) {
                    SubtitleStyle.HORMOZI_POP -> Color.argb(215, 10, 10, 16)
                    SubtitleStyle.KARAOKE_GLOW -> Color.argb(225, 124, 58, 237)
                    SubtitleStyle.MINIMAL_PILL -> Color.argb(220, 22, 24, 34)
                    SubtitleStyle.NEON_BOX -> Color.argb(230, 8, 12, 24)
                    SubtitleStyle.CAPTION_OUTLINE -> Color.argb(175, 0, 0, 0)
                    SubtitleStyle.YELLOW_CREATOR -> Color.argb(245, 255, 196, 0)
                }
                subTextPaint.color = when (subtitleStyle) {
                    SubtitleStyle.HORMOZI_POP -> Color.rgb(255, 200, 40)
                    SubtitleStyle.NEON_BOX -> Color.rgb(0, 229, 255)
                    SubtitleStyle.YELLOW_CREATOR -> Color.BLACK
                    else -> Color.WHITE
                }
                val safeScale = captionScale.coerceIn(0.75f, 1.5f)
                subTextPaint.textSize = (width * 0.044f * safeScale).coerceIn(26f, 76f)

                val maxTextW = (width * 0.82f).toInt().coerceAtLeast(120)
                val layout = StaticLayout.Builder
                    .obtain(formatted, 0, formatted.length, subTextPaint, maxTextW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setLineSpacing(4f, 1.05f)
                    .setMaxLines(2)
                    .build()

                var maxLineW = 0f
                for (i in 0 until layout.lineCount) {
                    maxLineW = maxOf(maxLineW, layout.getLineWidth(i))
                }
                val padX = width * 0.04f
                val padY = height * 0.016f
                val boxW = (maxLineW + padX * 2f).coerceAtMost(width * 0.90f)
                val boxH = layout.height + padY * 2f
                val boxTop = when (captionPosition) {
                    CaptionPosition.TOP -> height * 0.16f
                    CaptionPosition.CENTER -> (height - boxH) / 2f
                    CaptionPosition.BOTTOM -> height * 0.80f - boxH
                }
                val left = (width - boxW) / 2f
                val boxRect = RectF(left, boxTop, left + boxW, boxTop + boxH)
                canvas.drawRoundRect(boxRect, 22f, 22f, subBgPaint)

                if (subtitleStyle == SubtitleStyle.NEON_BOX || subtitleStyle == SubtitleStyle.HORMOZI_POP) {
                    subBorderPaint.color = if (subtitleStyle == SubtitleStyle.NEON_BOX) {
                        Color.rgb(0, 229, 255)
                    } else {
                        Color.argb(160, 255, 200, 40)
                    }
                    canvas.drawRoundRect(boxRect, 22f, 22f, subBorderPaint)
                }

                canvas.save()
                canvas.translate((width - maxTextW) / 2f, boxTop + padY)
                layout.draw(canvas)
                canvas.restore()
            }

            return bitmap
        }
    }
}
