package com.example.data.remote

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class YouTubeTranscriptCue(
    val startSec: Long,
    val endSec: Long,
    val text: String
)

data class YouTubeChapter(
    val startSec: Long,
    val title: String
)

data class YouTubeHeatMarker(
    val startSec: Long,
    val endSec: Long,
    val intensity: Double
)

data class YouTubeVideoMetadata(
    val videoId: String,
    val canonicalUrl: String,
    val title: String,
    val authorName: String,
    val thumbnailUrl: String,
    val durationSeconds: Long = 480L,
    val description: String = "",
    val chapters: List<YouTubeChapter> = emptyList(),
    val transcriptCues: List<YouTubeTranscriptCue> = emptyList(),
    val heatMarkers: List<YouTubeHeatMarker> = emptyList()
)

class YouTubeMetadataService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun extractVideoId(rawUrl: String): String? {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) return null

        val patterns = listOf(
            Regex("""(?:youtube\.com/watch\?(?:.*&)?v=|youtu\.be/|youtube\.com/shorts/|youtube\.com/live/|youtube\.com/embed/)([A-Za-z0-9_-]{11})"""),
            Regex("""^([A-Za-z0-9_-]{11})$""")
        )
        for (pattern in patterns) {
            val match = pattern.find(trimmed)
            if (match != null) {
                return match.groupValues[1]
            }
        }
        return null
    }

    suspend fun fetchMetadata(rawUrl: String): Result<YouTubeVideoMetadata> = withContext(Dispatchers.IO) {
        val videoId = extractVideoId(rawUrl)
            ?: return@withContext Result.failure(
                IllegalArgumentException("Enter a valid YouTube URL (watch, shorts, live, or youtu.be link).")
            )

        val canonicalUrl = "https://www.youtube.com/watch?v=$videoId"
        val fallbackThumb = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"

        return@withContext try {
            coroutineScope {
                val oembedDeferred = async { fetchOembed(canonicalUrl, videoId, fallbackThumb) }
                val watchDeferred = async { fetchWatchPageDetails(canonicalUrl, videoId) }
                val playerApiDeferred = async { fetchInnertubePlayerDetails(videoId) }

                val oembed = oembedDeferred.await()
                val watch = watchDeferred.await()
                val apiDetails = playerApiDeferred.await()

                val title = oembed?.title?.ifBlank { null }
                    ?: apiDetails?.title?.ifBlank { null }
                    ?: watch?.title?.ifBlank { null }
                    ?: return@coroutineScope Result.failure(
                        IllegalStateException("Could not resolve YouTube video metadata. Check that the video URL is public.")
                    )

                val author = oembed?.authorName?.ifBlank { null }
                    ?: apiDetails?.authorName?.ifBlank { null }
                    ?: watch?.authorName?.ifBlank { null }
                    ?: "YouTube Creator"

                val thumb = oembed?.thumbnailUrl?.ifBlank { null } ?: fallbackThumb

                val durationSec = when {
                    apiDetails != null && apiDetails.durationSeconds > 15L -> apiDetails.durationSeconds
                    watch != null && watch.durationSeconds > 15L -> watch.durationSeconds
                    else -> apiDetails?.durationSeconds ?: watch?.durationSeconds ?: 300L
                }.coerceIn(15L, 43_200L)

                val description = apiDetails?.description?.ifBlank { null }
                    ?: watch?.description.orEmpty()

                val chapters = (apiDetails?.chapters.orEmpty() + watch?.chapters.orEmpty())
                    .ifEmpty { parseChaptersFromDescription(description) }
                    .distinctBy { it.startSec }
                    .sortedBy { it.startSec }

                val captionUrl = apiDetails?.captionUrl?.ifBlank { null }
                    ?: watch?.captionUrl.orEmpty()

                var transcript = if (captionUrl.isNotBlank()) {
                    fetchTranscriptCues(captionUrl)
                } else {
                    emptyList()
                }
                if (transcript.isEmpty()) {
                    transcript = fetchTimedTextFallback(videoId)
                }

                val heatMarkers = watch?.heatMarkers.orEmpty()
                    .sortedByDescending { it.intensity }

                Result.success(
                    YouTubeVideoMetadata(
                        videoId = videoId,
                        canonicalUrl = canonicalUrl,
                        title = title,
                        authorName = author,
                        thumbnailUrl = thumb,
                        durationSeconds = durationSec,
                        description = description.take(3000),
                        chapters = chapters,
                        transcriptCues = transcript,
                        heatMarkers = heatMarkers
                    )
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed fetching YouTube metadata: ${e.message}")
            Result.failure(e)
        }
    }

    private fun fetchOembed(canonicalUrl: String, videoId: String, fallbackThumb: String): YouTubeVideoMetadata? {
        return try {
            val encoded = URLEncoder.encode(canonicalUrl, "UTF-8")
            val request = Request.Builder()
                .url("https://www.youtube.com/oembed?url=$encoded&format=json")
                .header("User-Agent", DESKTOP_UA)
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) return null
                val json = JSONObject(body)
                YouTubeVideoMetadata(
                    videoId = videoId,
                    canonicalUrl = canonicalUrl,
                    title = json.optString("title").ifBlank { "YouTube Video ($videoId)" },
                    authorName = json.optString("author_name").ifBlank { "YouTube Creator" },
                    thumbnailUrl = json.optString("thumbnail_url").ifBlank { fallbackThumb },
                    durationSeconds = 300L
                )
            }
        } catch (_: Exception) {
            null
        }
    }

    private data class WatchPageDetails(
        val title: String,
        val authorName: String,
        val durationSeconds: Long,
        val description: String,
        val chapters: List<YouTubeChapter>,
        val captionUrl: String,
        val heatMarkers: List<YouTubeHeatMarker> = emptyList()
    )

    private fun fetchInnertubePlayerDetails(videoId: String): WatchPageDetails? {
        return try {
            val bodyJson = JSONObject().apply {
                put("videoId", videoId)
                put(
                    "context",
                    JSONObject().apply {
                        put(
                            "client",
                            JSONObject().apply {
                                put("clientName", "ANDROID")
                                put("clientVersion", "19.29.37")
                                put("androidSdkVersion", 34)
                                put("hl", "en")
                                put("gl", "US")
                            }
                        )
                    }
                )
            }
            val request = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
                .header("User-Agent", ANDROID_UA)
                .header("Content-Type", "application/json")
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string().orEmpty()
                if (raw.isBlank()) return null
                parsePlayerResponseJson(JSONObject(raw))
            }
        } catch (e: Exception) {
            Log.w(TAG, "Innertube player lookup skipped: ${e.message}")
            null
        }
    }

    private fun fetchWatchPageDetails(canonicalUrl: String, videoId: String): WatchPageDetails? {
        return try {
            val request = Request.Builder()
                .url("$canonicalUrl&hl=en&bpctr=9999999999&has_verified=1")
                .header("User-Agent", DESKTOP_UA)
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Cookie", "CONSENT=YES+cb.20230531-07-p0.en+FX+908")
                .build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val html = resp.body?.string().orEmpty()
                if (html.isBlank()) return null

                val heatMarkers = parseHeatMarkersFromHtml(html)

                // Try balanced JSON extraction of ytInitialPlayerResponse first
                val playerJsonStr = extractAssignedJsonObject(html, "ytInitialPlayerResponse")
                if (playerJsonStr != null) {
                    val parsedPlayer = runCatching {
                        parsePlayerResponseJson(JSONObject(playerJsonStr))
                    }.getOrNull()
                    if (parsedPlayer != null) {
                        return parsedPlayer.copy(heatMarkers = heatMarkers)
                    }
                }

                // Regex fallback if full JSON parse failed
                val lengthSec = Regex(""""lengthSeconds"\s*:\s*"(\d+)"""")
                    .find(html)?.groupValues?.get(1)?.toLongOrNull()
                    ?: Regex(""""approxDurationMs"\s*:\s*"(\d+)"""")
                        .find(html)?.groupValues?.get(1)?.toLongOrNull()?.div(1000L)
                    ?: 0L

                val titleRaw = Regex("""<meta name="title" content="([^"]+)"""")
                    .find(html)?.groupValues?.get(1).orEmpty()
                val authorRaw = Regex(""""ownerChannelName"\s*:\s*"((?:[^"\\]|\\.)*)"""")
                    .find(html)?.groupValues?.get(1).orEmpty()
                val descRaw = Regex(""""shortDescription"\s*:\s*"((?:[^"\\]|\\.)*)"""")
                    .find(html)?.groupValues?.get(1).orEmpty()

                val description = unescapeJsonString(descRaw)
                val chapters = parseChaptersFromDescription(description)

                WatchPageDetails(
                    title = decodeHtmlEntities(titleRaw),
                    authorName = unescapeJsonString(authorRaw),
                    durationSeconds = lengthSec.coerceIn(0L, 43_200L),
                    description = description.take(3000),
                    chapters = chapters,
                    captionUrl = "",
                    heatMarkers = heatMarkers
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Watch page detail parse skipped for $videoId: ${e.message}")
            null
        }
    }

    private fun parseHeatMarkersFromHtml(html: String): List<YouTubeHeatMarker> {
        return try {
            val markerRegex = Regex(
                """"heatMarkerRenderer"\s*:\s*\{[^}]*?"timeRangeStartMillis"\s*:\s*(\d+)[^}]*?"markerDurationMillis"\s*:\s*(\d+)[^}]*?"heatMarkerIntensityScoreNormalized"\s*:\s*([\d.]+)"""
            )
            markerRegex.findAll(html)
                .mapNotNull { m ->
                    val startMs = m.groupValues[1].toLongOrNull() ?: return@mapNotNull null
                    val durMs = m.groupValues[2].toLongOrNull() ?: 5000L
                    val intensity = m.groupValues[3].toDoubleOrNull() ?: 0.0
                    val startSec = (startMs / 1000L).coerceAtLeast(0L)
                    val endSec = ((startMs + durMs) / 1000L).coerceAtLeast(startSec + 1L)
                    if (intensity >= 0.35) {
                        YouTubeHeatMarker(startSec, endSec, intensity.coerceIn(0.0, 1.0))
                    } else null
                }
                .sortedByDescending { it.intensity }
                .take(24)
                .toList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parsePlayerResponseJson(root: JSONObject): WatchPageDetails? {
        val details = root.optJSONObject("videoDetails") ?: return null
        val title = details.optString("title").trim()
        val author = details.optString("author").trim()
        val lengthSec = details.optString("lengthSeconds").toLongOrNull()
            ?: details.optLong("lengthSeconds", 0L)
        val description = details.optString("shortDescription").trim()

        val captionTracks = root
            .optJSONObject("captions")
            ?.optJSONObject("playerCaptionsTracklistRenderer")
            ?.optJSONArray("captionTracks")

        val captionUrl = selectBestCaptionUrl(captionTracks)
        val chapters = parseChaptersFromDescription(description)

        return WatchPageDetails(
            title = title,
            authorName = author,
            durationSeconds = lengthSec.coerceIn(0L, 43_200L),
            description = description.take(3000),
            chapters = chapters,
            captionUrl = captionUrl
        )
    }

    private fun selectBestCaptionUrl(tracks: JSONArray?): String {
        if (tracks == null || tracks.length() == 0) return ""
        var englishManual: String? = null
        var englishAuto: String? = null
        var anyTrack: String? = null

        for (i in 0 until tracks.length()) {
            val t = tracks.optJSONObject(i) ?: continue
            val baseUrl = t.optString("baseUrl").trim()
                .replace("\\u0026", "&")
                .replace("\\/", "/")
            if (baseUrl.isBlank()) continue
            val lang = t.optString("languageCode").lowercase()
            val kind = t.optString("kind").lowercase()
            if (anyTrack == null) anyTrack = baseUrl
            if (lang.startsWith("en")) {
                if (kind == "asr") {
                    if (englishAuto == null) englishAuto = baseUrl
                } else {
                    if (englishManual == null) englishManual = baseUrl
                }
            }
        }
        return englishManual ?: englishAuto ?: anyTrack.orEmpty()
    }

    private fun extractAssignedJsonObject(html: String, varName: String): String? {
        val markerIdx = html.indexOf(varName)
        if (markerIdx < 0) return null
        val startBrace = html.indexOf('{', startIndex = markerIdx)
        if (startBrace < 0) return null

        var depth = 0
        var inString = false
        var escaped = false
        val limit = (startBrace + 550_000).coerceAtMost(html.length)
        for (i in startBrace until limit) {
            val ch = html[i]
            if (escaped) {
                escaped = false
                continue
            }
            if (inString) {
                if (ch == '\\') escaped = true
                else if (ch == '"') inString = false
                continue
            }
            when (ch) {
                '"' -> inString = true
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) {
                        return html.substring(startBrace, i + 1)
                    }
                }
            }
        }
        return null
    }

    private fun fetchTimedTextFallback(videoId: String): List<YouTubeTranscriptCue> {
        val urls = listOf(
            "https://www.youtube.com/api/timedtext?v=$videoId&lang=en",
            "https://www.youtube.com/api/timedtext?v=$videoId&lang=en&kind=asr"
        )
        for (url in urls) {
            val cues = fetchTranscriptCues(url)
            if (cues.isNotEmpty()) return cues
        }
        return emptyList()
    }

    private fun fetchTranscriptCues(captionBaseUrl: String): List<YouTubeTranscriptCue> {
        if (captionBaseUrl.isBlank()) return emptyList()
        return try {
            val req = Request.Builder()
                .url(captionBaseUrl)
                .header("User-Agent", DESKTOP_UA)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val xml = resp.body?.string().orEmpty()
                if (xml.isBlank()) return emptyList()

                // Format 1: standard <text start="12.3" dur="4.5">...</text>
                val standardRegex = Regex(
                    """<text\s+start="([\d.]+)"(?:\s+dur="([\d.]+)")?[^>]*>(.*?)</text>""",
                    RegexOption.DOT_MATCHES_ALL
                )
                val standardCues = standardRegex.findAll(xml).mapNotNull { match ->
                    val start = match.groupValues[1].toDoubleOrNull()?.toLong() ?: return@mapNotNull null
                    val dur = match.groupValues[2].toDoubleOrNull()?.toLong()?.coerceAtLeast(1L) ?: 3L
                    val text = cleanCaptionXmlText(match.groupValues[3])
                    if (text.isBlank()) null else YouTubeTranscriptCue(start, start + dur, text)
                }.toList()
                if (standardCues.isNotEmpty()) return standardCues

                // Format 2: srv3 <p t="12340" d="4500">...</p>
                val srv3Regex = Regex(
                    """<p\s+t="(\d+)"(?:\s+d="(\d+)")?[^>]*>(.*?)</p>""",
                    RegexOption.DOT_MATCHES_ALL
                )
                srv3Regex.findAll(xml).mapNotNull { match ->
                    val start = (match.groupValues[1].toLongOrNull() ?: return@mapNotNull null) / 1000L
                    val dur = ((match.groupValues[2].toLongOrNull() ?: 3000L) / 1000L).coerceAtLeast(1L)
                    val text = cleanCaptionXmlText(match.groupValues[3])
                    if (text.isBlank()) null else YouTubeTranscriptCue(start, start + dur, text)
                }.toList()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Transcript fetch skipped: ${e.message}")
            emptyList()
        }
    }

    private fun cleanCaptionXmlText(raw: String): String {
        return decodeHtmlEntities(raw)
            .replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun parseChaptersFromDescription(description: String): List<YouTubeChapter> {
        if (description.isBlank()) return emptyList()
        val lineRegex = Regex("""(?m)^\s*(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\s*[-–:|]?\s*(.+)$""")
        return lineRegex.findAll(description).mapNotNull { m ->
            val h = m.groupValues[1].toLongOrNull() ?: 0L
            val min = m.groupValues[2].toLongOrNull() ?: 0L
            val sec = m.groupValues[3].toLongOrNull() ?: 0L
            val totalSec = h * 3600L + min * 60L + sec
            val label = m.groupValues[4].trim().take(80)
            if (label.isBlank()) null else YouTubeChapter(totalSec, label)
        }.distinctBy { it.startSec }.sortedBy { it.startSec }.take(24).toList()
    }

    /**
     * Keyless public YouTube discovery via standard search HTML + parallel oEmbed resolution.
     */
    suspend fun searchYouTubeVideos(
        query: String,
        maxResults: Int = 8
    ): List<YouTubeVideoMetadata> = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim().ifBlank { "trending viral podcast highlights" }
        val discoveredIds = linkedSetOf<String>()

        try {
            val encodedQuery = URLEncoder.encode(cleanQuery, "UTF-8")
            val req = Request.Builder()
                .url("https://www.youtube.com/results?search_query=$encodedQuery")
                .header("User-Agent", DESKTOP_UA)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    val html = resp.body?.string().orEmpty()
                    val jsonIdRegex = Regex(""""videoId":"([A-Za-z0-9_-]{11})"""")
                    jsonIdRegex.findAll(html).forEach { match ->
                        discoveredIds.add(match.groupValues[1])
                        if (discoveredIds.size >= maxResults * 2) return@use
                    }
                    val watchRegex = Regex("""/watch\?v=([A-Za-z0-9_-]{11})""")
                    watchRegex.findAll(html).forEach { match ->
                        discoveredIds.add(match.groupValues[1])
                        if (discoveredIds.size >= maxResults * 2) return@use
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Keyless YouTube search fallback triggered: ${e.message}")
        }

        if (discoveredIds.isEmpty()) return@withContext emptyList()

        coroutineScope {
            discoveredIds.take(maxResults).map { id ->
                async {
                    fetchOembed(
                        canonicalUrl = "https://www.youtube.com/watch?v=$id",
                        videoId = id,
                        fallbackThumb = "https://img.youtube.com/vi/$id/hqdefault.jpg"
                    )
                }
            }.awaitAll().filterNotNull()
        }
    }

    private fun unescapeJsonString(raw: String): String {
        if (raw.isEmpty()) return ""
        return raw
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\u0026", "&")
    }

    private fun decodeHtmlEntities(raw: String): String {
        if (raw.isEmpty()) return ""
        return raw
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&#x27;", "'")
    }

    companion object {
        private const val TAG = "YouTubeMetadataService"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        private const val ANDROID_UA =
            "com.google.android.youtube/19.29.37 (Linux; U; Android 14; en_US) gzip"

        fun buildTimestampedUrl(sourceUrl: String, youtubeVideoId: String, startSec: Long): String {
            val base = if (youtubeVideoId.isNotBlank()) {
                "https://www.youtube.com/watch?v=$youtubeVideoId"
            } else {
                sourceUrl
            }
            if (startSec <= 0L) return base
            val sep = if (base.contains("?")) "&" else "?"
            return if (base.contains("t=")) base else "${base}${sep}t=${startSec}s"
        }
    }
}
