package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.local.LocalGuestStore
import com.example.data.model.AnalyticsRecordDoc
import com.example.data.model.MediaItemDoc
import com.example.data.model.PostStatus
import com.example.data.model.ScheduledPostDoc
import com.example.data.model.SocialAccountDoc
import com.example.data.model.SocialPlatform
import com.example.data.model.UserProfile
import com.example.data.model.ViralClipDoc
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ClipForgeRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val isGuestMode: Boolean = false,
    private val localGuestStore: LocalGuestStore? = null
) {
    constructor(context: Context, isGuestMode: Boolean = false) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth,
        isGuestMode = isGuestMode,
        localGuestStore = if (isGuestMode) LocalGuestStore(context.applicationContext) else null
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)

    fun observeClips(userId: String): Flow<List<ViralClipDoc>> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.clips
        } else {
            flow {
                val path = "users/$userId/clips"
                emitAll(
                    userDoc(userId).collection("clips")
                        .snapshots()
                        .map { snap ->
                            snap.toObjects(
                                ViralClipDoc::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            ).sortedByDescending { it.createdAt?.seconds ?: (it.createdEpochMs / 1000L) }
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                            throw error
                        }
                )
            }
        }

    fun observeMedia(userId: String): Flow<List<MediaItemDoc>> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.media
        } else {
            flow {
                val path = "users/$userId/media"
                emitAll(
                    userDoc(userId).collection("media")
                        .snapshots()
                        .map { snap ->
                            snap.toObjects(
                                MediaItemDoc::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            ).sortedByDescending { it.createdAt?.seconds ?: (it.createdEpochMs / 1000L) }
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                            throw error
                        }
                )
            }
        }

    fun observeSocialAccounts(userId: String): Flow<List<SocialAccountDoc>> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.socialAccounts
        } else {
            flow {
                val path = "users/$userId/socialAccounts"
                emitAll(
                    userDoc(userId).collection("socialAccounts")
                        .snapshots()
                        .map { snap ->
                            snap.toObjects(
                                SocialAccountDoc::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            )
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                            throw error
                        }
                )
            }
        }

    fun observeScheduledPosts(userId: String): Flow<List<ScheduledPostDoc>> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.scheduledPosts
        } else {
            flow {
                val path = "users/$userId/scheduledPosts"
                emitAll(
                    userDoc(userId).collection("scheduledPosts")
                        .snapshots()
                        .map { snap ->
                            snap.toObjects(
                                ScheduledPostDoc::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            ).sortedBy { it.scheduledAtEpochMs }
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                            throw error
                        }
                )
            }
        }

    fun observeAnalytics(userId: String): Flow<List<AnalyticsRecordDoc>> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.analytics
        } else {
            flow {
                val path = "users/$userId/analytics"
                emitAll(
                    userDoc(userId).collection("analytics")
                        .snapshots()
                        .map { snap ->
                            snap.toObjects(
                                AnalyticsRecordDoc::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.LIST, path, userId)
                            throw error
                        }
                )
            }
        }

    fun observeUserProfile(userId: String): Flow<UserProfile> =
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.profile
        } else {
            flow {
                val path = "users/$userId"
                emitAll(
                    userDoc(userId)
                        .snapshots()
                        .map { snap ->
                            snap.toObject(
                                UserProfile::class.java,
                                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                            ) ?: UserProfile(userId = userId)
                        }
                        .flowOn(Dispatchers.Default)
                        .distinctUntilChanged()
                        .catch { error ->
                            logStreamErrorIfActive(error, OperationType.GET, path, userId)
                            throw error
                        }
                )
            }
        }

    suspend fun ensureUserProfile(displayName: String): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.ensureProfile(displayName)
            return Result.success(Unit)
        }
        var docPath = "users/unknown"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid)
            docPath = ref.path
            val snap = ref.get().await()
            if (!snap.exists()) {
                val safeName = displayName.ifBlank { "Creator" }.take(60)
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "displayName" to safeName,
                        "defaultPlatform" to SocialPlatform.TIKTOK.name,
                        "autoSubtitlesEnabled" to true,
                        "superAiActive" to false,
                        "superAiNiche" to "Trending & Viral",
                        "superAiChannel" to "",
                        "superAiAutoPostNow" to false,
                        "superAiPostingTimes" to listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM"),
                        "autoDelete24hEnabled" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else if (!snap.contains("superAiActive") || !snap.contains("autoDelete24hEnabled")) {
                ref.update(
                    mapOf(
                        "superAiActive" to (snap.getBoolean("superAiActive") ?: false),
                        "superAiNiche" to (snap.getString("superAiNiche") ?: "Trending & Viral"),
                        "superAiChannel" to (snap.getString("superAiChannel") ?: ""),
                        "superAiAutoPostNow" to (snap.getBoolean("superAiAutoPostNow") ?: false),
                        "superAiPostingTimes" to ((snap.get("superAiPostingTimes") as? List<*>)
                            ?.filterIsInstance<String>()
                            ?.ifEmpty { null }
                            ?: listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM")),
                        "autoDelete24hEnabled" to (snap.getBoolean("autoDelete24hEnabled") ?: false),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateSuperAiConfig(
        active: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.updateSuperAiConfig(active, niche, channel, autoPostNow, postingTimes)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid)
            docPath = ref.path
            val safeTimes = postingTimes.map { it.trim().take(24) }.filter { it.isNotEmpty() }.distinct().take(16)
            ref.update(
                mapOf(
                    "superAiActive" to active,
                    "superAiNiche" to niche.trim().take(80),
                    "superAiChannel" to channel.trim().take(80),
                    "superAiAutoPostNow" to autoPostNow,
                    "superAiPostingTimes" to safeTimes,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateAutoDelete24h(enabled: Boolean): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.updateAutoDelete24h(enabled)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid)
            docPath = ref.path
            ref.update(
                mapOf(
                    "autoDelete24hEnabled" to enabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun createMediaItem(item: MediaItemDoc): Result<String> {
        if (isGuestMode && localGuestStore != null) {
            return Result.success(localGuestStore.createMediaItem(item))
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/media"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid).collection("media").document()
            docPath = ref.path
            ref.set(item.toCreateMap(uid)).await()
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateMediaStatus(mediaId: String, status: String): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.updateMediaStatus(mediaId, status)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/media/$mediaId"
        return try {
            val uid = requireUserId()
            require(mediaId.isNotBlank()) { "Media ID cannot be blank" }
            val ref = userDoc(uid).collection("media").document(mediaId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "status" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteMediaItem(mediaId: String): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.deleteMediaItem(mediaId)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/media/$mediaId"
        return try {
            val uid = requireUserId()
            require(mediaId.isNotBlank()) { "Media ID cannot be blank" }
            val ref = userDoc(uid).collection("media").document(mediaId)
            docPath = ref.path
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveClips(clips: List<ViralClipDoc>): Result<List<String>> {
        if (isGuestMode && localGuestStore != null) {
            return Result.success(localGuestStore.saveClips(clips))
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/clips"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            val ids = mutableListOf<String>()
            clips.forEach { clip ->
                val ref = userDoc(uid).collection("clips").document()
                docPath = ref.path
                ids.add(ref.id)
                batch.set(ref, clip.toCreateMap(uid))
            }
            batch.commit().await()
            Result.success(ids)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveSuperAiBatch(
        clips: List<ViralClipDoc>,
        mediaItems: List<MediaItemDoc>,
        scheduledPostsBuilder: (List<Pair<String, ViralClipDoc>>) -> List<ScheduledPostDoc>,
        analyticsBuilder: (List<Pair<String, ViralClipDoc>>) -> List<AnalyticsRecordDoc>
    ): Result<List<String>> {
        if (isGuestMode && localGuestStore != null) {
            return Result.success(
                localGuestStore.saveSuperAiBatch(
                    clips = clips,
                    mediaItems = mediaItems,
                    scheduledPostsBuilder = scheduledPostsBuilder,
                    analyticsBuilder = analyticsBuilder
                )
            )
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/clips"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            val clipPairs = mutableListOf<Pair<String, ViralClipDoc>>()

            mediaItems.forEachIndexed { index, media ->
                val mediaRef = userDoc(uid).collection("media").document()
                docPath = mediaRef.path
                batch.set(mediaRef, media.toCreateMap(uid))

                val clip = clips.getOrNull(index)
                if (clip != null) {
                    val clipRef = userDoc(uid).collection("clips").document()
                    docPath = clipRef.path
                    val linkedClip = clip.copy(mediaId = mediaRef.id)
                    batch.set(clipRef, linkedClip.toCreateMap(uid))
                    clipPairs.add(clipRef.id to linkedClip)
                }
            }
            if (clips.size > mediaItems.size) {
                clips.drop(mediaItems.size).forEach { clip ->
                    val clipRef = userDoc(uid).collection("clips").document()
                    docPath = clipRef.path
                    batch.set(clipRef, clip.toCreateMap(uid))
                    clipPairs.add(clipRef.id to clip)
                }
            }

            scheduledPostsBuilder(clipPairs).forEach { post ->
                val postRef = userDoc(uid).collection("scheduledPosts").document()
                docPath = postRef.path
                batch.set(postRef, post.toCreateMap(uid))
            }

            analyticsBuilder(clipPairs).forEach { metric ->
                val metricRef = userDoc(uid).collection("analytics").document()
                docPath = metricRef.path
                batch.set(metricRef, metric.toCreateMap(uid))
            }

            batch.commit().await()
            Result.success(clipPairs.map { it.first })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteExpiredMediaAndClips(
        mediaIds: List<String>,
        clipIds: List<String>
    ): Result<Int> {
        if (mediaIds.isEmpty() && clipIds.isEmpty()) return Result.success(0)
        if (isGuestMode && localGuestStore != null) {
            return Result.success(localGuestStore.deleteExpired(mediaIds, clipIds))
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/media"
        return try {
            val uid = requireUserId()
            val allRefs = buildList {
                mediaIds.filter { it.isNotBlank() }.forEach { id ->
                    add(userDoc(uid).collection("media").document(id))
                }
                clipIds.filter { it.isNotBlank() }.forEach { id ->
                    add(userDoc(uid).collection("clips").document(id))
                }
            }
            allRefs.chunked(400).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { ref ->
                    docPath = ref.path
                    batch.delete(ref)
                }
                batch.commit().await()
            }
            Result.success(allRefs.size)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateClip(clip: ViralClipDoc): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.updateClip(clip)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/clips/${clip.id}"
        return try {
            val uid = requireUserId()
            require(clip.id.isNotBlank()) { "Clip ID cannot be blank" }
            val ref = userDoc(uid).collection("clips").document(clip.id)
            docPath = ref.path
            val safeStart = clip.startSec.coerceIn(0L, 86400L)
            val safeEnd = clip.endSec.coerceIn(safeStart, 86400L)
            ref.update(
                mapOf(
                    "title" to clip.title.ifBlank { "Viral Highlight" }.take(160),
                    "hook" to clip.hook.take(240),
                    "viralScore" to clip.viralScore.coerceIn(0L, 100L),
                    "startSec" to safeStart,
                    "endSec" to safeEnd,
                    "subtitlesEnabled" to clip.subtitlesEnabled,
                    "subtitleStyle" to clip.subtitleStyle,
                    "captions" to clip.captions.take(40).map { it.toMap() },
                    "aspectRatio" to if (clip.aspectRatio in listOf("9:16", "16:9", "1:1", "4:5")) clip.aspectRatio else "9:16",
                    "filterPreset" to clip.filterPreset,
                    "playbackSpeed" to clip.playbackSpeed.coerceIn(0.25, 4.0),
                    "zoomScale" to clip.zoomScale.coerceIn(0.5, 3.0),
                    "brightness" to clip.brightness.coerceIn(-1.0, 1.0),
                    "contrast" to clip.contrast.coerceIn(0.2, 3.0),
                    "saturation" to clip.saturation.coerceIn(0.0, 3.0),
                    "warmth" to clip.warmth.coerceIn(-1.0, 1.0),
                    "vignette" to clip.vignette.coerceIn(0.0, 1.0),
                    "rotationDeg" to ((clip.rotationDeg % 360 + 360) % 360),
                    "flipHorizontal" to clip.flipHorizontal,
                    "videoEffect" to clip.videoEffect,
                    "transitionType" to clip.transitionType,
                    "voiceVolume" to clip.voiceVolume.coerceIn(0.0, 1.5),
                    "voiceEffect" to clip.voiceEffect,
                    "audioFadeIn" to clip.audioFadeIn,
                    "audioFadeOut" to clip.audioFadeOut,
                    "musicTrack" to clip.musicTrack,
                    "musicVolume" to clip.musicVolume.coerceIn(0.0, 1.5),
                    "noiseReduction" to clip.noiseReduction,
                    "overlayText" to clip.overlayText.take(120),
                    "captionPosition" to clip.captionPosition,
                    "captionScale" to clip.captionScale.coerceIn(0.6, 2.0),
                    "thumbnailTemplate" to clip.thumbnailTemplate,
                    "exportResolution" to if (clip.exportResolution in listOf("720p", "1080p", "2K", "4K")) clip.exportResolution else "1080p",
                    "exportFps" to if (clip.exportFps in listOf(24L, 30L, 60L)) clip.exportFps else 60L,
                    "exportBitrate" to clip.exportBitrate,
                    "exportFormat" to clip.exportFormat,
                    "optimizedPlatform" to clip.optimizedPlatform,
                    "seoTitle" to clip.seoTitle.take(160),
                    "seoDescription" to clip.seoDescription.take(1000),
                    "seoTags" to clip.seoTags.take(20).map { it.take(40) },
                    "exportedPath" to clip.exportedPath.take(500),
                    "waveformBars" to clip.waveformBars.take(64),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteClip(clipId: String): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.deleteClip(clipId)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/clips/$clipId"
        return try {
            val uid = requireUserId()
            require(clipId.isNotBlank()) { "Clip ID cannot be blank" }
            val ref = userDoc(uid).collection("clips").document(clipId)
            docPath = ref.path
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertSocialAccount(account: SocialAccountDoc): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.upsertSocialAccount(account)
            return Result.success(Unit)
        }
        val docId = "acc_${account.platform.lowercase()}"
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/socialAccounts/$docId"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid).collection("socialAccounts").document(docId)
            docPath = ref.path
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "handle" to account.handle.ifBlank { "@creator" }.take(80),
                        "connected" to account.connected,
                        "autoOptimize" to account.autoOptimize,
                        "followersCount" to account.followersCount.coerceIn(0L, 1_000_000_000L),
                        "peakTimeWindow" to account.peakTimeWindow.take(80),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(account.toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun createScheduledPost(post: ScheduledPostDoc): Result<String> {
        if (isGuestMode && localGuestStore != null) {
            return Result.success(localGuestStore.createScheduledPost(post))
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/scheduledPosts"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid).collection("scheduledPosts").document()
            docPath = ref.path
            ref.set(post.toCreateMap(uid)).await()
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateScheduledPost(
        postId: String,
        scheduledAtEpochMs: Long,
        scheduledLabel: String,
        peakScore: Long,
        status: PostStatus
    ): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.updateScheduledPost(postId, scheduledAtEpochMs, scheduledLabel, peakScore, status)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/scheduledPosts/$postId"
        return try {
            val uid = requireUserId()
            require(postId.isNotBlank()) { "Post ID cannot be blank" }
            val ref = userDoc(uid).collection("scheduledPosts").document(postId)
            docPath = ref.path
            ref.update(
                mapOf(
                    "scheduledAtEpochMs" to scheduledAtEpochMs.coerceAtLeast(1L),
                    "scheduledLabel" to scheduledLabel.ifBlank { "Peak Window" }.take(80),
                    "peakScore" to peakScore.coerceIn(0L, 100L),
                    "status" to status.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteScheduledPost(postId: String): Result<Unit> {
        if (isGuestMode && localGuestStore != null) {
            localGuestStore.deleteScheduledPost(postId)
            return Result.success(Unit)
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/scheduledPosts/$postId"
        return try {
            val uid = requireUserId()
            require(postId.isNotBlank()) { "Post ID cannot be blank" }
            val ref = userDoc(uid).collection("scheduledPosts").document(postId)
            docPath = ref.path
            ref.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun logAnalyticsRecord(record: AnalyticsRecordDoc): Result<String> {
        if (isGuestMode && localGuestStore != null) {
            return Result.success(localGuestStore.logAnalyticsRecord(record))
        }
        var docPath = "users/${auth.currentUser?.uid ?: "unauth"}/analytics"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid).collection("analytics").document()
            docPath = ref.path
            ref.set(record.toCreateMap(uid)).await()
            Result.success(ref.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    fun clearLocalWorkspace() {
        localGuestStore?.clearAllLocalData()
    }

    private fun logStreamErrorIfActive(
        error: Throwable,
        op: OperationType,
        path: String,
        uid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }
}
