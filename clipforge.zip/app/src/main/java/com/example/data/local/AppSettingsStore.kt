package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

import com.example.BuildConfig

private val Context.clipForgeSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "clipforge_app_settings"
)

data class AppSettings(
    val defaultExportResolution: String = "1080p",
    val defaultExportFps: Long = 60L,
    val defaultExportBitrate: String = "HIGH",
    val defaultExportFormat: String = "MP4_H264",
    val autoSaveToGallery: Boolean = true,
    val autoCaptionsOnUpload: Boolean = true,
    val autoWaveformAnalysis: Boolean = true,
    val smartDirectorTone: String = "Viral High-Energy"
) {
    fun isGroqSecretSet(): Boolean {
        val key = BuildConfig.GROQ_API_KEY.trim()
        return key.isNotBlank() &&
            !key.equals("MY_GROQ_API_KEY", ignoreCase = true) &&
            !key.equals("null", ignoreCase = true) &&
            key.length > 12
    }

    fun effectiveEngineLabel(): String =
        if (isGroqSecretSet()) "Groq Llama-3.3 • $defaultExportResolution"
        else "On-Device AI • $defaultExportResolution"
}

class AppSettingsStore(context: Context) {
    private val dataStore = context.applicationContext.clipForgeSettingsDataStore

    private object Keys {
        val DEFAULT_EXPORT_RES = stringPreferencesKey("default_export_res")
        val DEFAULT_EXPORT_FPS = longPreferencesKey("default_export_fps")
        val DEFAULT_EXPORT_BITRATE = stringPreferencesKey("default_export_bitrate")
        val DEFAULT_EXPORT_FORMAT = stringPreferencesKey("default_export_format")
        val AUTO_SAVE_GALLERY = booleanPreferencesKey("auto_save_gallery")
        val AUTO_CAPTIONS_UPLOAD = booleanPreferencesKey("auto_captions_upload")
        val AUTO_WAVEFORM_ANALYSIS = booleanPreferencesKey("auto_waveform_analysis")
        val SMART_DIRECTOR_TONE = stringPreferencesKey("smart_director_tone")
    }

    val settingsFlow: Flow<AppSettings> = dataStore.data
        .catch { err ->
            if (err is IOException) emit(emptyPreferences()) else throw err
        }
        .map { prefs ->
            AppSettings(
                defaultExportResolution = prefs[Keys.DEFAULT_EXPORT_RES] ?: "1080p",
                defaultExportFps = prefs[Keys.DEFAULT_EXPORT_FPS] ?: 60L,
                defaultExportBitrate = prefs[Keys.DEFAULT_EXPORT_BITRATE] ?: "HIGH",
                defaultExportFormat = prefs[Keys.DEFAULT_EXPORT_FORMAT] ?: "MP4_H264",
                autoSaveToGallery = prefs[Keys.AUTO_SAVE_GALLERY] ?: true,
                autoCaptionsOnUpload = prefs[Keys.AUTO_CAPTIONS_UPLOAD] ?: true,
                autoWaveformAnalysis = prefs[Keys.AUTO_WAVEFORM_ANALYSIS] ?: true,
                smartDirectorTone = prefs[Keys.SMART_DIRECTOR_TONE] ?: "Viral High-Energy"
            )
        }

    suspend fun currentSettings(): AppSettings = settingsFlow.first()

    suspend fun updateSettings(updated: AppSettings) {
        dataStore.edit { prefs ->
            prefs[Keys.DEFAULT_EXPORT_RES] = updated.defaultExportResolution
            prefs[Keys.DEFAULT_EXPORT_FPS] = updated.defaultExportFps
            prefs[Keys.DEFAULT_EXPORT_BITRATE] = updated.defaultExportBitrate
            prefs[Keys.DEFAULT_EXPORT_FORMAT] = updated.defaultExportFormat
            prefs[Keys.AUTO_SAVE_GALLERY] = updated.autoSaveToGallery
            prefs[Keys.AUTO_CAPTIONS_UPLOAD] = updated.autoCaptionsOnUpload
            prefs[Keys.AUTO_WAVEFORM_ANALYSIS] = updated.autoWaveformAnalysis
            prefs[Keys.SMART_DIRECTOR_TONE] = updated.smartDirectorTone.trim().ifBlank { "Viral High-Energy" }
        }
    }
}
