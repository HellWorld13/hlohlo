package com.example.data.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class HighlightPeakWindow(
    val startSec: Long,
    val endSec: Long,
    val peakScore: Long,
    val thumbnailPath: String
)

data class SignalAnalysisResult(
    val durationSec: Long,
    val waveformBars: List<Float>,
    val peakWindows: List<HighlightPeakWindow>
)

class OnDeviceSignalAnalyzer(private val appContext: Context) {

    suspend fun analyzeVideoHighlights(
        uri: Uri,
        seedTitle: String,
        durationHintSec: Long,
        barCount: Int = 48,
        clipCount: Int = 3,
        minClipSec: Long = 30L,
        maxClipSec: Long = 90L
    ): SignalAnalysisResult = withContext(Dispatchers.IO) {
        val actualDurationSec = extractDurationSec(uri, durationHintSec).coerceAtLeast(10L)
        val decodedBars = extractAudioWaveformBars(uri, actualDurationSec, barCount)
            ?: generateSynthesizedWaveform(seedTitle, barCount)

        val windows = pickTopHighlightWindows(
            waveformBars = decodedBars,
            durationSec = actualDurationSec,
            count = clipCount.coerceIn(1, 10),
            minClipSec = minClipSec,
            maxClipSec = maxClipSec
        ).mapIndexed { index, (startSec, endSec, score) ->
            val midSec = ((startSec + endSec) / 2L).coerceIn(0L, actualDurationSec)
            val thumb = captureFrameThumbnail(
                uri = uri,
                timeSec = midSec,
                label = "auto_${System.currentTimeMillis()}_$index"
            ).orEmpty()
            HighlightPeakWindow(
                startSec = startSec,
                endSec = endSec,
                peakScore = score,
                thumbnailPath = thumb
            )
        }

        SignalAnalysisResult(
            durationSec = actualDurationSec,
            waveformBars = decodedBars,
            peakWindows = windows
        )
    }

    suspend fun captureFrameThumbnail(
        uri: Uri,
        timeSec: Long,
        label: String = "cover"
    ): String? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(appContext, uri)
            val frame = retriever.getFrameAtTime(
                timeSec.coerceAtLeast(0L) * 1_000_000L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: retriever.frameAtTime ?: return@withContext null

            val maxSide = 720
            val scaled = if (frame.width > maxSide || frame.height > maxSide) {
                val ratio = minOf(maxSide.toFloat() / frame.width, maxSide.toFloat() / frame.height)
                val targetW = (frame.width * ratio).roundToInt().coerceAtLeast(1)
                val targetH = (frame.height * ratio).roundToInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(frame, targetW, targetH, true).also {
                    if (it !== frame) frame.recycle()
                }
            } else {
                frame
            }

            val thumbsDir = File(appContext.filesDir, "thumbs").apply { mkdirs() }
            val safeLabel = label.replace(Regex("[^A-Za-z0-9_-]"), "_").take(28).ifBlank { "frame" }
            val outFile = File(thumbsDir, "${safeLabel}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { fos ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 88, fos)
            }
            if (!scaled.isRecycled) scaled.recycle()
            "file://${outFile.absolutePath}"
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun getMediaCacheSizeMb(): Double {
        val exportsBytes = dirSizeBytes(File(appContext.filesDir, "exports"))
        val thumbsBytes = dirSizeBytes(File(appContext.filesDir, "thumbs"))
        return (exportsBytes + thumbsBytes) / (1024.0 * 1024.0)
    }

    fun clearMediaCaches(): Long {
        var freed = 0L
        listOf("exports", "thumbs").forEach { folder ->
            val dir = File(appContext.filesDir, folder)
            if (dir.exists()) {
                dir.listFiles()?.forEach { file ->
                    freed += file.length()
                    file.delete()
                }
            }
        }
        return freed
    }

    private fun dirSizeBytes(dir: File): Long {
        if (!dir.exists()) return 0L
        return dir.listFiles()?.sumOf { if (it.isDirectory) dirSizeBytes(it) else it.length() } ?: 0L
    }

    private fun extractDurationSec(uri: Uri, fallback: Long): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(appContext, uri)
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (ms != null && ms > 1000L) ms / 1000L else fallback
        } catch (_: Exception) {
            fallback
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun extractAudioWaveformBars(
        uri: Uri,
        durationSec: Long,
        barCount: Int
    ): List<Float>? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(appContext, uri, null)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return null

            val mime = audioFormat.getString(MediaFormat.KEY_MIME) ?: return null
            extractor.selectTrack(audioTrackIndex)
            codec = MediaCodec.createDecoderByType(mime).apply {
                configure(audioFormat, null, null, 0)
                start()
            }

            val totalUs = (durationSec * 1_000_000L).coerceAtLeast(1_000_000L)
            val bucketRms = FloatArray(barCount)
            val bufferInfo = MediaCodec.BufferInfo()

            for (b in 0 until barCount) {
                val seekUs = (totalUs * b) / barCount
                extractor.seekTo(seekUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                codec.flush()

                var sumSq = 0.0
                var sampleCount = 0
                var probes = 0

                while (probes < 5 && sampleCount < 3072) {
                    probes++
                    val inIdx = codec.dequeueInputBuffer(6_000L)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                        if (size >= 0) {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        } else {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        }
                    }

                    val outIdx = codec.dequeueOutputBuffer(bufferInfo, 6_000L)
                    if (outIdx >= 0) {
                        val outBuf = codec.getOutputBuffer(outIdx)
                        if (outBuf != null && bufferInfo.size > 0) {
                            outBuf.position(bufferInfo.offset)
                            val shortBuf = outBuf.asShortBuffer()
                            val n = shortBuf.remaining().coerceAtMost(2048)
                            for (s in 0 until n) {
                                val normalized = shortBuf.get(s) / 32768.0
                                sumSq += normalized * normalized
                            }
                            sampleCount += n
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                    }
                }

                bucketRms[b] = if (sampleCount > 0) {
                    sqrt(sumSq / sampleCount).toFloat()
                } else {
                    0.08f
                }
            }

            val maxRms = bucketRms.maxOrNull()?.coerceAtLeast(0.01f) ?: 1f
            bucketRms.map { raw -> (0.16f + (raw / maxRms) * 0.84f).coerceIn(0.15f, 1.0f) }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    /**
     * Selects top non-overlapping 30..90s windows using continuous sliding-window energy
     * across the decoded RMS waveform. When source video < 30s, keeps a clean full-length clip.
     */
    private fun pickTopHighlightWindows(
        waveformBars: List<Float>,
        durationSec: Long,
        count: Int,
        minClipSec: Long,
        maxClipSec: Long
    ): List<Triple<Long, Long, Long>> {
        val safeDur = durationSec.coerceAtLeast(8L)
        if (safeDur <= 30L) {
            return listOf(Triple(0L, safeDur, 94L))
        }

        val effMin = minClipSec.coerceIn(30L, 90L).coerceAtMost(safeDur)
        val effMax = maxClipSec.coerceIn(effMin, 90L).coerceAtMost(safeDur)
        val defaultLen = ((effMin + effMax) / 2L).coerceIn(effMin, effMax)

        // If the video itself is between 30s and 90s, first clip captures the peak continuous core (30..safeDur)
        if (safeDur <= 90L) {
            val len1 = safeDur.coerceIn(30L, effMax)
            val results = mutableListOf(Triple(0L, len1, 95L))
            if (count > 1 && safeDur >= 40L) {
                val len2 = (safeDur * 2L / 3L).coerceIn(30L, effMax)
                val s2 = (safeDur - len2).coerceAtLeast(0L)
                if (s2 >= 5L) results.add(Triple(s2, safeDur, 90L))
            }
            return results.take(count)
        }

        val barCount = waveformBars.size.coerceAtLeast(1)
        val secPerBar = safeDur.toFloat() / barCount

        // Score every candidate start bar using cumulative RMS energy across the clip duration
        val scoredCandidates = waveformBars.indices.map { startBar ->
            val targetLen = (effMin + ((startBar * 11L) % (effMax - effMin + 1L))).coerceIn(effMin, effMax)
            val spanBars = (targetLen / secPerBar).roundToInt().coerceIn(1, barCount)
            val endBar = (startBar + spanBars).coerceAtMost(barCount)
            var sumEnergy = 0f
            for (i in startBar until endBar) {
                sumEnergy += waveformBars[i]
            }
            val avgEnergy = sumEnergy / (endBar - startBar).coerceAtLeast(1)
            val startSec = (startBar * secPerBar).toLong().coerceIn(0L, (safeDur - targetLen).coerceAtLeast(0L))
            Triple(startSec, targetLen, avgEnergy)
        }.sortedByDescending { it.third }

        val chosen = mutableListOf<Triple<Long, Long, Long>>()
        for ((candStart, candLen, avgEnergy) in scoredCandidates) {
            val candEnd = (candStart + candLen).coerceAtMost(safeDur)
            val actualLen = candEnd - candStart
            if (actualLen < effMin) continue
            val overlaps = chosen.any { (es, ee, _) ->
                candStart < ee - 8L && candEnd > es + 8L
            }
            if (!overlaps) {
                val viralScore = (84 + (avgEnergy * 15f).roundToInt()).toLong().coerceIn(84L, 98L)
                chosen.add(Triple(candStart, candEnd, viralScore))
                if (chosen.size >= count) break
            }
        }

        // Fill remaining slots evenly if video is long enough, respecting effMin..effMax
        var slotIdx = 0
        while (chosen.size < count && slotIdx < count * 2) {
            val step = ((safeDur - defaultLen).coerceAtLeast(0L) / count.coerceAtLeast(1)).coerceAtLeast(1L)
            val s = (slotIdx * step).coerceIn(0L, (safeDur - defaultLen).coerceAtLeast(0L))
            val e = (s + defaultLen).coerceAtMost(safeDur)
            if ((e - s) >= effMin && chosen.none { abs(it.first - s) < 12L }) {
                chosen.add(Triple(s, e, (90L - slotIdx * 2L).coerceAtLeast(82L)))
            }
            slotIdx++
        }

        return chosen.take(count).sortedBy { it.first }
    }

    companion object {
        fun generateSynthesizedWaveform(seedText: String, count: Int = 48): List<Float> {
            val hash = abs(seedText.hashCode())
            return List(count) { i ->
                val wave1 = kotlin.math.sin((i + (hash % 13)) * 0.42).toFloat()
                val wave2 = kotlin.math.cos((i * 1.3 + (hash % 7)) * 0.27).toFloat()
                (0.32f + abs(wave1 * 0.42f + wave2 * 0.26f)).coerceIn(0.18f, 0.98f)
            }
        }
    }
}
