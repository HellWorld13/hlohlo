package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class SocialPlatform(
    val label: String,
    val shortLabel: String,
    val targetRatio: String,
    val maxDurationLabel: String,
    val optimizationSpec: String,
    val defaultPeakWindow: String
) {
    TIKTOK(
        label = "TikTok",
        shortLabel = "TikTok",
        targetRatio = "9:16",
        maxDurationLabel = "3m max",
        optimizationSpec = "9:16 • 1080×1920 • 60fps • -14 LUFS",
        defaultPeakWindow = "6:30 PM – 9:30 PM"
    ),
    YOUTUBE_SHORTS(
        label = "YouTube Shorts",
        shortLabel = "YT Shorts",
        targetRatio = "9:16",
        maxDurationLabel = "60s max",
        optimizationSpec = "9:16 • 1080×1920 • ≤60s • #Shorts SEO",
        defaultPeakWindow = "12:00 PM – 3:00 PM"
    ),
    INSTAGRAM_REELS(
        label = "Instagram Reels",
        shortLabel = "Reels",
        targetRatio = "9:16",
        maxDurationLabel = "90s max",
        optimizationSpec = "9:16 • Safe Zone 14% • 30/60fps MP4",
        defaultPeakWindow = "11:00 AM – 2:00 PM"
    ),
    X(
        label = "X (Twitter)",
        shortLabel = "X",
        targetRatio = "16:9",
        maxDurationLabel = "2m20s",
        optimizationSpec = "16:9 or 1:1 • High Bitrate H.264",
        defaultPeakWindow = "8:30 AM – 11:00 AM"
    ),
    LINKEDIN(
        label = "LinkedIn",
        shortLabel = "LinkedIn",
        targetRatio = "4:5",
        maxDurationLabel = "3m max",
        optimizationSpec = "4:5 Feed Portrait • Captions Burned/CC",
        defaultPeakWindow = "9:00 AM – 11:30 AM"
    );

    companion object {
        fun fromRaw(raw: String): SocialPlatform =
            entries.firstOrNull { it.name == raw } ?: TIKTOK
    }
}

enum class SubtitleStyle(val label: String, val badge: String) {
    HORMOZI_POP("Hormozi Pop", "BOLD IMPACT"),
    KARAOKE_GLOW("Karaoke Glow", "WORD SYNC"),
    MINIMAL_PILL("Minimal Pill", "CLEAN BAR"),
    NEON_BOX("Neon Box", "CYBER FRAME"),
    CAPTION_OUTLINE("CapCut Outline", "PRO STROKE"),
    YELLOW_CREATOR("Yellow Viral", "HIGH CTR");

    companion object {
        fun fromRaw(raw: String): SubtitleStyle =
            entries.firstOrNull { it.name == raw } ?: HORMOZI_POP
    }
}

enum class CaptionPosition(val label: String) {
    TOP("Top"),
    CENTER("Center"),
    BOTTOM("Bottom");

    companion object {
        fun fromRaw(raw: String): CaptionPosition =
            entries.firstOrNull { it.name == raw } ?: BOTTOM
    }
}

enum class FilterPreset(val label: String, val category: String) {
    NONE("Original", "Basic"),
    CRISP_STUDIO("Crisp HD", "Pro"),
    VIVID_POP("TikTok Vivid", "Viral"),
    TIKTOK_GLOW("TikTok Glow", "Portrait"),
    CYBER_CYAN("Cyber Neon", "Sci-Fi"),
    TEAL_ORANGE("Teal & Orange", "Cinema"),
    GOLDEN_HOUR("Golden Hour", "Warm"),
    SUNSET_WARM("Sunset Coral", "Warm"),
    OBSIDIAN("Obsidian", "Moody"),
    TUNGSTEN("Warm Tungsten", "Warm"),
    MOODY_NOIR("Moody Noir", "Mono"),
    VINTAGE("VHS Retro", "Retro"),
    BW_DRAMATIC("B&W Pro", "Mono"),
    ANIME_BLOOM("Soft Bloom", "Glow"),
    KODAK_FILM("Kodak 400", "Film"),
    PASTEL_CREAM("Pastel Cream", "Portrait");

    companion object {
        fun fromRaw(raw: String): FilterPreset =
            entries.firstOrNull { it.name == raw } ?: NONE
    }
}

enum class VideoEffect(val label: String, val badge: String) {
    NONE("None", "Clean"),
    ZOOM_PULSE("Beat Zoom", "Rhythm"),
    GLITCH_RGB("RGB Glitch", "Viral"),
    VHS_SCAN("Retro VHS", "90s Cam"),
    FLASH_CUT("Flash Cut", "Hook"),
    BLUR_VIGNETTE("Dream Glow", "Soft"),
    SHAKE_IMPACT("Impact Shake", "Energy"),
    CHROMA_SPLIT("Chroma Split", "TikTok"),
    FILM_GRAIN("Cinema Grain", "Film"),
    NEON_EDGE("Neon Rim", "Cyber"),
    STROBE_PULSE("Beat Strobe", "Hype"),
    MIRROR_TWIN("Mirror Split", "FX");

    companion object {
        fun fromRaw(raw: String): VideoEffect =
            entries.firstOrNull { it.name == raw } ?: NONE
    }
}

enum class SpeedCurvePreset(val label: String, val speedMultiplier: Double, val badge: String) {
    NORMAL("Normal", 1.0, "1.0x"),
    MONTAGE("Montage", 1.18, "Punchy"),
    HERO_TIME("Hero Slow", 0.75, "Dramatic"),
    BULLET_CUT("Bullet Fast", 1.35, "High Energy"),
    JUMP_CUT("Crisp 1.08x", 1.08, "Retention");

    companion object {
        fun fromRaw(raw: String): SpeedCurvePreset =
            entries.firstOrNull { it.name == raw } ?: NORMAL
    }
}

enum class ClipTransition(val label: String) {
    NONE("Cut"),
    FADE_BLACK("Fade In/Out"),
    WHIP_PAN("Whip Pan"),
    ZOOM_IN("Zoom Through"),
    GLITCH_SNAP("Glitch Snap");

    companion object {
        fun fromRaw(raw: String): ClipTransition =
            entries.firstOrNull { it.name == raw } ?: NONE
    }
}

enum class VoiceEffect(val label: String) {
    NORMAL("Original"),
    STUDIO_CRISP("Studio Mic"),
    DEEP_RADIO("Deep Podcast"),
    HIGH_ENERGY("Crisp Boost");

    companion object {
        fun fromRaw(raw: String): VoiceEffect =
            entries.firstOrNull { it.name == raw } ?: NORMAL
    }
}

enum class MusicTrack(val label: String, val bpmLabel: String) {
    NONE("No Music", "Original Audio"),
    PHONK_DRIVE("Phonk Drive", "132 BPM"),
    LOFI_CHILL("Lo-Fi Chill", "86 BPM"),
    HYPER_BEAT("Hyper Beat", "140 BPM"),
    CINEMATIC_PULSE("Cinematic Pulse", "110 BPM"),
    TRAP_BOUNCE("Trap Bounce", "145 BPM"),
    SYNTHWAVE_RUN("Synthwave Run", "124 BPM"),
    PODCAST_BED("Soft Podcast Bed", "92 BPM");

    companion object {
        fun fromRaw(raw: String): MusicTrack =
            entries.firstOrNull { it.name == raw } ?: NONE
    }
}

enum class StudioTemplate(
    val label: String,
    val tagline: String,
    val filter: FilterPreset,
    val effect: VideoEffect,
    val transition: ClipTransition,
    val subtitleStyle: SubtitleStyle,
    val musicTrack: MusicTrack,
    val thumbnailTemplate: ThumbnailTemplate,
    val speed: Double,
    val zoom: Double,
    val contrast: Double,
    val saturation: Double,
    val warmth: Double,
    val vignette: Double,
    val overlayBadge: String
) {
    VIRAL_HOOK(
        label = "TikTok Viral Hook",
        tagline = "Hormozi Pop + Beat Zoom + 1.08x",
        filter = FilterPreset.VIVID_POP,
        effect = VideoEffect.ZOOM_PULSE,
        transition = ClipTransition.ZOOM_IN,
        subtitleStyle = SubtitleStyle.HORMOZI_POP,
        musicTrack = MusicTrack.HYPER_BEAT,
        thumbnailTemplate = ThumbnailTemplate.NEON_HOOK,
        speed = 1.08,
        zoom = 1.10,
        contrast = 1.15,
        saturation = 1.18,
        warmth = 0.04,
        vignette = 0.14,
        overlayBadge = "WAIT FOR IT"
    ),
    OPUS_HORMOZI(
        label = "Opus Retention",
        tagline = "Crisp HD + Karaoke Glow + Tight Cut",
        filter = FilterPreset.CRISP_STUDIO,
        effect = VideoEffect.NONE,
        transition = ClipTransition.WHIP_PAN,
        subtitleStyle = SubtitleStyle.KARAOKE_GLOW,
        musicTrack = MusicTrack.PODCAST_BED,
        thumbnailTemplate = ThumbnailTemplate.BOLD_SPLIT,
        speed = 1.10,
        zoom = 1.08,
        contrast = 1.16,
        saturation = 1.10,
        warmth = 0.02,
        vignette = 0.10,
        overlayBadge = "KEY SECRET"
    ),
    PODCAST_SPLIT(
        label = "Podcast Broadcast",
        tagline = "Warm Tungsten + Yellow Viral + Studio Mic",
        filter = FilterPreset.TUNGSTEN,
        effect = VideoEffect.FILM_GRAIN,
        transition = ClipTransition.FADE_BLACK,
        subtitleStyle = SubtitleStyle.YELLOW_CREATOR,
        musicTrack = MusicTrack.LOFI_CHILL,
        thumbnailTemplate = ThumbnailTemplate.PODCAST_QUOTE,
        speed = 1.05,
        zoom = 1.06,
        contrast = 1.14,
        saturation = 1.12,
        warmth = 0.12,
        vignette = 0.18,
        overlayBadge = "HOT TAKE"
    ),
    CYBER_REVIEW(
        label = "Cyber Neon Tech",
        tagline = "Cyber Neon + Chroma Split + Neon Box",
        filter = FilterPreset.CYBER_CYAN,
        effect = VideoEffect.CHROMA_SPLIT,
        transition = ClipTransition.GLITCH_SNAP,
        subtitleStyle = SubtitleStyle.NEON_BOX,
        musicTrack = MusicTrack.SYNTHWAVE_RUN,
        thumbnailTemplate = ThumbnailTemplate.TECH_GLOW,
        speed = 1.08,
        zoom = 1.12,
        contrast = 1.20,
        saturation = 1.22,
        warmth = -0.10,
        vignette = 0.20,
        overlayBadge = "PRO BREAKDOWN"
    ),
    CINEMA_REEL(
        label = "Cinema Teal",
        tagline = "Teal & Orange + Dream Glow + Outline",
        filter = FilterPreset.TEAL_ORANGE,
        effect = VideoEffect.BLUR_VIGNETTE,
        transition = ClipTransition.FADE_BLACK,
        subtitleStyle = SubtitleStyle.CAPTION_OUTLINE,
        musicTrack = MusicTrack.CINEMATIC_PULSE,
        thumbnailTemplate = ThumbnailTemplate.MINIMAL_CLEAN,
        speed = 1.0,
        zoom = 1.05,
        contrast = 1.18,
        saturation = 1.10,
        warmth = 0.08,
        vignette = 0.28,
        overlayBadge = "WATCH CLOSELY"
    ),
    FAST_MONTAGE(
        label = "Phonk Flash Cut",
        tagline = "Flash Cut + 1.18x + Phonk Drive",
        filter = FilterPreset.SUNSET_WARM,
        effect = VideoEffect.FLASH_CUT,
        transition = ClipTransition.GLITCH_SNAP,
        subtitleStyle = SubtitleStyle.HORMOZI_POP,
        musicTrack = MusicTrack.PHONK_DRIVE,
        thumbnailTemplate = ThumbnailTemplate.NEON_HOOK,
        speed = 1.18,
        zoom = 1.16,
        contrast = 1.22,
        saturation = 1.24,
        warmth = 0.06,
        vignette = 0.16,
        overlayBadge = "NO WAY"
    ),
    KODAK_STORY(
        label = "Kodak Storytime",
        tagline = "Kodak 400 + Film Grain + Minimal Pill",
        filter = FilterPreset.KODAK_FILM,
        effect = VideoEffect.VHS_SCAN,
        transition = ClipTransition.WHIP_PAN,
        subtitleStyle = SubtitleStyle.MINIMAL_PILL,
        musicTrack = MusicTrack.LOFI_CHILL,
        thumbnailTemplate = ThumbnailTemplate.PODCAST_QUOTE,
        speed = 1.02,
        zoom = 1.04,
        contrast = 1.10,
        saturation = 1.06,
        warmth = 0.16,
        vignette = 0.22,
        overlayBadge = "STORYTIME"
    ),
    CLEAN_CREATOR(
        label = "Clean TikTok Glow",
        tagline = "TikTok Glow + Soft Bloom + Trap Bounce",
        filter = FilterPreset.TIKTOK_GLOW,
        effect = VideoEffect.NEON_EDGE,
        transition = ClipTransition.ZOOM_IN,
        subtitleStyle = SubtitleStyle.KARAOKE_GLOW,
        musicTrack = MusicTrack.TRAP_BOUNCE,
        thumbnailTemplate = ThumbnailTemplate.BOLD_SPLIT,
        speed = 1.05,
        zoom = 1.09,
        contrast = 1.12,
        saturation = 1.16,
        warmth = 0.05,
        vignette = 0.12,
        overlayBadge = "MUST TRY"
    );

    companion object {
        fun fromRaw(raw: String): StudioTemplate? =
            entries.firstOrNull { it.name == raw }
    }
}

enum class ThumbnailTemplate(val label: String, val subtitle: String) {
    BOLD_SPLIT("Bold Split", "High-contrast 2-line headline"),
    NEON_HOOK("Neon Hook", "Glowing coral frame + hook badge"),
    PODCAST_QUOTE("Podcast Quote", "Warm broadcast quote card"),
    TECH_GLOW("Tech Glow", "Cyan rim accent + score pill"),
    MINIMAL_CLEAN("Minimal Clean", "Editorial top/bottom margin");

    companion object {
        fun fromRaw(raw: String): ThumbnailTemplate =
            entries.firstOrNull { it.name == raw } ?: NEON_HOOK
    }
}

enum class ExportResolution(val label: String, val widthPx: Int, val heightPx: Int) {
    RES_720P("720p", 720, 1280),
    RES_1080P("1080p", 1080, 1920),
    RES_2K("2K", 1440, 2560),
    RES_4K("4K", 2160, 3840);

    companion object {
        fun fromRaw(raw: String): ExportResolution =
            entries.firstOrNull { it.label == raw || it.name == raw } ?: RES_1080P
    }
}

enum class ExportBitrate(val label: String, val mbps: String, val bitsPerSec: Int) {
    STANDARD("Standard", "8 Mbps", 8_000_000),
    HIGH("High HD", "15 Mbps", 15_000_000),
    ULTRA("Ultra Pro", "25 Mbps", 25_000_000);

    companion object {
        fun fromRaw(raw: String): ExportBitrate =
            entries.firstOrNull { it.name == raw } ?: HIGH
    }
}

enum class ExportFormat(val label: String) {
    MP4_H264("MP4 (H.264)"),
    HEVC_H265("HEVC (H.265)");

    companion object {
        fun fromRaw(raw: String): ExportFormat =
            entries.firstOrNull { it.name == raw } ?: MP4_H264
    }
}

enum class MediaSourceType(val label: String) {
    YOUTUBE("YouTube"),
    UPLOADED("Uploaded"),
    CLIP("AI Clip");

    companion object {
        fun fromRaw(raw: String): MediaSourceType =
            entries.firstOrNull { it.name == raw } ?: CLIP
    }
}

enum class MediaStatus(val label: String) {
    READY("Ready"),
    PROCESSING("Processing"),
    EXPORTED("Exported");

    companion object {
        fun fromRaw(raw: String): MediaStatus =
            entries.firstOrNull { it.name == raw } ?: READY
    }
}

enum class PostStatus(val label: String) {
    SCHEDULED("Scheduled"),
    PUBLISHED("Published"),
    DRAFT("Draft");

    companion object {
        fun fromRaw(raw: String): PostStatus =
            entries.firstOrNull { it.name == raw } ?: SCHEDULED
    }
}

@Keep
@IgnoreExtraProperties
data class CaptionCue(
    val startSec: Long = 0L,
    val endSec: Long = 0L,
    val text: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "startSec" to startSec,
        "endSec" to endSec,
        "text" to text.take(160)
    )
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Creator",
    val defaultPlatform: String = SocialPlatform.TIKTOK.name,
    val autoSubtitlesEnabled: Boolean = true,
    val superAiActive: Boolean = false,
    val superAiNiche: String = "Trending & Viral",
    val superAiChannel: String = "",
    val superAiAutoPostNow: Boolean = false,
    val superAiPostingTimes: List<String> = listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM"),
    val autoDelete24hEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class MediaItemDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val sourceType: String = MediaSourceType.YOUTUBE.name,
    val sourceUrl: String = "",
    val youtubeVideoId: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Long = 0L,
    val aspectRatio: String = "16:9",
    val status: String = MediaStatus.READY.name,
    val createdEpochMs: Long = 0L,
    val superAiGenerated: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun effectiveCreatedEpochMs(): Long =
        if (createdEpochMs > 0L) createdEpochMs else (createdAt?.toDate()?.time ?: System.currentTimeMillis())

    fun toCreateMap(uid: String): Map<String, Any> {
        val nowMs = if (createdEpochMs > 0L) createdEpochMs else System.currentTimeMillis()
        return mapOf(
            "userId" to uid,
            "title" to title.ifBlank { "Untitled Video" }.take(160),
            "sourceType" to sourceType,
            "sourceUrl" to sourceUrl.take(500),
            "youtubeVideoId" to youtubeVideoId.take(32),
            "thumbnailUrl" to thumbnailUrl.take(500),
            "durationSeconds" to durationSeconds.coerceIn(0L, 86400L),
            "aspectRatio" to if (aspectRatio in listOf("9:16", "16:9", "1:1", "4:5")) aspectRatio else "16:9",
            "status" to status,
            "createdEpochMs" to nowMs,
            "superAiGenerated" to superAiGenerated,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}

@Keep
@IgnoreExtraProperties
data class ViralClipDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val mediaId: String = "",
    val sourceUrl: String = "",
    val youtubeVideoId: String = "",
    val thumbnailUrl: String = "",
    val title: String = "",
    val hook: String = "",
    val viralScore: Long = 85L,
    val hookScore: Long = 88L,
    val viralReason: String = "",
    val startSec: Long = 0L,
    val endSec: Long = 35L,
    val subtitlesEnabled: Boolean = true,
    val subtitleStyle: String = SubtitleStyle.HORMOZI_POP.name,
    val captions: List<CaptionCue> = emptyList(),
    val aspectRatio: String = "9:16",
    val filterPreset: String = FilterPreset.NONE.name,
    val filterIntensity: Double = 1.0,
    val playbackSpeed: Double = 1.0,
    val speedCurvePreset: String = SpeedCurvePreset.NORMAL.name,
    val zoomScale: Double = 1.0,
    val brightness: Double = 0.0,
    val contrast: Double = 1.0,
    val saturation: Double = 1.0,
    val warmth: Double = 0.0,
    val vignette: Double = 0.0,
    val rotationDeg: Int = 0,
    val flipHorizontal: Boolean = false,
    val videoEffect: String = VideoEffect.NONE.name,
    val transitionType: String = ClipTransition.NONE.name,
    val silenceRemoved: Boolean = false,
    val studioTemplateId: String = "",
    val voiceVolume: Double = 1.0,
    val voiceEffect: String = VoiceEffect.NORMAL.name,
    val audioFadeIn: Boolean = false,
    val audioFadeOut: Boolean = false,
    val musicTrack: String = MusicTrack.NONE.name,
    val musicVolume: Double = 0.25,
    val noiseReduction: Boolean = true,
    val overlayText: String = "",
    val captionPosition: String = CaptionPosition.BOTTOM.name,
    val captionScale: Double = 1.0,
    val thumbnailTemplate: String = ThumbnailTemplate.NEON_HOOK.name,
    val exportResolution: String = ExportResolution.RES_1080P.label,
    val exportFps: Long = 60L,
    val exportBitrate: String = ExportBitrate.HIGH.name,
    val exportFormat: String = ExportFormat.MP4_H264.name,
    val optimizedPlatform: String = SocialPlatform.TIKTOK.name,
    val seoTitle: String = "",
    val seoDescription: String = "",
    val seoTags: List<String> = emptyList(),
    val exportedPath: String = "",
    val waveformBars: List<Float> = emptyList(),
    val createdEpochMs: Long = 0L,
    val superAiGenerated: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun effectiveCreatedEpochMs(): Long =
        if (createdEpochMs > 0L) createdEpochMs else (createdAt?.toDate()?.time ?: System.currentTimeMillis())

    fun toCreateMap(uid: String): Map<String, Any> {
        val safeStart = startSec.coerceIn(0L, 86400L)
        val safeEnd = endSec.coerceIn(safeStart, 86400L)
        val nowMs = if (createdEpochMs > 0L) createdEpochMs else System.currentTimeMillis()
        return mapOf(
            "userId" to uid,
            "mediaId" to mediaId.take(128),
            "sourceUrl" to sourceUrl.take(500),
            "youtubeVideoId" to youtubeVideoId.take(32),
            "thumbnailUrl" to thumbnailUrl.take(500),
            "title" to title.ifBlank { "Viral Highlight" }.take(160),
            "hook" to hook.take(240),
            "viralScore" to viralScore.coerceIn(0L, 100L),
            "startSec" to safeStart,
            "endSec" to safeEnd,
            "subtitlesEnabled" to subtitlesEnabled,
            "subtitleStyle" to subtitleStyle,
            "captions" to captions.take(40).map { it.toMap() },
            "aspectRatio" to if (aspectRatio in listOf("9:16", "16:9", "1:1", "4:5")) aspectRatio else "9:16",
            "filterPreset" to filterPreset,
            "playbackSpeed" to playbackSpeed.coerceIn(0.25, 4.0),
            "zoomScale" to zoomScale.coerceIn(0.5, 3.0),
            "brightness" to brightness.coerceIn(-1.0, 1.0),
            "contrast" to contrast.coerceIn(0.2, 3.0),
            "saturation" to saturation.coerceIn(0.0, 3.0),
            "warmth" to warmth.coerceIn(-1.0, 1.0),
            "vignette" to vignette.coerceIn(0.0, 1.0),
            "rotationDeg" to ((rotationDeg % 360 + 360) % 360),
            "flipHorizontal" to flipHorizontal,
            "videoEffect" to videoEffect,
            "transitionType" to transitionType,
            "voiceVolume" to voiceVolume.coerceIn(0.0, 1.5),
            "voiceEffect" to voiceEffect,
            "audioFadeIn" to audioFadeIn,
            "audioFadeOut" to audioFadeOut,
            "musicTrack" to musicTrack,
            "musicVolume" to musicVolume.coerceIn(0.0, 1.5),
            "noiseReduction" to noiseReduction,
            "overlayText" to overlayText.take(120),
            "captionPosition" to captionPosition,
            "captionScale" to captionScale.coerceIn(0.6, 2.0),
            "thumbnailTemplate" to thumbnailTemplate,
            "exportResolution" to if (exportResolution in listOf("720p", "1080p", "2K", "4K")) exportResolution else "1080p",
            "exportFps" to if (exportFps in listOf(24L, 30L, 60L)) exportFps else 60L,
            "exportBitrate" to exportBitrate,
            "exportFormat" to exportFormat,
            "optimizedPlatform" to optimizedPlatform,
            "seoTitle" to seoTitle.take(160),
            "seoDescription" to seoDescription.take(1000),
            "seoTags" to seoTags.take(20).map { it.take(40) },
            "exportedPath" to exportedPath.take(500),
            "createdEpochMs" to nowMs,
            "superAiGenerated" to superAiGenerated,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}

@Keep
@IgnoreExtraProperties
data class SocialAccountDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val platform: String = SocialPlatform.TIKTOK.name,
    val handle: String = "",
    val connected: Boolean = false,
    val autoOptimize: Boolean = true,
    val followersCount: Long = 0L,
    val peakTimeWindow: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "platform" to platform,
        "handle" to handle.ifBlank { "@creator" }.take(80),
        "connected" to connected,
        "autoOptimize" to autoOptimize,
        "followersCount" to followersCount.coerceIn(0L, 1_000_000_000L),
        "peakTimeWindow" to peakTimeWindow.take(80),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class ScheduledPostDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val clipId: String = "",
    val clipTitle: String = "",
    val thumbnailUrl: String = "",
    val platforms: List<String> = emptyList(),
    val seoTitle: String = "",
    val seoDescription: String = "",
    val seoTags: List<String> = emptyList(),
    val scheduledAtEpochMs: Long = 0L,
    val scheduledLabel: String = "",
    val peakScore: Long = 90L,
    val status: String = PostStatus.SCHEDULED.name,
    val optimizationSummary: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "clipId" to clipId.ifBlank { "clip_custom" }.take(128),
        "clipTitle" to clipTitle.ifBlank { "Scheduled Clip" }.take(160),
        "thumbnailUrl" to thumbnailUrl.take(500),
        "platforms" to platforms.ifEmpty { listOf(SocialPlatform.TIKTOK.name) }.take(5),
        "seoTitle" to seoTitle.ifBlank { clipTitle.ifBlank { "Viral Clip" } }.take(160),
        "seoDescription" to seoDescription.take(1000),
        "seoTags" to seoTags.take(20),
        "scheduledAtEpochMs" to scheduledAtEpochMs.coerceAtLeast(1L),
        "scheduledLabel" to scheduledLabel.ifBlank { "Peak Window" }.take(80),
        "peakScore" to peakScore.coerceIn(0L, 100L),
        "status" to status,
        "optimizationSummary" to optimizationSummary.take(300),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class AnalyticsRecordDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val clipId: String = "",
    val clipTitle: String = "",
    val platform: String = SocialPlatform.TIKTOK.name,
    val dayLabel: String = "Today",
    val views: Long = 0L,
    val likes: Long = 0L,
    val comments: Long = 0L,
    val shares: Long = 0L,
    val avgWatchSeconds: Long = 0L,
    val retentionPercent: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "clipId" to clipId.take(128),
        "clipTitle" to clipTitle.ifBlank { "Clip Performance" }.take(160),
        "platform" to platform,
        "dayLabel" to dayLabel.ifBlank { "Today" }.take(32),
        "views" to views.coerceAtLeast(0L),
        "likes" to likes.coerceAtLeast(0L),
        "comments" to comments.coerceAtLeast(0L),
        "shares" to shares.coerceAtLeast(0L),
        "avgWatchSeconds" to avgWatchSeconds.coerceAtLeast(0L),
        "retentionPercent" to retentionPercent.coerceIn(0L, 100L),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}
