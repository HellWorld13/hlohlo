package com.example.data.local

import android.content.Context
import android.util.Log
import com.example.data.model.AnalyticsRecordDoc
import com.example.data.model.CaptionCue
import com.example.data.model.MediaItemDoc
import com.example.data.model.PostStatus
import com.example.data.model.ScheduledPostDoc
import com.example.data.model.SocialAccountDoc
import com.example.data.model.SocialPlatform
import com.example.data.model.UserProfile
import com.example.data.model.ViralClipDoc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class LocalGuestStore(context: Context) {
    private val appContext = context.applicationContext
    private val storeFile = File(appContext.filesDir, "clipforge_guest_workspace.json")
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val writeMutex = Mutex()

    private val _profile = MutableStateFlow(UserProfile(id = GUEST_UID, userId = GUEST_UID, displayName = "Local Creator"))
    val profile: StateFlow<UserProfile> = _profile.asStateFlow()

    private val _clips = MutableStateFlow<List<ViralClipDoc>>(emptyList())
    val clips: StateFlow<List<ViralClipDoc>> = _clips.asStateFlow()

    private val _media = MutableStateFlow<List<MediaItemDoc>>(emptyList())
    val media: StateFlow<List<MediaItemDoc>> = _media.asStateFlow()

    private val _socialAccounts = MutableStateFlow<List<SocialAccountDoc>>(emptyList())
    val socialAccounts: StateFlow<List<SocialAccountDoc>> = _socialAccounts.asStateFlow()

    private val _scheduledPosts = MutableStateFlow<List<ScheduledPostDoc>>(emptyList())
    val scheduledPosts: StateFlow<List<ScheduledPostDoc>> = _scheduledPosts.asStateFlow()

    private val _analytics = MutableStateFlow<List<AnalyticsRecordDoc>>(emptyList())
    val analytics: StateFlow<List<AnalyticsRecordDoc>> = _analytics.asStateFlow()

    init {
        ioScope.launch {
            loadFromDisk()
        }
    }

    private fun newId(prefix: String): String = "${prefix}_${UUID.randomUUID().toString().take(10)}"

    fun ensureProfile(displayName: String) {
        val current = _profile.value
        val resolvedName = displayName.ifBlank { "Local Creator" }.take(60)
        if (current.userId != GUEST_UID || current.displayName != resolvedName) {
            _profile.value = current.copy(
                id = GUEST_UID,
                userId = GUEST_UID,
                displayName = resolvedName
            )
            persistAsync()
        }
    }

    fun updateSuperAiConfig(
        active: Boolean,
        niche: String,
        channel: String,
        autoPostNow: Boolean,
        postingTimes: List<String>
    ) {
        val safeTimes = postingTimes.map { it.trim().take(24) }.filter { it.isNotEmpty() }.distinct().take(16)
        _profile.value = _profile.value.copy(
            superAiActive = active,
            superAiNiche = niche.trim().take(80),
            superAiChannel = channel.trim().take(80),
            superAiAutoPostNow = autoPostNow,
            superAiPostingTimes = safeTimes
        )
        persistAsync()
    }

    fun updateAutoDelete24h(enabled: Boolean) {
        _profile.value = _profile.value.copy(autoDelete24hEnabled = enabled)
        persistAsync()
    }

    fun createMediaItem(item: MediaItemDoc): String {
        val id = item.id.ifBlank { newId("med") }
        val nowMs = if (item.createdEpochMs > 0L) item.createdEpochMs else System.currentTimeMillis()
        val stored = item.copy(
            id = id,
            userId = GUEST_UID,
            createdEpochMs = nowMs
        )
        _media.value = (listOf(stored) + _media.value).sortedByDescending { it.createdEpochMs }
        persistAsync()
        return id
    }

    fun updateMediaStatus(mediaId: String, status: String) {
        _media.value = _media.value.map {
            if (it.id == mediaId) it.copy(status = status) else it
        }
        persistAsync()
    }

    fun deleteMediaItem(mediaId: String) {
        _media.value = _media.value.filterNot { it.id == mediaId }
        persistAsync()
    }

    fun saveClips(clips: List<ViralClipDoc>): List<String> {
        val nowMs = System.currentTimeMillis()
        val created = clips.mapIndexed { idx, clip ->
            val id = clip.id.ifBlank { newId("clip") }
            clip.copy(
                id = id,
                userId = GUEST_UID,
                createdEpochMs = if (clip.createdEpochMs > 0L) clip.createdEpochMs else (nowMs + idx)
            )
        }
        _clips.value = (created + _clips.value).sortedByDescending { it.createdEpochMs }
        persistAsync()
        return created.map { it.id }
    }

    fun saveSuperAiBatch(
        clips: List<ViralClipDoc>,
        mediaItems: List<MediaItemDoc>,
        scheduledPostsBuilder: (List<Pair<String, ViralClipDoc>>) -> List<ScheduledPostDoc>,
        analyticsBuilder: (List<Pair<String, ViralClipDoc>>) -> List<AnalyticsRecordDoc>
    ): List<String> {
        val nowMs = System.currentTimeMillis()
        val newMedia = mutableListOf<MediaItemDoc>()
        val newClips = mutableListOf<ViralClipDoc>()
        val clipPairs = mutableListOf<Pair<String, ViralClipDoc>>()

        mediaItems.forEachIndexed { index, media ->
            val mId = media.id.ifBlank { newId("med") }
            val mCreated = if (media.createdEpochMs > 0L) media.createdEpochMs else (nowMs + index)
            newMedia.add(media.copy(id = mId, userId = GUEST_UID, createdEpochMs = mCreated))

            val clip = clips.getOrNull(index)
            if (clip != null) {
                val cId = clip.id.ifBlank { newId("clip") }
                val cCreated = if (clip.createdEpochMs > 0L) clip.createdEpochMs else (nowMs + index)
                val linked = clip.copy(
                    id = cId,
                    userId = GUEST_UID,
                    mediaId = mId,
                    createdEpochMs = cCreated
                )
                newClips.add(linked)
                clipPairs.add(cId to linked)
            }
        }
        if (clips.size > mediaItems.size) {
            clips.drop(mediaItems.size).forEachIndexed { idx, clip ->
                val cId = clip.id.ifBlank { newId("clip") }
                val cCreated = if (clip.createdEpochMs > 0L) clip.createdEpochMs else (nowMs + mediaItems.size + idx)
                val stored = clip.copy(id = cId, userId = GUEST_UID, createdEpochMs = cCreated)
                newClips.add(stored)
                clipPairs.add(cId to stored)
            }
        }

        val newPosts = scheduledPostsBuilder(clipPairs).map {
            it.copy(id = it.id.ifBlank { newId("post") }, userId = GUEST_UID)
        }
        val newAnalytics = analyticsBuilder(clipPairs).map {
            it.copy(id = it.id.ifBlank { newId("stat") }, userId = GUEST_UID)
        }

        _media.value = (newMedia + _media.value).sortedByDescending { it.createdEpochMs }
        _clips.value = (newClips + _clips.value).sortedByDescending { it.createdEpochMs }
        if (newPosts.isNotEmpty()) {
            _scheduledPosts.value = (_scheduledPosts.value + newPosts).sortedBy { it.scheduledAtEpochMs }
        }
        if (newAnalytics.isNotEmpty()) {
            _analytics.value = newAnalytics + _analytics.value
        }

        persistAsync()
        return clipPairs.map { it.first }
    }

    fun deleteExpired(mediaIds: List<String>, clipIds: List<String>): Int {
        val mSet = mediaIds.toSet()
        val cSet = clipIds.toSet()
        if (mSet.isEmpty() && cSet.isEmpty()) return 0
        val beforeCount = _media.value.size + _clips.value.size
        _media.value = _media.value.filterNot { it.id in mSet }
        _clips.value = _clips.value.filterNot { it.id in cSet }
        val removed = beforeCount - (_media.value.size + _clips.value.size)
        if (removed > 0) persistAsync()
        return removed
    }

    fun updateClip(clip: ViralClipDoc) {
        _clips.value = _clips.value.map {
            if (it.id == clip.id) clip.copy(userId = GUEST_UID) else it
        }
        persistAsync()
    }

    fun deleteClip(clipId: String) {
        _clips.value = _clips.value.filterNot { it.id == clipId }
        persistAsync()
    }

    fun upsertSocialAccount(account: SocialAccountDoc) {
        val docId = "acc_${account.platform.lowercase()}"
        val updated = account.copy(id = docId, userId = GUEST_UID)
        val current = _socialAccounts.value.filterNot { it.id == docId || it.platform == account.platform }
        _socialAccounts.value = current + updated
        persistAsync()
    }

    fun createScheduledPost(post: ScheduledPostDoc): String {
        val id = post.id.ifBlank { newId("post") }
        val stored = post.copy(id = id, userId = GUEST_UID)
        _scheduledPosts.value = (_scheduledPosts.value + stored).sortedBy { it.scheduledAtEpochMs }
        persistAsync()
        return id
    }

    fun updateScheduledPost(
        postId: String,
        scheduledAtEpochMs: Long,
        scheduledLabel: String,
        peakScore: Long,
        status: PostStatus
    ) {
        _scheduledPosts.value = _scheduledPosts.value.map {
            if (it.id == postId) {
                it.copy(
                    scheduledAtEpochMs = scheduledAtEpochMs.coerceAtLeast(1L),
                    scheduledLabel = scheduledLabel.ifBlank { "Peak Window" }.take(80),
                    peakScore = peakScore.coerceIn(0L, 100L),
                    status = status.name
                )
            } else it
        }.sortedBy { it.scheduledAtEpochMs }
        persistAsync()
    }

    fun deleteScheduledPost(postId: String) {
        _scheduledPosts.value = _scheduledPosts.value.filterNot { it.id == postId }
        persistAsync()
    }

    fun logAnalyticsRecord(record: AnalyticsRecordDoc): String {
        val id = record.id.ifBlank { newId("stat") }
        val stored = record.copy(id = id, userId = GUEST_UID)
        _analytics.value = listOf(stored) + _analytics.value
        persistAsync()
        return id
    }

    fun clearAllLocalData() {
        _clips.value = emptyList()
        _media.value = emptyList()
        _socialAccounts.value = emptyList()
        _scheduledPosts.value = emptyList()
        _analytics.value = emptyList()
        persistAsync()
    }

    private fun persistAsync() {
        val snapshotProfile = _profile.value
        val snapshotClips = _clips.value
        val snapshotMedia = _media.value
        val snapshotAccounts = _socialAccounts.value
        val snapshotPosts = _scheduledPosts.value
        val snapshotAnalytics = _analytics.value

        ioScope.launch {
            writeMutex.withLock {
                try {
                    val root = JSONObject().apply {
                        put("profile", encodeProfile(snapshotProfile))
                        put("clips", JSONArray().apply { snapshotClips.forEach { put(encodeClip(it)) } })
                        put("media", JSONArray().apply { snapshotMedia.forEach { put(encodeMedia(it)) } })
                        put("accounts", JSONArray().apply { snapshotAccounts.forEach { put(encodeAccount(it)) } })
                        put("posts", JSONArray().apply { snapshotPosts.forEach { put(encodePost(it)) } })
                        put("analytics", JSONArray().apply { snapshotAnalytics.forEach { put(encodeAnalytics(it)) } })
                    }
                    storeFile.writeText(root.toString())
                } catch (e: Exception) {
                    Log.w(TAG, "Failed saving guest workspace", e)
                }
            }
        }
    }

    private fun loadFromDisk() {
        try {
            if (!storeFile.exists()) return
            val raw = storeFile.readText()
            if (raw.isBlank()) return
            val root = JSONObject(raw)

            root.optJSONObject("profile")?.let { p ->
                val timesArr = p.optJSONArray("superAiPostingTimes")
                val times = buildList {
                    if (timesArr != null) {
                        for (i in 0 until timesArr.length()) {
                            timesArr.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                        }
                    }
                }.ifEmpty { listOf("09:00 AM", "01:00 PM", "06:30 PM", "09:00 PM") }

                _profile.value = UserProfile(
                    id = GUEST_UID,
                    userId = GUEST_UID,
                    displayName = p.optString("displayName", "Local Creator"),
                    defaultPlatform = p.optString("defaultPlatform", SocialPlatform.TIKTOK.name),
                    autoSubtitlesEnabled = p.optBoolean("autoSubtitlesEnabled", true),
                    superAiActive = p.optBoolean("superAiActive", false),
                    superAiNiche = p.optString("superAiNiche", "Trending & Viral"),
                    superAiChannel = p.optString("superAiChannel", ""),
                    superAiAutoPostNow = p.optBoolean("superAiAutoPostNow", false),
                    superAiPostingTimes = times,
                    autoDelete24hEnabled = p.optBoolean("autoDelete24hEnabled", false)
                )
            }

            root.optJSONArray("clips")?.let { arr ->
                _clips.value = (0 until arr.length()).map { decodeClip(arr.getJSONObject(it)) }
                    .sortedByDescending { it.createdEpochMs }
            }
            root.optJSONArray("media")?.let { arr ->
                _media.value = (0 until arr.length()).map { decodeMedia(arr.getJSONObject(it)) }
                    .sortedByDescending { it.createdEpochMs }
            }
            root.optJSONArray("accounts")?.let { arr ->
                _socialAccounts.value = (0 until arr.length()).map { decodeAccount(arr.getJSONObject(it)) }
            }
            root.optJSONArray("posts")?.let { arr ->
                _scheduledPosts.value = (0 until arr.length()).map { decodePost(arr.getJSONObject(it)) }
                    .sortedBy { it.scheduledAtEpochMs }
            }
            root.optJSONArray("analytics")?.let { arr ->
                _analytics.value = (0 until arr.length()).map { decodeAnalytics(arr.getJSONObject(it)) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed loading guest workspace", e)
        }
    }

    private fun encodeProfile(p: UserProfile) = JSONObject().apply {
        put("displayName", p.displayName)
        put("defaultPlatform", p.defaultPlatform)
        put("autoSubtitlesEnabled", p.autoSubtitlesEnabled)
        put("superAiActive", p.superAiActive)
        put("superAiNiche", p.superAiNiche)
        put("superAiChannel", p.superAiChannel)
        put("superAiAutoPostNow", p.superAiAutoPostNow)
        put("superAiPostingTimes", JSONArray(p.superAiPostingTimes))
        put("autoDelete24hEnabled", p.autoDelete24hEnabled)
    }

    private fun encodeMedia(m: MediaItemDoc) = JSONObject().apply {
        put("id", m.id)
        put("title", m.title)
        put("sourceType", m.sourceType)
        put("sourceUrl", m.sourceUrl)
        put("youtubeVideoId", m.youtubeVideoId)
        put("thumbnailUrl", m.thumbnailUrl)
        put("durationSeconds", m.durationSeconds)
        put("aspectRatio", m.aspectRatio)
        put("status", m.status)
        put("createdEpochMs", m.createdEpochMs)
        put("superAiGenerated", m.superAiGenerated)
    }

    private fun decodeMedia(o: JSONObject) = MediaItemDoc(
        id = o.optString("id"),
        userId = GUEST_UID,
        title = o.optString("title"),
        sourceType = o.optString("sourceType"),
        sourceUrl = o.optString("sourceUrl"),
        youtubeVideoId = o.optString("youtubeVideoId"),
        thumbnailUrl = o.optString("thumbnailUrl"),
        durationSeconds = o.optLong("durationSeconds"),
        aspectRatio = o.optString("aspectRatio", "16:9"),
        status = o.optString("status"),
        createdEpochMs = o.optLong("createdEpochMs"),
        superAiGenerated = o.optBoolean("superAiGenerated", false)
    )

    private fun encodeClip(c: ViralClipDoc) = JSONObject().apply {
        put("id", c.id)
        put("mediaId", c.mediaId)
        put("sourceUrl", c.sourceUrl)
        put("youtubeVideoId", c.youtubeVideoId)
        put("thumbnailUrl", c.thumbnailUrl)
        put("title", c.title)
        put("hook", c.hook)
        put("viralScore", c.viralScore)
        put("hookScore", c.hookScore)
        put("viralReason", c.viralReason)
        put("startSec", c.startSec)
        put("endSec", c.endSec)
        put("subtitlesEnabled", c.subtitlesEnabled)
        put("subtitleStyle", c.subtitleStyle)
        put("captions", JSONArray().apply {
            c.captions.forEach { cue ->
                put(JSONObject().apply {
                    put("startSec", cue.startSec)
                    put("endSec", cue.endSec)
                    put("text", cue.text)
                })
            }
        })
        put("aspectRatio", c.aspectRatio)
        put("filterPreset", c.filterPreset)
        put("filterIntensity", c.filterIntensity)
        put("playbackSpeed", c.playbackSpeed)
        put("speedCurvePreset", c.speedCurvePreset)
        put("zoomScale", c.zoomScale)
        put("brightness", c.brightness)
        put("contrast", c.contrast)
        put("saturation", c.saturation)
        put("warmth", c.warmth)
        put("vignette", c.vignette)
        put("rotationDeg", c.rotationDeg)
        put("flipHorizontal", c.flipHorizontal)
        put("videoEffect", c.videoEffect)
        put("transitionType", c.transitionType)
        put("silenceRemoved", c.silenceRemoved)
        put("studioTemplateId", c.studioTemplateId)
        put("voiceVolume", c.voiceVolume)
        put("voiceEffect", c.voiceEffect)
        put("audioFadeIn", c.audioFadeIn)
        put("audioFadeOut", c.audioFadeOut)
        put("musicTrack", c.musicTrack)
        put("musicVolume", c.musicVolume)
        put("noiseReduction", c.noiseReduction)
        put("overlayText", c.overlayText)
        put("captionPosition", c.captionPosition)
        put("captionScale", c.captionScale)
        put("thumbnailTemplate", c.thumbnailTemplate)
        put("exportResolution", c.exportResolution)
        put("exportFps", c.exportFps)
        put("exportBitrate", c.exportBitrate)
        put("exportFormat", c.exportFormat)
        put("optimizedPlatform", c.optimizedPlatform)
        put("seoTitle", c.seoTitle)
        put("seoDescription", c.seoDescription)
        put("seoTags", JSONArray(c.seoTags))
        put("exportedPath", c.exportedPath)
        put("waveformBars", JSONArray().apply { c.waveformBars.forEach { put(it.toDouble()) } })
        put("createdEpochMs", c.createdEpochMs)
        put("superAiGenerated", c.superAiGenerated)
    }

    private fun decodeClip(o: JSONObject): ViralClipDoc {
        val cuesArr = o.optJSONArray("captions")
        val captions = buildList {
            if (cuesArr != null) {
                for (i in 0 until cuesArr.length()) {
                    val cObj = cuesArr.getJSONObject(i)
                    add(CaptionCue(cObj.optLong("startSec"), cObj.optLong("endSec"), cObj.optString("text")))
                }
            }
        }
        val tagsArr = o.optJSONArray("seoTags")
        val tags = buildList {
            if (tagsArr != null) {
                for (i in 0 until tagsArr.length()) {
                    add(tagsArr.optString(i))
                }
            }
        }
        val waveArr = o.optJSONArray("waveformBars")
        val waveBars = buildList {
            if (waveArr != null) {
                for (i in 0 until waveArr.length()) {
                    add(waveArr.optDouble(i, 0.4).toFloat().coerceIn(0.1f, 1.0f))
                }
            }
        }
        return ViralClipDoc(
            id = o.optString("id"),
            userId = GUEST_UID,
            mediaId = o.optString("mediaId"),
            sourceUrl = o.optString("sourceUrl"),
            youtubeVideoId = o.optString("youtubeVideoId"),
            thumbnailUrl = o.optString("thumbnailUrl"),
            title = o.optString("title"),
            hook = o.optString("hook"),
            viralScore = o.optLong("viralScore", 85L),
            hookScore = o.optLong("hookScore", 88L),
            viralReason = o.optString("viralReason"),
            startSec = o.optLong("startSec", 0L),
            endSec = o.optLong("endSec", 35L),
            subtitlesEnabled = o.optBoolean("subtitlesEnabled", true),
            subtitleStyle = o.optString("subtitleStyle", "HORMOZI_POP"),
            captions = captions,
            aspectRatio = o.optString("aspectRatio", "9:16"),
            filterPreset = o.optString("filterPreset", "NONE"),
            filterIntensity = o.optDouble("filterIntensity", 1.0),
            playbackSpeed = o.optDouble("playbackSpeed", 1.0),
            speedCurvePreset = o.optString("speedCurvePreset", "NORMAL"),
            zoomScale = o.optDouble("zoomScale", 1.0),
            brightness = o.optDouble("brightness", 0.0),
            contrast = o.optDouble("contrast", 1.0),
            saturation = o.optDouble("saturation", 1.0),
            warmth = o.optDouble("warmth", 0.0),
            vignette = o.optDouble("vignette", 0.0),
            rotationDeg = o.optInt("rotationDeg", 0),
            flipHorizontal = o.optBoolean("flipHorizontal", false),
            videoEffect = o.optString("videoEffect", "NONE"),
            transitionType = o.optString("transitionType", "NONE"),
            silenceRemoved = o.optBoolean("silenceRemoved", false),
            studioTemplateId = o.optString("studioTemplateId"),
            voiceVolume = o.optDouble("voiceVolume", 1.0),
            voiceEffect = o.optString("voiceEffect", "NORMAL"),
            audioFadeIn = o.optBoolean("audioFadeIn", false),
            audioFadeOut = o.optBoolean("audioFadeOut", false),
            musicTrack = o.optString("musicTrack", "NONE"),
            musicVolume = o.optDouble("musicVolume", 0.25),
            noiseReduction = o.optBoolean("noiseReduction", true),
            overlayText = o.optString("overlayText"),
            captionPosition = o.optString("captionPosition", "BOTTOM"),
            captionScale = o.optDouble("captionScale", 1.0),
            thumbnailTemplate = o.optString("thumbnailTemplate", "NEON_HOOK"),
            exportResolution = o.optString("exportResolution", "1080p"),
            exportFps = o.optLong("exportFps", 60L),
            exportBitrate = o.optString("exportBitrate", "HIGH"),
            exportFormat = o.optString("exportFormat", "MP4_H264"),
            optimizedPlatform = o.optString("optimizedPlatform", SocialPlatform.TIKTOK.name),
            seoTitle = o.optString("seoTitle"),
            seoDescription = o.optString("seoDescription"),
            seoTags = tags,
            exportedPath = o.optString("exportedPath"),
            waveformBars = waveBars,
            createdEpochMs = o.optLong("createdEpochMs"),
            superAiGenerated = o.optBoolean("superAiGenerated", false)
        )
    }

    private fun encodeAccount(a: SocialAccountDoc) = JSONObject().apply {
        put("id", a.id)
        put("platform", a.platform)
        put("handle", a.handle)
        put("connected", a.connected)
        put("autoOptimize", a.autoOptimize)
        put("followersCount", a.followersCount)
        put("peakTimeWindow", a.peakTimeWindow)
    }

    private fun decodeAccount(o: JSONObject) = SocialAccountDoc(
        id = o.optString("id"),
        userId = GUEST_UID,
        platform = o.optString("platform"),
        handle = o.optString("handle"),
        connected = o.optBoolean("connected", false),
        autoOptimize = o.optBoolean("autoOptimize", true),
        followersCount = o.optLong("followersCount", 0L),
        peakTimeWindow = o.optString("peakTimeWindow")
    )

    private fun encodePost(p: ScheduledPostDoc) = JSONObject().apply {
        put("id", p.id)
        put("clipId", p.clipId)
        put("clipTitle", p.clipTitle)
        put("thumbnailUrl", p.thumbnailUrl)
        put("platforms", JSONArray(p.platforms))
        put("seoTitle", p.seoTitle)
        put("seoDescription", p.seoDescription)
        put("seoTags", JSONArray(p.seoTags))
        put("scheduledAtEpochMs", p.scheduledAtEpochMs)
        put("scheduledLabel", p.scheduledLabel)
        put("peakScore", p.peakScore)
        put("status", p.status)
        put("optimizationSummary", p.optimizationSummary)
    }

    private fun decodePost(o: JSONObject): ScheduledPostDoc {
        val platArr = o.optJSONArray("platforms")
        val platforms = buildList {
            if (platArr != null) {
                for (i in 0 until platArr.length()) add(platArr.optString(i))
            }
        }
        val tagsArr = o.optJSONArray("seoTags")
        val tags = buildList {
            if (tagsArr != null) {
                for (i in 0 until tagsArr.length()) add(tagsArr.optString(i))
            }
        }
        return ScheduledPostDoc(
            id = o.optString("id"),
            userId = GUEST_UID,
            clipId = o.optString("clipId"),
            clipTitle = o.optString("clipTitle"),
            thumbnailUrl = o.optString("thumbnailUrl"),
            platforms = platforms,
            seoTitle = o.optString("seoTitle"),
            seoDescription = o.optString("seoDescription"),
            seoTags = tags,
            scheduledAtEpochMs = o.optLong("scheduledAtEpochMs"),
            scheduledLabel = o.optString("scheduledLabel"),
            peakScore = o.optLong("peakScore", 90L),
            status = o.optString("status", PostStatus.SCHEDULED.name),
            optimizationSummary = o.optString("optimizationSummary")
        )
    }

    private fun encodeAnalytics(r: AnalyticsRecordDoc) = JSONObject().apply {
        put("id", r.id)
        put("clipId", r.clipId)
        put("clipTitle", r.clipTitle)
        put("platform", r.platform)
        put("dayLabel", r.dayLabel)
        put("views", r.views)
        put("likes", r.likes)
        put("comments", r.comments)
        put("shares", r.shares)
        put("avgWatchSeconds", r.avgWatchSeconds)
        put("retentionPercent", r.retentionPercent)
    }

    private fun decodeAnalytics(o: JSONObject) = AnalyticsRecordDoc(
        id = o.optString("id"),
        userId = GUEST_UID,
        clipId = o.optString("clipId"),
        clipTitle = o.optString("clipTitle"),
        platform = o.optString("platform"),
        dayLabel = o.optString("dayLabel"),
        views = o.optLong("views"),
        likes = o.optLong("likes"),
        comments = o.optLong("comments"),
        shares = o.optLong("shares"),
        avgWatchSeconds = o.optLong("avgWatchSeconds"),
        retentionPercent = o.optLong("retentionPercent")
    )

    companion object {
        const val GUEST_UID = "guest_local"
        private const val TAG = "LocalGuestStore"
    }
}
