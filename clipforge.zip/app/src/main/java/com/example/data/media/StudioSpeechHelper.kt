package com.example.data.media

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class StudioSpeechHelper(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit = {}
) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingText: String? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = (status == TextToSpeech.SUCCESS)
            if (ready) {
                tts?.language = Locale.US
                tts?.setSpeechRate(1.06f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingChanged(false)
                    }
                })
                pendingText?.let { queued ->
                    pendingText = null
                    speak(queued)
                }
            }
        }
    }

    fun speak(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        if (!ready) {
            pendingText = clean
            return
        }
        onSpeakingChanged(true)
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "clipforge_tts_${System.currentTimeMillis()}")
    }

    fun stop() {
        pendingText = null
        tts?.stop()
        onSpeakingChanged(false)
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
