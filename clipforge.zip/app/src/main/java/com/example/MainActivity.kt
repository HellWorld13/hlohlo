package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.local.AppSettingsStore
import com.example.data.local.LocalGuestStore
import com.example.data.media.OnDeviceSignalAnalyzer
import com.example.data.media.VideoExportEngine
import com.example.data.remote.ClipForgeAiService
import com.example.data.remote.YouTubeMetadataService
import com.example.data.remote.configureAppCheck
import com.example.data.repository.ClipForgeRepository
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.ClipperScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.ClipForgeTheme
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianSurface
import com.example.ui.viewmodel.ClipForgeViewModel

enum class ClipForgeTab(
    val labelRes: Int,
    val icon: ImageVector,
    val testTag: String
) {
    CLIPPER(R.string.nav_clipper, Icons.Default.ContentCut, "nav_tab_clipper"),
    STUDIO(R.string.nav_studio, Icons.Default.Movie, "nav_tab_studio"),
    SCHEDULE(R.string.nav_schedule, Icons.Default.CalendarMonth, "nav_tab_schedule"),
    ANALYTICS(R.string.nav_analytics, Icons.Default.Insights, "nav_tab_analytics"),
    LIBRARY(R.string.nav_library, Icons.Default.VideoLibrary, "nav_tab_library")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()

        setContent {
            ClipForgeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ClipForgeAppRoot()
                }
            }
        }
    }
}

@Composable
fun ClipForgeAppRoot() {
    ClipForgeWorkspace(
        currentUserId = LocalGuestStore.GUEST_UID,
        displayName = "Mobile Creator"
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClipForgeWorkspace(
    currentUserId: String,
    displayName: String
) {
    val viewModel: ClipForgeViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val settingsStore = AppSettingsStore(app)
                val ytService = YouTubeMetadataService()
                val signalAnalyzer = OnDeviceSignalAnalyzer(app)
                ClipForgeViewModel(
                    repository = ClipForgeRepository(app, isGuestMode = true),
                    youTubeMetadataService = ytService,
                    aiService = ClipForgeAiService(ytService, settingsStore, signalAnalyzer),
                    videoExportEngine = VideoExportEngine(app),
                    currentUserId = currentUserId,
                    displayName = displayName,
                    settingsStore = settingsStore,
                    signalAnalyzer = signalAnalyzer
                )
            }
        }
    )

    val appSettings by viewModel.appSettingsState.collectAsStateWithLifecycle()
    var activeTab by remember { mutableStateOf(ClipForgeTab.CLIPPER) }
    var showSettings by remember { mutableStateOf(false) }
    var scheduleClipId by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    if (showSettings) {
        BackHandler { showSettings = false }
    } else if (activeTab != ClipForgeTab.CLIPPER) {
        BackHandler { activeTab = ClipForgeTab.CLIPPER }
    }

    SnackbarObserver(
        viewModel = viewModel,
        snackbarHostState = snackbarHostState
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 840.dp

        Scaffold(
            containerColor = ObsidianBg,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianSurface),
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = CoralPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = "${appSettings.effectiveEngineLabel()} • ${appSettings.defaultExportFps}fps",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberCyan
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showSettings = !showSettings },
                            modifier = Modifier.testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = stringResource(R.string.nav_settings),
                                tint = if (showSettings) CoralPrimary else CyberCyan
                            )
                        }
                    }
                )
            },
            bottomBar = {
                if (!useNavRail && !showSettings) {
                    NavigationBar(containerColor = ObsidianSurface) {
                        ClipForgeTab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = activeTab == tab,
                                onClick = {
                                    showSettings = false
                                    activeTab = tab
                                },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes), maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = CoralPrimary,
                                    indicatorColor = CoralPrimary
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail && !showSettings) {
                    NavigationRail(containerColor = ObsidianSurface) {
                        ClipForgeTab.entries.forEach { tab ->
                            NavigationRailItem(
                                selected = activeTab == tab,
                                onClick = {
                                    showSettings = false
                                    activeTab = tab
                                },
                                icon = { Icon(tab.icon, contentDescription = stringResource(tab.labelRes)) },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 780.dp)
                            .fillMaxSize()
                    ) {
                        if (showSettings) {
                            val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
                            val cacheSizeMb by viewModel.cacheSizeMb.collectAsStateWithLifecycle()

                            LaunchedEffect(Unit) {
                                viewModel.refreshCacheSize()
                            }

                            SettingsScreen(
                                currentSettings = appSettings,
                                autoDelete24hEnabled = (userProfileState as? com.example.data.model.UiState.Success)
                                    ?.data?.autoDelete24hEnabled == true,
                                cacheSizeMb = cacheSizeMb,
                                onBack = { showSettings = false },
                                onSaveSettings = { updated -> viewModel.saveAppSettings(updated) },
                                onToggleAutoDelete24h = { enabled -> viewModel.toggleAutoDelete24h(enabled) },
                                onClearMediaCache = { viewModel.clearMediaCaches() },
                                onClearWorkspace = { viewModel.clearLocalWorkspace() }
                            )
                        } else {
                            when (activeTab) {
                                ClipForgeTab.CLIPPER -> {
                                    val clipsState by viewModel.clipsState.collectAsStateWithLifecycle()
                                    val mediaState by viewModel.mediaState.collectAsStateWithLifecycle()
                                    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
                                    val aiClipperStatus by viewModel.aiClipperStatus.collectAsStateWithLifecycle()
                                    val superAiStatus by viewModel.superAiStatus.collectAsStateWithLifecycle()

                                    ClipperScreen(
                                        clipsState = clipsState,
                                        mediaState = mediaState,
                                        userProfileState = userProfileState,
                                        aiStatus = aiClipperStatus,
                                        superAiStatus = superAiStatus,
                                        onToggleSuperAi = { enabled, niche, channel, autoPostNow, times ->
                                            viewModel.toggleSuperAiAndRunIfEnabled(enabled, niche, channel, autoPostNow, times)
                                        },
                                        onRunSuperAiNow = { niche, channel, autoPostNow, times ->
                                            viewModel.runSuperAiAutopilot(niche, channel, autoPostNow, times)
                                        },
                                        onSaveSuperAiPrefs = { active, niche, channel, autoPostNow, times ->
                                            viewModel.saveSuperAiSettings(active, niche, channel, autoPostNow, times)
                                        },
                                        onDismissSuperAiStatus = { viewModel.dismissSuperAiStatus() },
                                        onClipYouTubeUrl = { url, platform, subs, count, minSec, maxSec ->
                                            viewModel.clipYouTubeVideo(
                                                rawUrl = url,
                                                targetPlatform = platform,
                                                includeSubtitles = subs,
                                                clipCount = count,
                                                minClipSec = minSec,
                                                maxClipSec = maxSec
                                            )
                                        },
                                        onUploadLocalVideo = { uri ->
                                            viewModel.uploadVideoToStudio(uri)
                                            activeTab = ClipForgeTab.STUDIO
                                        },
                                        onToggleSubtitles = { clip -> viewModel.toggleClipSubtitles(clip) },
                                        onEditInStudio = { clip ->
                                            viewModel.selectClipForStudio(clip.id)
                                            activeTab = ClipForgeTab.STUDIO
                                        },
                                        onScheduleClip = { clip ->
                                            scheduleClipId = clip.id
                                            activeTab = ClipForgeTab.SCHEDULE
                                        },
                                        onDeleteClip = { id -> viewModel.deleteClip(id) },
                                        onDismissStatus = { viewModel.resetClipperStatus() }
                                    )
                                }

                                ClipForgeTab.STUDIO -> {
                                    val clipsState by viewModel.clipsState.collectAsStateWithLifecycle()
                                    val selectedStudioClipId by viewModel.selectedStudioClipId.collectAsStateWithLifecycle()
                                    val exportStatus by viewModel.exportStatus.collectAsStateWithLifecycle()
                                    val seoGenerating by viewModel.seoGenerating.collectAsStateWithLifecycle()
                                    val captionsGenerating by viewModel.captionsGenerating.collectAsStateWithLifecycle()
                                    val smartEditGenerating by viewModel.smartEditGenerating.collectAsStateWithLifecycle()

                                    StudioScreen(
                                        clipsState = clipsState,
                                        selectedClipId = selectedStudioClipId,
                                        exportStatus = exportStatus,
                                        isGeneratingSeo = seoGenerating,
                                        isGeneratingCaptions = captionsGenerating,
                                        isGeneratingSmartEdit = smartEditGenerating,
                                        onSelectClip = { id -> viewModel.selectClipForStudio(id) },
                                        onUploadVideoToStudio = { uri -> viewModel.uploadVideoToStudio(uri) },
                                        onSaveClip = { clip -> viewModel.saveClipEdits(clip) },
                                        onSplitClip = { clip, sec -> viewModel.splitClipAtPlayhead(clip, sec) },
                                        onDuplicateClip = { clip -> viewModel.duplicateClip(clip) },
                                        onCaptureCoverFrame = { clip, sec, onDone ->
                                            viewModel.captureCoverFrameAtPlayhead(clip, sec, onDone)
                                        },
                                        onSyncScript = { clip, script, onDone ->
                                            viewModel.syncScriptToClipCaptions(clip, script, onDone)
                                        },
                                        onAiSmartEdit = { clip, onDone -> viewModel.runAiSmartDirector(clip, onDone) },
                                        onGenerateSeo = { clip, platform, onDone ->
                                            viewModel.generateSeoForClip(clip, platform, onDone)
                                        },
                                        onRegenerateCaptions = { clip -> viewModel.regenerateCaptionsForClip(clip) },
                                        onExportClip = { clip -> viewModel.exportClip(clip) }
                                    )
                                }

                                ClipForgeTab.SCHEDULE -> {
                                    val clipsState by viewModel.clipsState.collectAsStateWithLifecycle()
                                    val accountsState by viewModel.socialAccountsState.collectAsStateWithLifecycle()
                                    val postsState by viewModel.scheduledPostsState.collectAsStateWithLifecycle()
                                    val seoGenerating by viewModel.seoGenerating.collectAsStateWithLifecycle()

                                    ScheduleScreen(
                                        clipsState = clipsState,
                                        accountsState = accountsState,
                                        postsState = postsState,
                                        isGeneratingSeo = seoGenerating,
                                        preselectedClipId = scheduleClipId,
                                        onConnectAccount = { p, h, conn, autoOpt, followers ->
                                            viewModel.connectOrUpdateSocialAccount(p, h, conn, autoOpt, followers)
                                        },
                                        onGenerateSeo = { clip, platform, onDone ->
                                            viewModel.generateSeoForClip(clip, platform, onDone)
                                        },
                                        onSchedulePost = { clip, platforms, title, desc, tags, epochMs, label, peakScore, pubNow ->
                                            viewModel.scheduleClipPost(
                                                clip, platforms, title, desc, tags, epochMs, label, peakScore, pubNow
                                            )
                                        },
                                        onMarkPublished = { post -> viewModel.markPostPublished(post) },
                                        onDeletePost = { id -> viewModel.deleteScheduledPost(id) }
                                    )
                                }

                                ClipForgeTab.ANALYTICS -> {
                                    val analyticsState by viewModel.analyticsState.collectAsStateWithLifecycle()
                                    val clipsState by viewModel.clipsState.collectAsStateWithLifecycle()
                                    val aiInsightsState by viewModel.aiInsightsState.collectAsStateWithLifecycle()

                                    AnalyticsScreen(
                                        analyticsState = analyticsState,
                                        clipsState = clipsState,
                                        aiInsightsState = aiInsightsState,
                                        onGenerateInsights = { recs, clips -> viewModel.generateGrowthInsights(recs, clips) },
                                        onLogMetric = { title, clipId, platform, day, views, likes, comments, shares, retention ->
                                            viewModel.logAnalyticsMetric(
                                                title, clipId, platform, day, views, likes, comments, shares, retention
                                            )
                                        }
                                    )
                                }

                                ClipForgeTab.LIBRARY -> {
                                    val mediaState by viewModel.mediaState.collectAsStateWithLifecycle()
                                    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()

                                    LibraryScreen(
                                        mediaState = mediaState,
                                        autoDelete24hEnabled = (userProfileState as? com.example.data.model.UiState.Success)
                                            ?.data?.autoDelete24hEnabled == true,
                                        onToggleAutoDelete24h = { enabled ->
                                            viewModel.toggleAutoDelete24h(enabled)
                                        },
                                        onUploadVideo = { uri -> viewModel.uploadLocalVideo(uri) },
                                        onAutoClipMedia = { media, platform, subs ->
                                            viewModel.clipMediaItemWithAi(media, platform, subs)
                                            activeTab = ClipForgeTab.CLIPPER
                                        },
                                        onDeleteMedia = { id -> viewModel.deleteMedia(id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SnackbarObserver(
    viewModel: ClipForgeViewModel,
    snackbarHostState: SnackbarHostState
) {
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }
}
